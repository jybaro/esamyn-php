export class User {
    id: string;
	nombre: string;
    password: string;
    contrasenia: string;
	role: string;
	company: string;	
	token: string;
	loggedIn: boolean;
	type: string;
	nombreUsuario:string;
	nombreCompleto:string;
	passwordConfirm:string;
	fechaCreacion:Date;
    estado:string;
}