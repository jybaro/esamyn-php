import {ItemMenu} from "./index";
import {MenuModule,MenuItem} from 'primeng/primeng';

export class Menu {
	crudsItemRol:any;
	panelMenuAppListArray:ItemMenu[];
	panelMenuAppList:MenuItem[];

}