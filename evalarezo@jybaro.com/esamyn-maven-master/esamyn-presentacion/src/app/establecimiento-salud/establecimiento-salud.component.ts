import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'establecimiento-salud',
  templateUrl: './establecimiento-salud.component.html',
  styleUrls: ['./establecimiento-salud.component.css']
})
export class EstablecimientoSaludComponent implements OnInit {

  constructor() { 
     
  }

  ngOnInit() {
  }

}
