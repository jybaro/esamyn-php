export const environment = {
  production: true,
  baseHref: '/core-general-web/light/'
};
