--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.0

-- Started on 2017-11-06 08:38:59 -05

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 7 (class 2615 OID 34296)
-- Name: administracion_general; Type: SCHEMA; Schema: -; Owner: esamyn_user
--

CREATE SCHEMA administracion_general;


ALTER SCHEMA administracion_general OWNER TO esamyn_user;

--
-- TOC entry 2960 (class 0 OID 0)
-- Dependencies: 7
-- Name: SCHEMA administracion_general; Type: COMMENT; Schema: -; Owner: esamyn_user
--

COMMENT ON SCHEMA administracion_general IS 'Esquema que contiene los objetos correspondientes a generalidades';


--
-- TOC entry 8 (class 2615 OID 34297)
-- Name: administracion_seguridad; Type: SCHEMA; Schema: -; Owner: esamyn_user
--

CREATE SCHEMA administracion_seguridad;


ALTER SCHEMA administracion_seguridad OWNER TO esamyn_user;

--
-- TOC entry 2961 (class 0 OID 0)
-- Dependencies: 8
-- Name: SCHEMA administracion_seguridad; Type: COMMENT; Schema: -; Owner: esamyn_user
--

COMMENT ON SCHEMA administracion_seguridad IS 'Esquema para el manejo de la administración de usuarios externos e internos';


--
-- TOC entry 11 (class 2615 OID 34298)
-- Name: esamyn; Type: SCHEMA; Schema: -; Owner: esamyn_user
--

CREATE SCHEMA esamyn;


ALTER SCHEMA esamyn OWNER TO esamyn_user;

--
-- TOC entry 6 (class 2615 OID 34299)
-- Name: medicina_prepagada; Type: SCHEMA; Schema: -; Owner: esamyn_user
--

CREATE SCHEMA medicina_prepagada;


ALTER SCHEMA medicina_prepagada OWNER TO esamyn_user;

--
-- TOC entry 2962 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA medicina_prepagada; Type: COMMENT; Schema: -; Owner: esamyn_user
--

COMMENT ON SCHEMA medicina_prepagada IS 'Esquema que almacena la informaci''on referente a los procesos de medicina prepagada';


--
-- TOC entry 1 (class 3079 OID 12655)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2964 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = administracion_general, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 189 (class 1259 OID 34300)
-- Name: agn_canton; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_canton (
    can_codigo_canton numeric(10,0) NOT NULL,
    can_nombre character varying(150),
    can_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    can_codigo_provincia numeric(10,0),
    can_fecha_creacion date NOT NULL,
    can_fecha_modificacion date NOT NULL,
    can_codigo_usuario_crea numeric(10,0) NOT NULL,
    can_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT can_estado_registro_ck CHECK (((can_estado_registro)::text = ANY (ARRAY[('INA'::character varying)::text, ('ACT'::character varying)::text])))
);


ALTER TABLE agn_canton OWNER TO esamyn_user;

--
-- TOC entry 2965 (class 0 OID 0)
-- Dependencies: 189
-- Name: TABLE agn_canton; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_canton IS 'Tabla que contiene la informacion de los cantones';


--
-- TOC entry 2966 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_codigo_canton; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_codigo_canton IS 'Campo que identifica la clave primaria de la tabla ';


--
-- TOC entry 2967 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_nombre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_nombre IS 'Campo que contiene el nombre del canton';


--
-- TOC entry 2968 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_estado_registro IS 'Campo que define el estado del registro ''ACT'',''INA''';


--
-- TOC entry 2969 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_codigo_provincia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_codigo_provincia IS 'Campo que hace referencia a la tabla asg_provincia';


--
-- TOC entry 2970 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 2971 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 2972 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 2973 (class 0 OID 0)
-- Dependencies: 189
-- Name: COLUMN agn_canton.can_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_canton.can_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 190 (class 1259 OID 34305)
-- Name: agn_catalogo; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_catalogo (
    cat_codigo_catalogo numeric(10,0) NOT NULL,
    cat_nombre character varying(250) NOT NULL,
    cat_descripcion character varying(250) NOT NULL,
    cat_identificador character varying(50) NOT NULL,
    cat_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    cat_codigo_migracion numeric(10,0) NOT NULL,
    cat_orden numeric(10,0),
    cat_codigo_catalogo_padre numeric(10,0),
    cat_fecha_creacion date NOT NULL,
    cat_fecha_modificacion date NOT NULL,
    cat_codigo_usuario_crea numeric(10,0) NOT NULL,
    cat_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((cat_estado_registro)::text = ANY (ARRAY[('INA'::character varying)::text, ('ACT'::character varying)::text])))
);


ALTER TABLE agn_catalogo OWNER TO esamyn_user;

--
-- TOC entry 2974 (class 0 OID 0)
-- Dependencies: 190
-- Name: TABLE agn_catalogo; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_catalogo IS 'Tabla que contiene los datos de catalogos';


--
-- TOC entry 2975 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_codigo_catalogo; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_codigo_catalogo IS 'Campo que define el secuencial de la tabla';


--
-- TOC entry 2976 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_nombre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_nombre IS 'Campo que define el nombre del catalogo';


--
-- TOC entry 2977 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_descripcion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_descripcion IS 'Campo que define la descripcion del catalogo';


--
-- TOC entry 2978 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_identificador; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_identificador IS 'Campo que define un identificador unico al catalogo';


--
-- TOC entry 2979 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_estado_registro IS 'Campo que define el estado del registro (''ACT'',''INA'')';


--
-- TOC entry 2980 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_codigo_migracion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_codigo_migracion IS 'Campo que define el identificador de migracion de los catalogos del MSP';


--
-- TOC entry 2981 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_orden; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_orden IS 'Campo que define el orden del catalogo';


--
-- TOC entry 2982 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_codigo_catalogo_padre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_codigo_catalogo_padre IS 'Campo que define el codigo padre de la tabla como recursiva';


--
-- TOC entry 2983 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 2984 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 2985 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 2986 (class 0 OID 0)
-- Dependencies: 190
-- Name: COLUMN agn_catalogo.cat_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_catalogo.cat_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 191 (class 1259 OID 34313)
-- Name: agn_distrito; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_distrito (
    dis_codigo_distrito numeric(10,0) NOT NULL,
    dis_nombre character varying(150) NOT NULL,
    dis_descripcion character varying(250),
    dis_identificador character varying(150),
    dis_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    dis_fecha_creacion date NOT NULL,
    dis_fecha_modificacion date NOT NULL,
    dis_codigo_usuario_crea numeric(10,0) NOT NULL,
    dis_codigo_usuario_modifica numeric(10,0) NOT NULL,
    dis_codigo_zona numeric(10,0) NOT NULL,
    CONSTRAINT dis_estado_registro_ck CHECK (((dis_estado_registro)::text = ANY (ARRAY[('INA'::character varying)::text, ('ACT'::character varying)::text])))
);


ALTER TABLE agn_distrito OWNER TO esamyn_user;

--
-- TOC entry 2987 (class 0 OID 0)
-- Dependencies: 191
-- Name: TABLE agn_distrito; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_distrito IS 'Tabla que contiene los datos del distrito';


--
-- TOC entry 2988 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_codigo_distrito; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_codigo_distrito IS 'Campo que corresponde a la clave primaria de la tabla';


--
-- TOC entry 2989 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_nombre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_nombre IS 'Campo que contiene el nombre del distrito';


--
-- TOC entry 2990 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_descripcion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_descripcion IS 'Campo que contiene la descripcion del distrito';


--
-- TOC entry 2991 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_identificador; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_identificador IS 'Campo que contiene el identificador del distrito';


--
-- TOC entry 2992 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_estado_registro IS 'Campo que contiene el estado del registro.';


--
-- TOC entry 2993 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_fecha_creacion IS 'Campo que define la fecha en la que se creo el registro';


--
-- TOC entry 2994 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_fecha_modificacion IS 'Campo  que define la fecha de modificacion del registro';


--
-- TOC entry 2995 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_codigo_usuario_crea IS 'Campo que identifica el usuario que creo el registro';


--
-- TOC entry 2996 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_codigo_usuario_modifica IS 'Campo que define el codigo de usuario que reliza la modificacion';


--
-- TOC entry 2997 (class 0 OID 0)
-- Dependencies: 191
-- Name: COLUMN agn_distrito.dis_codigo_zona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_distrito.dis_codigo_zona IS 'Campo que define el codigo de la zona';


--
-- TOC entry 192 (class 1259 OID 34321)
-- Name: agn_entidad; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_entidad (
    ent_codigo_entidad numeric(10,0) NOT NULL,
    ent_ruc character varying(20) NOT NULL,
    ent_razon_social character varying(250) NOT NULL,
    ent_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    ent_tipo_entidad character varying(3),
    ent_fecha_creacion date NOT NULL,
    ent_fecha_modificacion date NOT NULL,
    ent_codigo_usuario_crea numeric(10,0) NOT NULL,
    ent_codigo_usuario_modifica numeric(10,0) NOT NULL,
    ent_unicode character varying(250),
    ent_es_acess character varying(2) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((ent_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE agn_entidad OWNER TO esamyn_user;

--
-- TOC entry 2998 (class 0 OID 0)
-- Dependencies: 192
-- Name: TABLE agn_entidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_entidad IS 'Estructura que almacena la informacion de empresas e intituciones';


--
-- TOC entry 2999 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_codigo_entidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_codigo_entidad IS 'Campo que hace referencia a la secuencia asg_seq_institucion';


--
-- TOC entry 3000 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_ruc; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_ruc IS 'Csmpo que define el numero de ruc de la institucion';


--
-- TOC entry 3001 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_razon_social; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_razon_social IS 'Campo que almacena la razon social de la instucion';


--
-- TOC entry 3002 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_estado_registro IS 'Campo que define el estado del registro';


--
-- TOC entry 3003 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_tipo_entidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_tipo_entidad IS 'Campo que almacen el tipo de entidad. Permite los tipos ''PRI'' para privada,''PUB'' para publica.';


--
-- TOC entry 3004 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3005 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3006 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3007 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 3008 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_unicode; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_unicode IS 'Campo unicode correspondiente al RUES';


--
-- TOC entry 3009 (class 0 OID 0)
-- Dependencies: 192
-- Name: COLUMN agn_entidad.ent_es_acess; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_entidad.ent_es_acess IS 'Campo que identifica si la entidad es acess o otra institucion o empresa';


--
-- TOC entry 193 (class 1259 OID 34329)
-- Name: agn_establecimiento; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_establecimiento (
    est_codigo_establecimiento numeric(10,0) NOT NULL,
    est_nombre_comercial character varying(250) NOT NULL,
    est_numero_establecimiento character varying(10),
    est_direccion character varying(250) NOT NULL,
    est_telefono character varying(10),
    est_codigo_parroquia numeric(10,0) NOT NULL,
    est_latitud character varying(50),
    est_longitud character varying(50),
    est_mail character varying(150),
    est_paginaweb character varying(150),
    est_barrio character varying(150),
    est_direccion_referencia character varying(150),
    est_actividad_principal character varying(150),
    est_codigo_distrito numeric(10,0) NOT NULL,
    est_fecha_creacion date NOT NULL,
    est_codigo_usuario_crea numeric(10,0) NOT NULL,
    est_fecha_modificacion date,
    est_codigo_usuario_modifica numeric(10,0),
    est_matriz character varying(2) NOT NULL,
    est_codigo_entidad numeric(10,0),
    CONSTRAINT esmatrizck CHECK (((est_matriz)::text = ANY (ARRAY[('SI'::character varying)::text, ('NO'::character varying)::text])))
);


ALTER TABLE agn_establecimiento OWNER TO esamyn_user;

--
-- TOC entry 3010 (class 0 OID 0)
-- Dependencies: 193
-- Name: TABLE agn_establecimiento; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_establecimiento IS 'Tabla que contiene los datos de establecimiento';


--
-- TOC entry 3011 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_codigo_establecimiento; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_codigo_establecimiento IS 'Campo que almacena la clave primaria';


--
-- TOC entry 3012 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_nombre_comercial; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_nombre_comercial IS 'Campo que almacena el nombre comercial del establecimiento';


--
-- TOC entry 3013 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_numero_establecimiento; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_numero_establecimiento IS 'Campo que almacena el numero de establecimiento';


--
-- TOC entry 3014 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_direccion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_direccion IS 'Campo que almacena la direccion del establecimiento';


--
-- TOC entry 3015 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_telefono; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_telefono IS 'Campo que almacena el telefono del establecimiento';


--
-- TOC entry 3016 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_codigo_parroquia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_codigo_parroquia IS 'Campo que almacena el codigo de la parroquia';


--
-- TOC entry 3017 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_latitud; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_latitud IS 'Campo que almacena la informacion de ubicacion geografica en latitud';


--
-- TOC entry 3018 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_longitud; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_longitud IS 'Campo que almacena la ubicacion geografica en longitud';


--
-- TOC entry 3019 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_mail; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_mail IS 'Campo que almacena la direccion de correo electronico';


--
-- TOC entry 3020 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_paginaweb; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_paginaweb IS 'Campo que almacena la url de la pagina web';


--
-- TOC entry 3021 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_barrio; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_barrio IS 'Campo que almacena el nombre del barrio del establecimiento';


--
-- TOC entry 3022 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_direccion_referencia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_direccion_referencia IS 'Campo que almacena la direccion de referencia del establecimiento';


--
-- TOC entry 3023 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_actividad_principal; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_actividad_principal IS 'Campo que almacena la actividad principal del establecimiento';


--
-- TOC entry 3024 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_codigo_distrito; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_codigo_distrito IS 'Campo que almacena el codigo del distrito';


--
-- TOC entry 3025 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_fecha_creacion IS 'Campo que almacena la fecha del registro';


--
-- TOC entry 3026 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_codigo_usuario_crea IS 'Campo que almacena el codigo del usuario que crea el registro';


--
-- TOC entry 3027 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_fecha_modificacion IS 'Campo que almacena la fecha en la cual se modifico el registro';


--
-- TOC entry 3028 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_codigo_usuario_modifica IS 'Campo que almacena el codigo del usuario que modifica el registro';


--
-- TOC entry 3029 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_matriz; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_matriz IS 'Campo que identifica si el establecimiento es matriz o no. Permite ''SI'', ''NO''';


--
-- TOC entry 3030 (class 0 OID 0)
-- Dependencies: 193
-- Name: COLUMN agn_establecimiento.est_codigo_entidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_establecimiento.est_codigo_entidad IS 'Campo que almacena la referencia a la tabla entidad';


--
-- TOC entry 194 (class 1259 OID 34336)
-- Name: agn_parametro_general; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_parametro_general (
    pgn_codigo_parametro_general numeric(10,0) NOT NULL,
    pgn_nombre_parametro character varying(100) NOT NULL,
    pgn_valor_parametro character varying(250) NOT NULL,
    pgn_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    pgn_identificador_parametro character varying(50),
    pgn_fecha_creacion date NOT NULL,
    pgn_fecha_modificacion date NOT NULL,
    pgn_codigo_usuario_crea numeric(10,0) NOT NULL,
    pgn_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((pgn_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE agn_parametro_general OWNER TO esamyn_user;

--
-- TOC entry 3031 (class 0 OID 0)
-- Dependencies: 194
-- Name: TABLE agn_parametro_general; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_parametro_general IS 'Estructura que almacena los parametros generales de las aplicaciones';


--
-- TOC entry 3032 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_codigo_parametro_general; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_codigo_parametro_general IS 'Campo que hace referencia a la secuencia asg_seq_parametro_general';


--
-- TOC entry 3033 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_nombre_parametro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_nombre_parametro IS 'Campo que define el nombre del parametro';


--
-- TOC entry 3034 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_valor_parametro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_valor_parametro IS 'Campo que define el valor del parametro';


--
-- TOC entry 3035 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_estado_registro IS 'Campo que defien el estado del registro';


--
-- TOC entry 3036 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_identificador_parametro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_identificador_parametro IS 'Campo que ayuda a la identificacion del registro dentro de parametros';


--
-- TOC entry 3037 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3038 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3039 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3040 (class 0 OID 0)
-- Dependencies: 194
-- Name: COLUMN agn_parametro_general.pgn_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parametro_general.pgn_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 195 (class 1259 OID 34341)
-- Name: agn_parroquia; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_parroquia (
    par_codigo_parroquia numeric(10,0) NOT NULL,
    par_nombre character varying(250) NOT NULL,
    par_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    par_codigo_canton numeric(10,0) NOT NULL,
    par_fecha_creacion date NOT NULL,
    par_fecha_modificacion date NOT NULL,
    par_codigo_usuario_crea numeric(10,0) NOT NULL,
    par_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT asg_estado_registro_ck CHECK (((par_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE agn_parroquia OWNER TO esamyn_user;

--
-- TOC entry 3041 (class 0 OID 0)
-- Dependencies: 195
-- Name: TABLE agn_parroquia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_parroquia IS 'Tabla que contiene la informacion de parroquias';


--
-- TOC entry 3042 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_codigo_parroquia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_codigo_parroquia IS 'Capo que define la clave primaria de la tabla';


--
-- TOC entry 3043 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_nombre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_nombre IS 'Campo que define el nombre de la parroquia';


--
-- TOC entry 3044 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_estado_registro IS 'Campo que define el estado del registro';


--
-- TOC entry 3045 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_codigo_canton; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_codigo_canton IS 'campo que hace referencia a la tabla asg_canton';


--
-- TOC entry 3046 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3047 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3048 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3049 (class 0 OID 0)
-- Dependencies: 195
-- Name: COLUMN agn_parroquia.par_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_parroquia.par_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 196 (class 1259 OID 34346)
-- Name: agn_persona; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_persona (
    per_codigo_persona numeric(10,0) NOT NULL,
    per_numero_identificacion character varying(20) NOT NULL,
    per_nombres character varying(150) NOT NULL,
    per_apellidos character varying(150) NOT NULL,
    per_direccion character varying(250),
    per_telefono character varying(20),
    per_celular character varying(20),
    per_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    per_genero character varying(1),
    per_codigo_migracion numeric(10,0),
    per_codigo_parroquia numeric(10,0),
    per_lugar_nacimiento character varying(150),
    per_fecha_nacimiento date,
    per_codigo_cat_nacionalidad numeric(10,0),
    per_codigo_cat_estado_civil numeric(10,0),
    per_codigo_cat_etnia numeric(10,0),
    per_codigo_cat_nacionalidad_org numeric(10,0),
    per_codigo_cat_pueblo numeric(10,0),
    per_codigo_cat_tipo_entidad numeric(10,0),
    per_fecha_creacion date NOT NULL,
    per_fecha_modificacion date NOT NULL,
    per_codigo_usuario_crea numeric(10,0) NOT NULL,
    per_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((per_estado_registro)::text = ANY (ARRAY[('INA'::character varying)::text, ('ACT'::character varying)::text])))
);


ALTER TABLE agn_persona OWNER TO esamyn_user;

--
-- TOC entry 3050 (class 0 OID 0)
-- Dependencies: 196
-- Name: TABLE agn_persona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_persona IS 'Estructura que almacena la informacion de las personas';


--
-- TOC entry 3051 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_persona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_persona IS 'Campo que define la secuencia de la tabla';


--
-- TOC entry 3052 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_numero_identificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_numero_identificacion IS 'Campo que contiene la información del numero de identificacion de la persona';


--
-- TOC entry 3053 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_nombres; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_nombres IS 'Campo que define el nombre de la persona';


--
-- TOC entry 3054 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_apellidos; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_apellidos IS 'Campo que contiene los apellidos de la persona';


--
-- TOC entry 3055 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_direccion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_direccion IS 'Campo que define la direccion de domicilio de la persona';


--
-- TOC entry 3056 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_telefono; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_telefono IS 'Campo que almacena la informacion del telefono de la persona';


--
-- TOC entry 3057 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_celular; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_celular IS 'Campo que almacena la informacion del telefono celular de la persona';


--
-- TOC entry 3058 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_estado_registro IS 'Campo que defien si un registro es activo o inactivo';


--
-- TOC entry 3059 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_genero; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_genero IS 'Campo que define el genero de la persona';


--
-- TOC entry 3060 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_migracion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_migracion IS 'Campo que define el codigo de la migracion de las tablas del MSP';


--
-- TOC entry 3061 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_parroquia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_parroquia IS 'Campo que hace referencia a la tabla agn_parroquia';


--
-- TOC entry 3062 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_lugar_nacimiento; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_lugar_nacimiento IS 'Campo que contiene la descripcion del lugar de nacimiento';


--
-- TOC entry 3063 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_fecha_nacimiento; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_fecha_nacimiento IS 'Campo que contiene la fecha de nacimiento';


--
-- TOC entry 3064 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_cat_nacionalidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_cat_nacionalidad IS 'Campo que contiene los datos de las nacionalidades de personas como (Awá , Chachi , Epera entre otros). Este esta relacionado a la tabla agn_catalogo';


--
-- TOC entry 3065 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_cat_estado_civil; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_cat_estado_civil IS 'Campo que define el estado civil de la persona. Relacion con la tabla agn_catalogo';


--
-- TOC entry 3066 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_cat_etnia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_cat_etnia IS 'Campo que hace referencia a la etnia de una persona. Referencia a la tabla agn_catalogo';


--
-- TOC entry 3067 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_cat_nacionalidad_org; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_cat_nacionalidad_org IS 'Campo que define la nacionalidad de origen (Colombiana, Ecuatoriana, Peruana entre otros). Referencia a la tabla agn_catalogo';


--
-- TOC entry 3068 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_cat_pueblo; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_cat_pueblo IS 'Campo que hace referencia a la tabla agn_catalogo. ';


--
-- TOC entry 3069 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_cat_tipo_entidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_cat_tipo_entidad IS 'Campo que hace referencia a la tabla agn_catalogo';


--
-- TOC entry 3070 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3071 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3072 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3073 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN agn_persona.per_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_persona.per_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 197 (class 1259 OID 34354)
-- Name: agn_provincia; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_provincia (
    pro_codigo_provincia numeric(10,0) NOT NULL,
    pro_nombre character varying(150),
    pro_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    pro_fecha_creacion date NOT NULL,
    pro_fecha_modificacion date NOT NULL,
    pro_codigo_usuario_crea numeric(10,0) NOT NULL,
    pro_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT asg_estado_registro_ck CHECK (((pro_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE agn_provincia OWNER TO esamyn_user;

--
-- TOC entry 3074 (class 0 OID 0)
-- Dependencies: 197
-- Name: TABLE agn_provincia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_provincia IS 'Tabla que almacena los datos de provincias';


--
-- TOC entry 3075 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_codigo_provincia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_codigo_provincia IS 'Campo que define la clave primaria';


--
-- TOC entry 3076 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_nombre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_nombre IS 'Campo que hace referencia al nombre de la provincia';


--
-- TOC entry 3077 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_estado_registro IS 'Campo que define el estado del registro. Permite ACT, INA';


--
-- TOC entry 3078 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3079 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3080 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3081 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN agn_provincia.pro_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_provincia.pro_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 198 (class 1259 OID 34359)
-- Name: agn_seq_canton; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_canton
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_canton OWNER TO esamyn_user;

--
-- TOC entry 3082 (class 0 OID 0)
-- Dependencies: 198
-- Name: SEQUENCE agn_seq_canton; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_canton IS 'Secuencia que pertenece a la tabla agn_canton';


--
-- TOC entry 199 (class 1259 OID 34361)
-- Name: agn_seq_catalogo; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_catalogo
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_catalogo OWNER TO esamyn_user;

--
-- TOC entry 3083 (class 0 OID 0)
-- Dependencies: 199
-- Name: SEQUENCE agn_seq_catalogo; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_catalogo IS 'Secuencia que pertenece a la tabla agn_catalogo';


--
-- TOC entry 200 (class 1259 OID 34363)
-- Name: agn_seq_distrito; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_distrito
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_distrito OWNER TO esamyn_user;

--
-- TOC entry 3084 (class 0 OID 0)
-- Dependencies: 200
-- Name: SEQUENCE agn_seq_distrito; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_distrito IS 'Secuencia que pertenece a la tabla agn_distrito';


--
-- TOC entry 201 (class 1259 OID 34365)
-- Name: agn_seq_entidad; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_entidad
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_entidad OWNER TO esamyn_user;

--
-- TOC entry 3085 (class 0 OID 0)
-- Dependencies: 201
-- Name: SEQUENCE agn_seq_entidad; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_entidad IS 'Secuencia que pertenece a la tabla agn_institucion';


--
-- TOC entry 202 (class 1259 OID 34367)
-- Name: agn_seq_establecimiento; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_establecimiento
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_establecimiento OWNER TO esamyn_user;

--
-- TOC entry 3086 (class 0 OID 0)
-- Dependencies: 202
-- Name: SEQUENCE agn_seq_establecimiento; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_establecimiento IS 'Secuencia que pertenece a la tabla agn_establecimiento';


--
-- TOC entry 203 (class 1259 OID 34369)
-- Name: agn_seq_parametro_general; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_parametro_general
    START WITH 1
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999
    CACHE 1;


ALTER TABLE agn_seq_parametro_general OWNER TO esamyn_user;

--
-- TOC entry 3087 (class 0 OID 0)
-- Dependencies: 203
-- Name: SEQUENCE agn_seq_parametro_general; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_parametro_general IS 'Secuencia que pertenece a la tabla agn_parametro_general';


--
-- TOC entry 204 (class 1259 OID 34371)
-- Name: agn_seq_parroquia; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_parroquia
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_parroquia OWNER TO esamyn_user;

--
-- TOC entry 3088 (class 0 OID 0)
-- Dependencies: 204
-- Name: SEQUENCE agn_seq_parroquia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_parroquia IS 'Secuencia que hace referencia a la tabla parroquia';


--
-- TOC entry 205 (class 1259 OID 34373)
-- Name: agn_seq_persona; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_persona
    START WITH 1
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_persona OWNER TO esamyn_user;

--
-- TOC entry 3089 (class 0 OID 0)
-- Dependencies: 205
-- Name: SEQUENCE agn_seq_persona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_persona IS 'Secuencia que hace referencia a la tabla agn_persona';


--
-- TOC entry 206 (class 1259 OID 34375)
-- Name: agn_seq_provincia; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_provincia
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_provincia OWNER TO esamyn_user;

--
-- TOC entry 3090 (class 0 OID 0)
-- Dependencies: 206
-- Name: SEQUENCE agn_seq_provincia; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_provincia IS 'Secuencia para la tabla agn_provincia';


--
-- TOC entry 207 (class 1259 OID 34377)
-- Name: agn_seq_zona; Type: SEQUENCE; Schema: administracion_general; Owner: esamyn_user
--

CREATE SEQUENCE agn_seq_zona
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE agn_seq_zona OWNER TO esamyn_user;

--
-- TOC entry 3091 (class 0 OID 0)
-- Dependencies: 207
-- Name: SEQUENCE agn_seq_zona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON SEQUENCE agn_seq_zona IS 'Secuencia que pertenece a la tabla agn_zona';


--
-- TOC entry 208 (class 1259 OID 34379)
-- Name: agn_zona; Type: TABLE; Schema: administracion_general; Owner: esamyn_user
--

CREATE TABLE agn_zona (
    zon_codigo_zona numeric(10,0) NOT NULL,
    zon_nombre character varying(150) NOT NULL,
    zon_descripcion character varying(250) NOT NULL,
    zon_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    zon_fecha_creacion date NOT NULL,
    zon_fecha_modificacion date NOT NULL,
    zon_codigo_usuario_crea numeric(10,0) NOT NULL,
    zon_codigo_usuario_modifica numeric(10,0) NOT NULL,
    zon_identificador character varying(10),
    CONSTRAINT zona_estado_registro_ck CHECK (((zon_estado_registro)::text = ANY (ARRAY[('INA'::character varying)::text, ('ACT'::character varying)::text])))
);


ALTER TABLE agn_zona OWNER TO esamyn_user;

--
-- TOC entry 3092 (class 0 OID 0)
-- Dependencies: 208
-- Name: TABLE agn_zona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON TABLE agn_zona IS 'Tabla que coniene la informacion de zonas';


--
-- TOC entry 3093 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_codigo_zona; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_codigo_zona IS 'Campo que corresponde a la clave primaria';


--
-- TOC entry 3094 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_nombre; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_nombre IS 'Campo que contiene el nombre de la zona';


--
-- TOC entry 3095 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_descripcion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_descripcion IS 'Campo que contiene la descripcion de la zona';


--
-- TOC entry 3096 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_estado_registro; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_estado_registro IS 'Campo que define el estado del registro';


--
-- TOC entry 3097 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_fecha_creacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_fecha_creacion IS 'Campo que contiene la fecha de creacion del registro';


--
-- TOC entry 3098 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_fecha_modificacion; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3099 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_codigo_usuario_crea; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el registro';


--
-- TOC entry 3100 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_codigo_usuario_modifica IS 'Campo que contiene el codigo del del usuario que modifica';


--
-- TOC entry 3101 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN agn_zona.zon_identificador; Type: COMMENT; Schema: administracion_general; Owner: esamyn_user
--

COMMENT ON COLUMN agn_zona.zon_identificador IS 'Campo que contiene un identificador de la zona';


SET search_path = administracion_seguridad, pg_catalog;

--
-- TOC entry 209 (class 1259 OID 34384)
-- Name: asg_aplicacion; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_aplicacion (
    apl_codigo_aplicacion numeric(10,0) NOT NULL,
    apl_nombre_aplicacion character varying(250) NOT NULL,
    apl_url character varying(250) NOT NULL,
    apl_estado_registro character varying(3) NOT NULL,
    apl_identificador character varying(50) NOT NULL,
    apl_fecha_creacion date NOT NULL,
    apl_fecha_modificacion date NOT NULL,
    apl_codigo_usuario_crea numeric(10,0) NOT NULL,
    apl_codigo_usuario_modifica numeric(10,0) NOT NULL,
    apl_tipo character varying(10) NOT NULL,
    apl_codigo_cat_proceso numeric(10,0),
    CONSTRAINT estado_registro_ck CHECK (((apl_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text]))),
    CONSTRAINT tipo_aplicacion_ck CHECK (((apl_tipo)::text = ANY (ARRAY[('INTERNA'::character varying)::text, ('EXTERNA'::character varying)::text])))
);


ALTER TABLE asg_aplicacion OWNER TO esamyn_user;

--
-- TOC entry 3102 (class 0 OID 0)
-- Dependencies: 209
-- Name: TABLE asg_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_aplicacion IS 'Estructura que almacena la informacion de las aplicaciones existentes';


--
-- TOC entry 3103 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_codigo_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_codigo_aplicacion IS 'Campo que hace referencia a la secuencia asg_seq_aplicacion';


--
-- TOC entry 3104 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_nombre_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_nombre_aplicacion IS 'Campo que define el nombre de la aplicacion';


--
-- TOC entry 3105 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_url; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_url IS 'Campo que define la URL de la aplicacion';


--
-- TOC entry 3106 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_estado_registro IS 'Campo que define el estado del registro. Permite ACT, INA';


--
-- TOC entry 3107 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_identificador; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_identificador IS 'Campo que define un identificador unico para la aplicacion';


--
-- TOC entry 3108 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3109 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3110 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3111 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 3112 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_tipo; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_tipo IS 'Campo que define si una aplicacion es externa o interna';


--
-- TOC entry 3113 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN asg_aplicacion.apl_codigo_cat_proceso; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_aplicacion.apl_codigo_cat_proceso IS 'Campo que hace referencia a la tabla asg_catalogo. Define a que proceso pertenece. Ejemplo HABILITACION, CERTIFICIACION..';


--
-- TOC entry 210 (class 1259 OID 34392)
-- Name: asg_menu; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_menu (
    men_codigo_menu numeric(10,0) NOT NULL,
    men_etiqueta character varying(200) NOT NULL,
    men_nombre_opcion character varying(150) NOT NULL,
    men_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    men_codigo_menu_padre numeric(10,0),
    men_nivel numeric(2,0) DEFAULT 1 NOT NULL,
    men_icono character varying(50),
    men_codigo_aplicacion numeric(10,0) NOT NULL,
    men_orden numeric(3,0) NOT NULL,
    men_ruta character varying(250),
    men_fecha_creacion date NOT NULL,
    men_fecha_modificacion date NOT NULL,
    men_codigo_usuario_crea numeric(10,0) NOT NULL,
    men_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((men_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE asg_menu OWNER TO esamyn_user;

--
-- TOC entry 3114 (class 0 OID 0)
-- Dependencies: 210
-- Name: TABLE asg_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_menu IS 'Estructura que almacena la informacion referente a las opciones de una aplicacion';


--
-- TOC entry 3115 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_codigo_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_codigo_menu IS 'Campo que hace referencia a la secuencia asg_seq_menu';


--
-- TOC entry 3116 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_etiqueta; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_etiqueta IS 'Campo que define el nombre de la etiqueta a mostrar en el menu del sistema';


--
-- TOC entry 3117 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_nombre_opcion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_nombre_opcion IS 'Campo que define el nombre de la opcion para redireccionar pagina';


--
-- TOC entry 3118 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_estado_registro IS 'Campo que define el estado del registro. Permite ACT,INA';


--
-- TOC entry 3119 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_codigo_menu_padre; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_codigo_menu_padre IS 'Campo que define el codigo de menu padre por la recursividad';


--
-- TOC entry 3120 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_nivel; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_nivel IS 'Campo que defiene el nivel de menu ';


--
-- TOC entry 3121 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_icono; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_icono IS 'Campo que define el icono a mostrar en el menu';


--
-- TOC entry 3122 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_codigo_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_codigo_aplicacion IS 'Campo que hace referencia a la tabla asg_aplicacion';


--
-- TOC entry 3123 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_orden; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_orden IS 'Campo que define el orden como se mostrara el menu en la aplicacion';


--
-- TOC entry 3124 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_ruta; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_ruta IS 'Campo que almacena la ruta de la pantalla';


--
-- TOC entry 3125 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3126 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3127 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3128 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN asg_menu.men_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_menu.men_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 211 (class 1259 OID 34401)
-- Name: asg_perfil; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_perfil (
    prl_codigo_perfil numeric(10,0) NOT NULL,
    prl_nombre_perfil character varying(150) NOT NULL,
    prl_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    prl_fecha_creacion date NOT NULL,
    prl_fecha_modificacion date NOT NULL,
    prl_codigo_usuario_crea numeric(10,0) NOT NULL,
    prl_codigo_usuario_modifica numeric(10,0) NOT NULL,
    prl_codigo_aplicacion numeric(10,0) NOT NULL,
    prl_asignar_defecto character varying(2) NOT NULL,
    CONSTRAINT asignar_defecto_ck CHECK (((prl_asignar_defecto)::text = ANY (ARRAY[('SI'::character varying)::text, ('NO'::character varying)::text]))),
    CONSTRAINT estado_registro_ck CHECK (((prl_estado_registro)::text = ANY (ARRAY[('INA'::character varying)::text, ('ACT'::character varying)::text])))
);


ALTER TABLE asg_perfil OWNER TO esamyn_user;

--
-- TOC entry 3129 (class 0 OID 0)
-- Dependencies: 211
-- Name: TABLE asg_perfil; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_perfil IS 'Tabla que almacena los perfiles de usuario';


--
-- TOC entry 3130 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_codigo_perfil; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_codigo_perfil IS 'Campo que define la clave primaria de la tabla';


--
-- TOC entry 3131 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_nombre_perfil; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_nombre_perfil IS 'Campo que define el nombre del perfil';


--
-- TOC entry 3132 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_estado_registro IS 'Campo que define el estado del registro. Permite ''INA'', ''ACT''';


--
-- TOC entry 3133 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3134 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_fecha_modificacion IS 'Campo que contiene la fecha de modificacion del registro';


--
-- TOC entry 3135 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3136 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_codigo_usuario_modifica IS 'Campo que contiene el codigo del usuario que modifico el regitro';


--
-- TOC entry 3137 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_codigo_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_codigo_aplicacion IS 'Campo que hace referencia a la tabla asg_aplicacion';


--
-- TOC entry 3138 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN asg_perfil.prl_asignar_defecto; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_perfil.prl_asignar_defecto IS 'Campo que almacena la informacion para determininar si el perfil es asignado por defecto. Permite SI y NO.';


--
-- TOC entry 212 (class 1259 OID 34407)
-- Name: asg_rol; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_rol (
    rol_codigo_rol numeric(10,0) NOT NULL,
    rol_nombre character varying(120) NOT NULL,
    rol_estado_registro character varying(3) NOT NULL,
    rol_codigo_aplicacion numeric(10,0) NOT NULL,
    rol_descripcion character varying(150),
    rol_fecha_creacion date NOT NULL,
    rol_fecha_modificacion date NOT NULL,
    rol_codigo_usuario_crea numeric(10,0) NOT NULL,
    rol_codigo_usuario_modifica numeric(10,0) NOT NULL,
    rol_codigo_perfil numeric(10,0),
    CONSTRAINT estado_registro_ck CHECK (((rol_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE asg_rol OWNER TO esamyn_user;

--
-- TOC entry 3139 (class 0 OID 0)
-- Dependencies: 212
-- Name: TABLE asg_rol; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_rol IS 'Estructura que almacena la informacion de los roles ';


--
-- TOC entry 3140 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_codigo_rol; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_codigo_rol IS 'Campo que hace referencia a la secuencia asg_seq_rol';


--
-- TOC entry 3141 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_nombre; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_nombre IS 'Campo que define el nombre del rol';


--
-- TOC entry 3142 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_estado_registro IS 'Campo que define el estado del registro activo o inactiva. Permite ACT, INA';


--
-- TOC entry 3143 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_codigo_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_codigo_aplicacion IS 'campo que hace referencia a la tabla asg_aplicacion';


--
-- TOC entry 3144 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_descripcion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_descripcion IS 'Campo que contiene la descripcion del catalogo';


--
-- TOC entry 3145 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3146 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3147 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3148 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 3149 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN asg_rol.rol_codigo_perfil; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol.rol_codigo_perfil IS 'Campo que contiene el codigo del perfil que hace referencia a la tabla ''asg_perfil''';


--
-- TOC entry 213 (class 1259 OID 34411)
-- Name: asg_rol_menu; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_rol_menu (
    rmn_codigo_rol_menu numeric(10,0) NOT NULL,
    rmn_codigo_rol numeric(10,0) NOT NULL,
    rmn_codigo_menu numeric(10,0) NOT NULL,
    rmn_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    rmn_fecha_creacion date NOT NULL,
    rmn_fecha_modificacion date NOT NULL,
    rmn_codigo_usuario_crea numeric(10,0) NOT NULL,
    rmn_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((rmn_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE asg_rol_menu OWNER TO esamyn_user;

--
-- TOC entry 3150 (class 0 OID 0)
-- Dependencies: 213
-- Name: TABLE asg_rol_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_rol_menu IS 'Estructura que almacena la infomacion del menu que tiene permisos el rol';


--
-- TOC entry 3151 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_codigo_rol_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_codigo_rol_menu IS 'Campo que hace referencia a la secuencia asg_seq_rol_menu';


--
-- TOC entry 3152 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_codigo_rol; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_codigo_rol IS 'Campo que define la relacion con la tabla asg_rol';


--
-- TOC entry 3153 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_codigo_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_codigo_menu IS 'Campo que hace referencia a la tabla asg_menu';


--
-- TOC entry 3154 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_estado_registro IS 'Campo que define el estado del registro. Permite ACT,INA';


--
-- TOC entry 3155 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3156 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3157 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3158 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN asg_rol_menu.rmn_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_rol_menu.rmn_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 214 (class 1259 OID 34416)
-- Name: asg_seq_aplicacion; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_aplicacion
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_aplicacion OWNER TO esamyn_user;

--
-- TOC entry 3159 (class 0 OID 0)
-- Dependencies: 214
-- Name: SEQUENCE asg_seq_aplicacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_aplicacion IS 'Secuencia que pertenece a la tabla asg_aplicacion';


--
-- TOC entry 215 (class 1259 OID 34418)
-- Name: asg_seq_menu; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_menu
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_menu OWNER TO esamyn_user;

--
-- TOC entry 3160 (class 0 OID 0)
-- Dependencies: 215
-- Name: SEQUENCE asg_seq_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_menu IS 'Secuencia que pertenece a la tabla menu';


--
-- TOC entry 216 (class 1259 OID 34420)
-- Name: asg_seq_rol; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_rol
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_rol OWNER TO esamyn_user;

--
-- TOC entry 3161 (class 0 OID 0)
-- Dependencies: 216
-- Name: SEQUENCE asg_seq_rol; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_rol IS 'Secuencia que pertenece a la tabla asg_rol';


--
-- TOC entry 217 (class 1259 OID 34422)
-- Name: asg_seq_rol_menu; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_rol_menu
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_rol_menu OWNER TO esamyn_user;

--
-- TOC entry 3162 (class 0 OID 0)
-- Dependencies: 217
-- Name: SEQUENCE asg_seq_rol_menu; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_rol_menu IS 'Secuencia que pertence a la tabla asg_rol_aplicacion';


--
-- TOC entry 218 (class 1259 OID 34424)
-- Name: asg_seq_usuario; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_usuario
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_usuario OWNER TO esamyn_user;

--
-- TOC entry 3163 (class 0 OID 0)
-- Dependencies: 218
-- Name: SEQUENCE asg_seq_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_usuario IS 'Secuencia que pertenece a la tabla asg_menu';


--
-- TOC entry 219 (class 1259 OID 34426)
-- Name: asg_seq_usuario_institucion; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_usuario_institucion
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_usuario_institucion OWNER TO esamyn_user;

--
-- TOC entry 3164 (class 0 OID 0)
-- Dependencies: 219
-- Name: SEQUENCE asg_seq_usuario_institucion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_usuario_institucion IS 'Secuencia que pertenece a la tabla asg_usuario_institucion';


--
-- TOC entry 220 (class 1259 OID 34428)
-- Name: asg_seq_usuario_logueado; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_usuario_logueado
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 9999999999
    CACHE 1;


ALTER TABLE asg_seq_usuario_logueado OWNER TO esamyn_user;

--
-- TOC entry 3165 (class 0 OID 0)
-- Dependencies: 220
-- Name: SEQUENCE asg_seq_usuario_logueado; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_usuario_logueado IS 'Secuencia que pertenece a la tabla asg_usuario_logueado';


--
-- TOC entry 221 (class 1259 OID 34430)
-- Name: asg_seq_usuario_rol; Type: SEQUENCE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE SEQUENCE asg_seq_usuario_rol
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE asg_seq_usuario_rol OWNER TO esamyn_user;

--
-- TOC entry 3166 (class 0 OID 0)
-- Dependencies: 221
-- Name: SEQUENCE asg_seq_usuario_rol; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON SEQUENCE asg_seq_usuario_rol IS 'Campo que pertence a la tabla asg_usuario_rol';


--
-- TOC entry 222 (class 1259 OID 34432)
-- Name: asg_usuario; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_usuario (
    usu_codigo_usuario numeric(10,0) NOT NULL,
    usu_nombre_usuario character varying(120) NOT NULL,
    usu_contrasenia character varying(120) NOT NULL,
    usu_fecha_creacion date NOT NULL,
    usu_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    usu_codigo_persona numeric(10,0),
    usu_usuario_interno character varying(3) DEFAULT 'SI'::character varying NOT NULL,
    usu_identificador_migracion character varying(10),
    usu_correo_electronico character varying(120),
    usu_fecha_modificacion date NOT NULL,
    usu_codigo_usuario_crea numeric(10,0) NOT NULL,
    usu_codigo_usuario_modifica numeric(10,0) NOT NULL,
    usu_origen_registro character varying(10) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((usu_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text]))),
    CONSTRAINT usuario_interno_ck CHECK (((usu_usuario_interno)::text = ANY (ARRAY[('SI'::character varying)::text, ('NO'::character varying)::text])))
);


ALTER TABLE asg_usuario OWNER TO esamyn_user;

--
-- TOC entry 3167 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE asg_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_usuario IS 'Estructura que almacena la información de usuarios internos y externos';


--
-- TOC entry 3168 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_codigo_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_codigo_usuario IS 'Campo que hace referencia a la secuencia asg_seq_usuario';


--
-- TOC entry 3169 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_nombre_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_nombre_usuario IS 'Campo que almacena el nombre de usuario';


--
-- TOC entry 3170 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_contrasenia; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_contrasenia IS 'Campo que define la contraseña del usuario';


--
-- TOC entry 3171 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_fecha_creacion IS 'Campo que define la fhecha de creacion de usuario';


--
-- TOC entry 3172 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_estado_registro IS 'Campo que define el estado del registro. Permite INA, ACT';


--
-- TOC entry 3173 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_codigo_persona; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_codigo_persona IS 'Campo que hace referencia a la tabla asp_persona';


--
-- TOC entry 3174 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_usuario_interno; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_usuario_interno IS 'Campo que define si un usuario es interno o externo';


--
-- TOC entry 3175 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_identificador_migracion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_identificador_migracion IS 'Campo que define como ayuda para la migracion de datos del MSP';


--
-- TOC entry 3176 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_correo_electronico; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_correo_electronico IS 'Campo que almacena la direccion del correo electronico';


--
-- TOC entry 3177 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3178 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3179 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 3180 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN asg_usuario.usu_origen_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario.usu_origen_registro IS 'Campo que define el origen del registro del usuario. Permite ''INT''  y ''EXT''';


--
-- TOC entry 223 (class 1259 OID 34439)
-- Name: asg_usuario_establecimiento; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_usuario_establecimiento (
    uit_codigo_usuario_entidad numeric(10,0) NOT NULL,
    uit_codigo_usuario numeric(10,0) NOT NULL,
    uit_estado_registro character varying(3),
    uit_codigo_establecimiento numeric(10,0) NOT NULL,
    uit_fecha_creacion date NOT NULL,
    uit_fecha_modificacion date NOT NULL,
    uit_codigo_usuario_crea numeric(10,0) NOT NULL,
    uit_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((uit_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE asg_usuario_establecimiento OWNER TO esamyn_user;

--
-- TOC entry 3181 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE asg_usuario_establecimiento; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_usuario_establecimiento IS 'Estructura que almacena los datos de la union entre las tablas usuario y establecimiento';


--
-- TOC entry 3182 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_codigo_usuario_entidad; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_codigo_usuario_entidad IS 'Campo que hace referencia a la secuencia asg_seq_usuario_institucion';


--
-- TOC entry 3183 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_codigo_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_codigo_usuario IS 'Campo que hace referencia a la tabla usuario';


--
-- TOC entry 3184 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_estado_registro IS 'Campo que define el estado del registro';


--
-- TOC entry 3185 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_codigo_establecimiento; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_codigo_establecimiento IS 'Campo que hace referencia a la tabla agn_establecimiento';


--
-- TOC entry 3186 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3187 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3188 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3189 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN asg_usuario_establecimiento.uit_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_establecimiento.uit_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 224 (class 1259 OID 34443)
-- Name: asg_usuario_logueado; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_usuario_logueado (
    ulg_codigo_usuario_logueado numeric(10,0) NOT NULL,
    ulg_codigo_usuario numeric(10,0) NOT NULL,
    ulg_fecha_ingreso date NOT NULL,
    ulg_token character varying(250),
    ulg_estado_registro character varying(3),
    ulg_fecha_creacion date NOT NULL,
    ulg_fecha_modificacion date NOT NULL,
    ulg_codigo_usuario_crea numeric(10,0) NOT NULL,
    ulg_codigo_usuario_modifica numeric(10,0) NOT NULL
);


ALTER TABLE asg_usuario_logueado OWNER TO esamyn_user;

--
-- TOC entry 3190 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE asg_usuario_logueado; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_usuario_logueado IS 'Estructura que almacena la informacion de los usuarios que se encuentran logueados';


--
-- TOC entry 3191 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_codigo_usuario_logueado; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_codigo_usuario_logueado IS 'Campo que hace referencia a la secuencia asg_seq_usuario_logueado';


--
-- TOC entry 3192 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_codigo_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_codigo_usuario IS 'Campo que hace referencia a la tabla asg_usuario';


--
-- TOC entry 3193 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_fecha_ingreso; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_fecha_ingreso IS 'Campo que define la fecha en la que ingreso el usuario al sistema';


--
-- TOC entry 3194 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_token; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_token IS 'Campo que define el token que genera cuando se loguea un usuario';


--
-- TOC entry 3195 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_estado_registro IS 'Campo que define el estado del registro';


--
-- TOC entry 3196 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3197 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3198 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3199 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN asg_usuario_logueado.ulg_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_logueado.ulg_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


--
-- TOC entry 225 (class 1259 OID 34446)
-- Name: asg_usuario_perfil; Type: TABLE; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE TABLE asg_usuario_perfil (
    uro_codigo_usuario_rol numeric(10,0) NOT NULL,
    uro_codigo_usuario numeric(10,0) NOT NULL,
    uro_codigo_perfil numeric(10,0) NOT NULL,
    uro_estado_registro character varying(3) DEFAULT 'ACT'::character varying NOT NULL,
    uro_fecha_creacion date NOT NULL,
    uro_fecha_modificacion date NOT NULL,
    uro_codigo_usuario_crea numeric(10,0) NOT NULL,
    uro_codigo_usuario_modifica numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((uro_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE asg_usuario_perfil OWNER TO esamyn_user;

--
-- TOC entry 3200 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE asg_usuario_perfil; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON TABLE asg_usuario_perfil IS 'Estructura que almacena la inforacion de la union entre la tabla asg_usuario y asg_ perfil';


--
-- TOC entry 3201 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_codigo_usuario_rol; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_codigo_usuario_rol IS 'Campo que hace referencia a la secuencia asg_seq_usuario_rol';


--
-- TOC entry 3202 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_codigo_usuario; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_codigo_usuario IS 'Campo que hacer referencia a la tabla asg_usuario';


--
-- TOC entry 3203 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_codigo_perfil; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_codigo_perfil IS 'Campo que hace referencia  a la tabla asg_perfil';


--
-- TOC entry 3204 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_estado_registro; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_estado_registro IS 'Campo que define el estado del registro. Permite INA, ACT';


--
-- TOC entry 3205 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_fecha_creacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_fecha_creacion IS 'Campo que contiene la fecha de crecion del registro';


--
-- TOC entry 3206 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_fecha_modificacion; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_fecha_modificacion IS 'Campo que contiene la fecha de modificacion';


--
-- TOC entry 3207 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_codigo_usuario_crea; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_codigo_usuario_crea IS 'Campo que contiene el codigo del usuario que creo el regitro';


--
-- TOC entry 3208 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN asg_usuario_perfil.uro_codigo_usuario_modifica; Type: COMMENT; Schema: administracion_seguridad; Owner: esamyn_user
--

COMMENT ON COLUMN asg_usuario_perfil.uro_codigo_usuario_modifica IS 'Campo que contiene el codigo de usuario que modifico el registro';


SET search_path = esamyn, pg_catalog;

--
-- TOC entry 226 (class 1259 OID 34451)
-- Name: esa_canton; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_canton (
    can_id bigint NOT NULL,
    can_provincia integer,
    can_nombre text,
    can_codigo text
);


ALTER TABLE esa_canton OWNER TO esamyn_user;

--
-- TOC entry 227 (class 1259 OID 34457)
-- Name: esa_canton_can_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_canton_can_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_canton_can_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3209 (class 0 OID 0)
-- Dependencies: 227
-- Name: esa_canton_can_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_canton_can_id_seq OWNED BY esa_canton.can_id;


--
-- TOC entry 228 (class 1259 OID 34459)
-- Name: esa_catalogo; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_catalogo (
    cat_id bigint NOT NULL,
    cat_creado timestamp with time zone DEFAULT now() NOT NULL,
    cat_modificado timestamp with time zone DEFAULT now() NOT NULL,
    cat_codigo text DEFAULT 'null'::text NOT NULL,
    cat_valor text
);


ALTER TABLE esa_catalogo OWNER TO esamyn_user;

--
-- TOC entry 229 (class 1259 OID 34468)
-- Name: esa_catalogo_cat_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_catalogo_cat_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_catalogo_cat_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3210 (class 0 OID 0)
-- Dependencies: 229
-- Name: esa_catalogo_cat_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_catalogo_cat_id_seq OWNED BY esa_catalogo.cat_id;


--
-- TOC entry 230 (class 1259 OID 34470)
-- Name: esa_condicion_no_aplica; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_condicion_no_aplica (
    cna_id bigint NOT NULL,
    cna_texto text
);


ALTER TABLE esa_condicion_no_aplica OWNER TO esamyn_user;

--
-- TOC entry 231 (class 1259 OID 34476)
-- Name: esa_condicion_no_aplica_cna_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_condicion_no_aplica_cna_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_condicion_no_aplica_cna_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3211 (class 0 OID 0)
-- Dependencies: 231
-- Name: esa_condicion_no_aplica_cna_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_condicion_no_aplica_cna_id_seq OWNED BY esa_condicion_no_aplica.cna_id;


--
-- TOC entry 232 (class 1259 OID 34478)
-- Name: esa_cumple_condicion_no_aplica; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_cumple_condicion_no_aplica (
    ccn_id bigint NOT NULL,
    ccn_creado timestamp with time zone DEFAULT now() NOT NULL,
    ccn_modificado timestamp with time zone DEFAULT now() NOT NULL,
    ccn_evaluacion bigint,
    ccn_condicion_no_aplica bigint,
    ccn_cumple integer DEFAULT 0 NOT NULL,
    ccn_pregunta bigint
);


ALTER TABLE esa_cumple_condicion_no_aplica OWNER TO esamyn_user;

--
-- TOC entry 233 (class 1259 OID 34484)
-- Name: esa_cumple_condicion_no_aplica_ccn_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_cumple_condicion_no_aplica_ccn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_cumple_condicion_no_aplica_ccn_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3212 (class 0 OID 0)
-- Dependencies: 233
-- Name: esa_cumple_condicion_no_aplica_ccn_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_cumple_condicion_no_aplica_ccn_id_seq OWNED BY esa_cumple_condicion_no_aplica.ccn_id;


--
-- TOC entry 234 (class 1259 OID 34486)
-- Name: esa_encuesta; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_encuesta (
    enc_id bigint NOT NULL,
    enc_creado timestamp with time zone DEFAULT now() NOT NULL,
    enc_modificado timestamp with time zone DEFAULT now() NOT NULL,
    enc_creado_por text,
    enc_modificado_por text,
    enc_formulario bigint,
    enc_usuario bigint,
    enc_evaluacion bigint,
    enc_finalizada integer DEFAULT 0 NOT NULL,
    enc_fecha_inicial timestamp with time zone DEFAULT now() NOT NULL,
    enc_fecha_final timestamp without time zone,
    enc_establecimiento_salud bigint,
    enc_responsable text,
    enc_cargo text,
    enc_extra text
);


ALTER TABLE esa_encuesta OWNER TO esamyn_user;

--
-- TOC entry 235 (class 1259 OID 34496)
-- Name: esa_encuesta_enc_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_encuesta_enc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_encuesta_enc_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3213 (class 0 OID 0)
-- Dependencies: 235
-- Name: esa_encuesta_enc_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_encuesta_enc_id_seq OWNED BY esa_encuesta.enc_id;


--
-- TOC entry 236 (class 1259 OID 34498)
-- Name: esa_establecimiento_salud; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_establecimiento_salud (
    ess_id bigint NOT NULL,
    ess_creado timestamp with time zone DEFAULT now() NOT NULL,
    ess_modificado timestamp with time zone DEFAULT now() NOT NULL,
    ess_canton bigint,
    ess_persona_juridica bigint,
    ess_nombre text,
    ess_unicodigo text,
    ess_direccion text,
    ess_latitud text,
    ess_longitud text,
    ess_telefono text,
    ess_correo_electronico text,
    ess_nombre_responsable text,
    ess_zona text,
    ess_distrito text,
    ess_nivel text,
    ess_tipologia text,
    ess_certificacion text
);


ALTER TABLE esa_establecimiento_salud OWNER TO esamyn_user;

--
-- TOC entry 237 (class 1259 OID 34506)
-- Name: esa_establecimiento_salud_ess_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_establecimiento_salud_ess_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_establecimiento_salud_ess_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3214 (class 0 OID 0)
-- Dependencies: 237
-- Name: esa_establecimiento_salud_ess_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_establecimiento_salud_ess_id_seq OWNED BY esa_establecimiento_salud.ess_id;


--
-- TOC entry 238 (class 1259 OID 34508)
-- Name: esa_evaluacion_eva_numero_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_evaluacion_eva_numero_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_evaluacion_eva_numero_seq OWNER TO esamyn_user;

--
-- TOC entry 239 (class 1259 OID 34510)
-- Name: esa_evaluacion; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_evaluacion (
    eva_id bigint NOT NULL,
    eva_creado timestamp with time zone DEFAULT now() NOT NULL,
    eva_modificado timestamp with time zone DEFAULT now() NOT NULL,
    eva_creado_por text,
    eva_modificado_por text,
    eva_usuario bigint,
    eva_establecimiento_salud bigint,
    eva_numero bigint DEFAULT nextval('esa_evaluacion_eva_numero_seq'::regclass),
    eva_calificacion numeric,
    eva_fecha_inicio timestamp with time zone DEFAULT now() NOT NULL,
    eva_fecha_calificacion timestamp with time zone,
    eva_cantidad_encuestas integer DEFAULT 0 NOT NULL,
    eva_tipo_evaluacion bigint,
    eva_descripcion text,
    eva_activo integer DEFAULT 0 NOT NULL,
    eva_porcentaje_avance integer DEFAULT 0 NOT NULL,
    eva_cumplido_minimos integer DEFAULT 0 NOT NULL,
    eva_cumplido_obligatorios integer DEFAULT 0 NOT NULL
);


ALTER TABLE esa_evaluacion OWNER TO esamyn_user;

--
-- TOC entry 240 (class 1259 OID 34523)
-- Name: esa_evaluacion_eva_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_evaluacion_eva_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_evaluacion_eva_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3215 (class 0 OID 0)
-- Dependencies: 240
-- Name: esa_evaluacion_eva_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_evaluacion_eva_id_seq OWNED BY esa_evaluacion.eva_id;


--
-- TOC entry 241 (class 1259 OID 34525)
-- Name: esa_formulario; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_formulario (
    frm_id bigint NOT NULL,
    frm_creado timestamp with time zone DEFAULT now() NOT NULL,
    frm_modificado timestamp with time zone DEFAULT now() NOT NULL,
    frm_nombre text,
    frm_titulo text,
    frm_subtitulo text,
    frm_ayuda text,
    frm_clave text,
    frm_umbral_maximo integer,
    frm_umbral_minimo integer DEFAULT 1 NOT NULL
);


ALTER TABLE esa_formulario OWNER TO esamyn_user;

--
-- TOC entry 242 (class 1259 OID 34534)
-- Name: esa_formulario_frm_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_formulario_frm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_formulario_frm_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3216 (class 0 OID 0)
-- Dependencies: 242
-- Name: esa_formulario_frm_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_formulario_frm_id_seq OWNED BY esa_formulario.frm_id;


--
-- TOC entry 243 (class 1259 OID 34536)
-- Name: esa_grupo_parametro; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_grupo_parametro (
    gpa_id bigint NOT NULL,
    gpa_padre bigint,
    gpa_tipo_grupo_parametro bigint,
    gpa_texto text,
    gpa_clave text
);


ALTER TABLE esa_grupo_parametro OWNER TO esamyn_user;

--
-- TOC entry 244 (class 1259 OID 34542)
-- Name: esa_grupo_parametro_gpa_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_grupo_parametro_gpa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_grupo_parametro_gpa_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3217 (class 0 OID 0)
-- Dependencies: 244
-- Name: esa_grupo_parametro_gpa_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_grupo_parametro_gpa_id_seq OWNED BY esa_grupo_parametro.gpa_id;


--
-- TOC entry 245 (class 1259 OID 34544)
-- Name: esa_parametro; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_parametro (
    par_id bigint NOT NULL,
    par_grupo_parametro bigint,
    par_puntaje integer,
    par_condicion_no_aplica bigint,
    par_texto text,
    par_obligatorio integer DEFAULT 0 NOT NULL,
    par_umbral integer DEFAULT 100 NOT NULL,
    par_cantidad_minima integer DEFAULT 10 NOT NULL,
    par_operador_logico integer,
    par_porcentaje integer DEFAULT 100 NOT NULL,
    par_codigo text,
    par_padre bigint
);


ALTER TABLE esa_parametro OWNER TO esamyn_user;

--
-- TOC entry 246 (class 1259 OID 34554)
-- Name: esa_parametro_par_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_parametro_par_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_parametro_par_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3218 (class 0 OID 0)
-- Dependencies: 246
-- Name: esa_parametro_par_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_parametro_par_id_seq OWNED BY esa_parametro.par_id;


--
-- TOC entry 247 (class 1259 OID 34556)
-- Name: esa_parametro_pregunta; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_parametro_pregunta (
    ppr_id bigint NOT NULL,
    ppr_creado timestamp with time zone DEFAULT now(),
    ppr_modificado timestamp with time zone DEFAULT now(),
    ppr_pregunta bigint,
    ppr_parametro bigint
);


ALTER TABLE esa_parametro_pregunta OWNER TO esamyn_user;

--
-- TOC entry 248 (class 1259 OID 34561)
-- Name: esa_parametro_pregunta_ppr_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_parametro_pregunta_ppr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_parametro_pregunta_ppr_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3219 (class 0 OID 0)
-- Dependencies: 248
-- Name: esa_parametro_pregunta_ppr_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_parametro_pregunta_ppr_id_seq OWNED BY esa_parametro_pregunta.ppr_id;


--
-- TOC entry 274 (class 1259 OID 35148)
-- Name: esa_permiso_ingreso; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_permiso_ingreso (
    pei_id bigint NOT NULL,
    pei_usuario bigint NOT NULL,
    pei_establecimiento_salud bigint NOT NULL
);


ALTER TABLE esa_permiso_ingreso OWNER TO esamyn_user;

--
-- TOC entry 273 (class 1259 OID 35146)
-- Name: esa_permiso_ingreso_pei_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_permiso_ingreso_pei_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_permiso_ingreso_pei_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3220 (class 0 OID 0)
-- Dependencies: 273
-- Name: esa_permiso_ingreso_pei_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_permiso_ingreso_pei_id_seq OWNED BY esa_permiso_ingreso.pei_id;


--
-- TOC entry 249 (class 1259 OID 34563)
-- Name: esa_persona_juridica; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_persona_juridica (
    pju_id bigint NOT NULL,
    pju_creado timestamp with time zone DEFAULT now() NOT NULL,
    pju_modificado timestamp with time zone DEFAULT now() NOT NULL,
    pju_razon_social text,
    pju_ruc text
);


ALTER TABLE esa_persona_juridica OWNER TO esamyn_user;

--
-- TOC entry 250 (class 1259 OID 34571)
-- Name: esa_persona_juridica_pju_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_persona_juridica_pju_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_persona_juridica_pju_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3221 (class 0 OID 0)
-- Dependencies: 250
-- Name: esa_persona_juridica_pju_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_persona_juridica_pju_id_seq OWNED BY esa_persona_juridica.pju_id;


--
-- TOC entry 251 (class 1259 OID 34573)
-- Name: esa_pregunta; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_pregunta (
    prg_id bigint NOT NULL,
    prg_creado timestamp with time zone DEFAULT now() NOT NULL,
    prg_modificado timestamp with time zone DEFAULT now() NOT NULL,
    prg_padre bigint,
    prg_tipo_pregunta bigint,
    prg_formulario integer,
    prg_texto text,
    prg_codigo_verificacion text,
    prg_ayuda text,
    prg_prefijo text,
    prg_subfijo text,
    prg_validacion text,
    prg_orden integer,
    prg_imagen text,
    prg_codigo_no_aplica text
);


ALTER TABLE esa_pregunta OWNER TO esamyn_user;

--
-- TOC entry 252 (class 1259 OID 34581)
-- Name: esa_pregunta_prg_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_pregunta_prg_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_pregunta_prg_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3222 (class 0 OID 0)
-- Dependencies: 252
-- Name: esa_pregunta_prg_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_pregunta_prg_id_seq OWNED BY esa_pregunta.prg_id;


--
-- TOC entry 253 (class 1259 OID 34583)
-- Name: esa_provincia; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_provincia (
    pro_id bigint NOT NULL,
    pro_nombre text,
    pro_codigo text
);


ALTER TABLE esa_provincia OWNER TO esamyn_user;

--
-- TOC entry 254 (class 1259 OID 34589)
-- Name: esa_provincia_pro_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_provincia_pro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_provincia_pro_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3223 (class 0 OID 0)
-- Dependencies: 254
-- Name: esa_provincia_pro_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_provincia_pro_id_seq OWNED BY esa_provincia.pro_id;


--
-- TOC entry 255 (class 1259 OID 34591)
-- Name: esa_respuesta; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_respuesta (
    res_id bigint NOT NULL,
    res_creado timestamp with time zone DEFAULT now() NOT NULL,
    res_modificado timestamp with time zone DEFAULT now() NOT NULL,
    res_creado_por text,
    res_modificado_por text,
    res_pregunta bigint,
    res_encuesta bigint,
    res_valor_numero numeric,
    res_valor_texto text,
    res_valor_fecha timestamp with time zone,
    res_valor_booleano boolean DEFAULT false
);


ALTER TABLE esa_respuesta OWNER TO esamyn_user;

--
-- TOC entry 256 (class 1259 OID 34600)
-- Name: esa_respuesta_res_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_respuesta_res_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_respuesta_res_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3224 (class 0 OID 0)
-- Dependencies: 256
-- Name: esa_respuesta_res_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_respuesta_res_id_seq OWNED BY esa_respuesta.res_id;


--
-- TOC entry 257 (class 1259 OID 34602)
-- Name: esa_rol; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_rol (
    rol_id bigint NOT NULL,
    rol_nombre text
);


ALTER TABLE esa_rol OWNER TO esamyn_user;

--
-- TOC entry 258 (class 1259 OID 34608)
-- Name: esa_rol_rol_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_rol_rol_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_rol_rol_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3225 (class 0 OID 0)
-- Dependencies: 258
-- Name: esa_rol_rol_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_rol_rol_id_seq OWNED BY esa_rol.rol_id;


--
-- TOC entry 259 (class 1259 OID 34610)
-- Name: esa_tipo_evaluacion; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_tipo_evaluacion (
    tev_id bigint NOT NULL,
    tev_nombre text NOT NULL
);


ALTER TABLE esa_tipo_evaluacion OWNER TO esamyn_user;

--
-- TOC entry 260 (class 1259 OID 34616)
-- Name: esa_tipo_evaluacion_tev_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_tipo_evaluacion_tev_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_tipo_evaluacion_tev_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3226 (class 0 OID 0)
-- Dependencies: 260
-- Name: esa_tipo_evaluacion_tev_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_tipo_evaluacion_tev_id_seq OWNED BY esa_tipo_evaluacion.tev_id;


--
-- TOC entry 261 (class 1259 OID 34618)
-- Name: esa_tipo_grupo_parametro; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_tipo_grupo_parametro (
    tgp_id bigint NOT NULL,
    tgp_texto text
);


ALTER TABLE esa_tipo_grupo_parametro OWNER TO esamyn_user;

--
-- TOC entry 262 (class 1259 OID 34624)
-- Name: esa_tipo_grupo_parametro_tgp_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_tipo_grupo_parametro_tgp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_tipo_grupo_parametro_tgp_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3227 (class 0 OID 0)
-- Dependencies: 262
-- Name: esa_tipo_grupo_parametro_tgp_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_tipo_grupo_parametro_tgp_id_seq OWNED BY esa_tipo_grupo_parametro.tgp_id;


--
-- TOC entry 263 (class 1259 OID 34626)
-- Name: esa_tipo_pregunta; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_tipo_pregunta (
    tpp_id bigint NOT NULL,
    tpp_clave text,
    tpp_etiqueta text
);


ALTER TABLE esa_tipo_pregunta OWNER TO esamyn_user;

--
-- TOC entry 264 (class 1259 OID 34633)
-- Name: esa_tipo_pregunta_tpp_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_tipo_pregunta_tpp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_tipo_pregunta_tpp_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3228 (class 0 OID 0)
-- Dependencies: 264
-- Name: esa_tipo_pregunta_tpp_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_tipo_pregunta_tpp_id_seq OWNED BY esa_tipo_pregunta.tpp_id;


--
-- TOC entry 265 (class 1259 OID 34635)
-- Name: esa_usuario; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_usuario (
    usu_id bigint NOT NULL,
    usu_creado timestamp with time zone DEFAULT now() NOT NULL,
    usu_modificado timestamp with time zone DEFAULT now() NOT NULL,
    usu_rol bigint,
    usu_nombres text,
    usu_apellidos text,
    usu_username text,
    usu_password text,
    usu_bloqueado integer DEFAULT 0 NOT NULL,
    usu_cedula text,
    usu_telefono text,
    usu_correo_electronico text,
    usu_sesion character varying(200),
    usu_fecha_ingreso timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE esa_usuario OWNER TO esamyn_user;

--
-- TOC entry 266 (class 1259 OID 34645)
-- Name: esa_usuario_usu_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_usuario_usu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_usuario_usu_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3229 (class 0 OID 0)
-- Dependencies: 266
-- Name: esa_usuario_usu_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_usuario_usu_id_seq OWNED BY esa_usuario.usu_id;


--
-- TOC entry 267 (class 1259 OID 34647)
-- Name: esa_verificador; Type: TABLE; Schema: esamyn; Owner: esamyn_user
--

CREATE TABLE esa_verificador (
    ver_id bigint NOT NULL,
    ver_creado timestamp with time zone DEFAULT now() NOT NULL,
    ver_modificado timestamp with time zone DEFAULT now() NOT NULL,
    ver_evaluacion bigint,
    ver_parametro bigint,
    ver_cumple integer DEFAULT 0 NOT NULL,
    ver_no_aplica integer DEFAULT 0 NOT NULL,
    ver_cantidad_medidas integer DEFAULT 0 NOT NULL,
    ver_cumple_condicion_no_aplica bigint
);


ALTER TABLE esa_verificador OWNER TO esamyn_user;

--
-- TOC entry 268 (class 1259 OID 34655)
-- Name: esa_verificador_ver_id_seq; Type: SEQUENCE; Schema: esamyn; Owner: esamyn_user
--

CREATE SEQUENCE esa_verificador_ver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE esa_verificador_ver_id_seq OWNER TO esamyn_user;

--
-- TOC entry 3230 (class 0 OID 0)
-- Dependencies: 268
-- Name: esa_verificador_ver_id_seq; Type: SEQUENCE OWNED BY; Schema: esamyn; Owner: esamyn_user
--

ALTER SEQUENCE esa_verificador_ver_id_seq OWNED BY esa_verificador.ver_id;


SET search_path = medicina_prepagada, pg_catalog;

--
-- TOC entry 269 (class 1259 OID 34657)
-- Name: mpp_archivo; Type: TABLE; Schema: medicina_prepagada; Owner: esamyn_user
--

CREATE TABLE mpp_archivo (
    arc_codigo_archivo numeric(10,0) NOT NULL,
    arc_nombre_archivo character varying(50) NOT NULL,
    arc_fecha_registro date DEFAULT now() NOT NULL,
    arc_estado_registro character varying(3) NOT NULL,
    arc_archivo text NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((arc_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE mpp_archivo OWNER TO esamyn_user;

--
-- TOC entry 3231 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE mpp_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON TABLE mpp_archivo IS 'Almacena archivos de hoja de calculo con informacion de clientes de medicina prepagada';


--
-- TOC entry 3232 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN mpp_archivo.arc_codigo_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_archivo.arc_codigo_archivo IS 'Codigo Tabla Historial Archivo';


--
-- TOC entry 3233 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN mpp_archivo.arc_nombre_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_archivo.arc_nombre_archivo IS 'nombre del archivo que se esta gestionando ';


--
-- TOC entry 3234 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN mpp_archivo.arc_fecha_registro; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_archivo.arc_fecha_registro IS 'fecha de creacion del registro ';


--
-- TOC entry 3235 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN mpp_archivo.arc_estado_registro; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_archivo.arc_estado_registro IS 'Campo que define el estado del registro';


--
-- TOC entry 3236 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN mpp_archivo.arc_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_archivo.arc_archivo IS 'Campo que almacena los archivos en formato base64';


--
-- TOC entry 270 (class 1259 OID 34665)
-- Name: mpp_historial_archivo; Type: TABLE; Schema: medicina_prepagada; Owner: esamyn_user
--

CREATE TABLE mpp_historial_archivo (
    cht_codigo_historial numeric(10,0) NOT NULL,
    cht_fecha_creacion date NOT NULL,
    cht_estado_registro character varying(3) NOT NULL,
    cht_tipo_transaccion character varying(10),
    cht_codigo_archivo numeric(10,0),
    cht_codigo_usuario numeric(10,0) NOT NULL,
    CONSTRAINT estado_registro_ck CHECK (((cht_estado_registro)::text = ANY (ARRAY[('ACT'::character varying)::text, ('INA'::character varying)::text])))
);


ALTER TABLE mpp_historial_archivo OWNER TO esamyn_user;

--
-- TOC entry 3237 (class 0 OID 0)
-- Dependencies: 270
-- Name: TABLE mpp_historial_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON TABLE mpp_historial_archivo IS 'hisorial de carga y descarga de archivos ';


--
-- TOC entry 3238 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN mpp_historial_archivo.cht_codigo_historial; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_historial_archivo.cht_codigo_historial IS 'codigo historial archivo';


--
-- TOC entry 3239 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN mpp_historial_archivo.cht_estado_registro; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_historial_archivo.cht_estado_registro IS 'estado del registro ';


--
-- TOC entry 3240 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN mpp_historial_archivo.cht_tipo_transaccion; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_historial_archivo.cht_tipo_transaccion IS 'tipo de transaccion realizada con el archivo carga/descarga';


--
-- TOC entry 3241 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN mpp_historial_archivo.cht_codigo_usuario; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON COLUMN mpp_historial_archivo.cht_codigo_usuario IS 'Campo que hace referencia a la tabla asg_usuario';


--
-- TOC entry 271 (class 1259 OID 34669)
-- Name: mpp_seq_archivo; Type: SEQUENCE; Schema: medicina_prepagada; Owner: esamyn_user
--

CREATE SEQUENCE mpp_seq_archivo
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE mpp_seq_archivo OWNER TO esamyn_user;

--
-- TOC entry 3242 (class 0 OID 0)
-- Dependencies: 271
-- Name: SEQUENCE mpp_seq_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON SEQUENCE mpp_seq_archivo IS 'secuencia para tabla mpp_archivos';


--
-- TOC entry 272 (class 1259 OID 34671)
-- Name: mpp_seq_historial_archivo; Type: SEQUENCE; Schema: medicina_prepagada; Owner: esamyn_user
--

CREATE SEQUENCE mpp_seq_historial_archivo
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE mpp_seq_historial_archivo OWNER TO esamyn_user;

--
-- TOC entry 3243 (class 0 OID 0)
-- Dependencies: 272
-- Name: SEQUENCE mpp_seq_historial_archivo; Type: COMMENT; Schema: medicina_prepagada; Owner: esamyn_user
--

COMMENT ON SEQUENCE mpp_seq_historial_archivo IS 'Secuencia que hace referencia  la tabla mpp_historial_archivo';


SET search_path = esamyn, pg_catalog;

--
-- TOC entry 2586 (class 2604 OID 34673)
-- Name: esa_canton can_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_canton ALTER COLUMN can_id SET DEFAULT nextval('esa_canton_can_id_seq'::regclass);


--
-- TOC entry 2590 (class 2604 OID 34674)
-- Name: esa_catalogo cat_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_catalogo ALTER COLUMN cat_id SET DEFAULT nextval('esa_catalogo_cat_id_seq'::regclass);


--
-- TOC entry 2591 (class 2604 OID 34675)
-- Name: esa_condicion_no_aplica cna_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_condicion_no_aplica ALTER COLUMN cna_id SET DEFAULT nextval('esa_condicion_no_aplica_cna_id_seq'::regclass);


--
-- TOC entry 2595 (class 2604 OID 34676)
-- Name: esa_cumple_condicion_no_aplica ccn_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_cumple_condicion_no_aplica ALTER COLUMN ccn_id SET DEFAULT nextval('esa_cumple_condicion_no_aplica_ccn_id_seq'::regclass);


--
-- TOC entry 2600 (class 2604 OID 34677)
-- Name: esa_encuesta enc_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_encuesta ALTER COLUMN enc_id SET DEFAULT nextval('esa_encuesta_enc_id_seq'::regclass);


--
-- TOC entry 2603 (class 2604 OID 34678)
-- Name: esa_establecimiento_salud ess_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_establecimiento_salud ALTER COLUMN ess_id SET DEFAULT nextval('esa_establecimiento_salud_ess_id_seq'::regclass);


--
-- TOC entry 2611 (class 2604 OID 34679)
-- Name: esa_evaluacion eva_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_evaluacion ALTER COLUMN eva_id SET DEFAULT nextval('esa_evaluacion_eva_id_seq'::regclass);


--
-- TOC entry 2617 (class 2604 OID 34680)
-- Name: esa_formulario frm_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_formulario ALTER COLUMN frm_id SET DEFAULT nextval('esa_formulario_frm_id_seq'::regclass);


--
-- TOC entry 2618 (class 2604 OID 34681)
-- Name: esa_grupo_parametro gpa_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_grupo_parametro ALTER COLUMN gpa_id SET DEFAULT nextval('esa_grupo_parametro_gpa_id_seq'::regclass);


--
-- TOC entry 2623 (class 2604 OID 34682)
-- Name: esa_parametro par_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro ALTER COLUMN par_id SET DEFAULT nextval('esa_parametro_par_id_seq'::regclass);


--
-- TOC entry 2626 (class 2604 OID 34683)
-- Name: esa_parametro_pregunta ppr_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro_pregunta ALTER COLUMN ppr_id SET DEFAULT nextval('esa_parametro_pregunta_ppr_id_seq'::regclass);


--
-- TOC entry 2656 (class 2604 OID 35151)
-- Name: esa_permiso_ingreso pei_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_permiso_ingreso ALTER COLUMN pei_id SET DEFAULT nextval('esa_permiso_ingreso_pei_id_seq'::regclass);


--
-- TOC entry 2629 (class 2604 OID 34684)
-- Name: esa_persona_juridica pju_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_persona_juridica ALTER COLUMN pju_id SET DEFAULT nextval('esa_persona_juridica_pju_id_seq'::regclass);


--
-- TOC entry 2632 (class 2604 OID 34685)
-- Name: esa_pregunta prg_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_pregunta ALTER COLUMN prg_id SET DEFAULT nextval('esa_pregunta_prg_id_seq'::regclass);


--
-- TOC entry 2633 (class 2604 OID 34686)
-- Name: esa_provincia pro_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_provincia ALTER COLUMN pro_id SET DEFAULT nextval('esa_provincia_pro_id_seq'::regclass);


--
-- TOC entry 2637 (class 2604 OID 34687)
-- Name: esa_respuesta res_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_respuesta ALTER COLUMN res_id SET DEFAULT nextval('esa_respuesta_res_id_seq'::regclass);


--
-- TOC entry 2638 (class 2604 OID 34688)
-- Name: esa_rol rol_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_rol ALTER COLUMN rol_id SET DEFAULT nextval('esa_rol_rol_id_seq'::regclass);


--
-- TOC entry 2639 (class 2604 OID 34689)
-- Name: esa_tipo_evaluacion tev_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_tipo_evaluacion ALTER COLUMN tev_id SET DEFAULT nextval('esa_tipo_evaluacion_tev_id_seq'::regclass);


--
-- TOC entry 2640 (class 2604 OID 34690)
-- Name: esa_tipo_grupo_parametro tgp_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_tipo_grupo_parametro ALTER COLUMN tgp_id SET DEFAULT nextval('esa_tipo_grupo_parametro_tgp_id_seq'::regclass);


--
-- TOC entry 2641 (class 2604 OID 34691)
-- Name: esa_tipo_pregunta tpp_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_tipo_pregunta ALTER COLUMN tpp_id SET DEFAULT nextval('esa_tipo_pregunta_tpp_id_seq'::regclass);


--
-- TOC entry 2646 (class 2604 OID 34692)
-- Name: esa_usuario usu_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_usuario ALTER COLUMN usu_id SET DEFAULT nextval('esa_usuario_usu_id_seq'::regclass);


--
-- TOC entry 2652 (class 2604 OID 34693)
-- Name: esa_verificador ver_id; Type: DEFAULT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_verificador ALTER COLUMN ver_id SET DEFAULT nextval('esa_verificador_ver_id_seq'::regclass);


SET search_path = administracion_general, pg_catalog;

--
-- TOC entry 2690 (class 2606 OID 34701)
-- Name: agn_provincia agn_provincia_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_provincia
    ADD CONSTRAINT agn_provincia_pk PRIMARY KEY (pro_codigo_provincia);


--
-- TOC entry 2658 (class 2606 OID 34703)
-- Name: agn_canton can_codigo_canton_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_canton
    ADD CONSTRAINT can_codigo_canton_pk PRIMARY KEY (can_codigo_canton);


--
-- TOC entry 2661 (class 2606 OID 34705)
-- Name: agn_catalogo codigo_catalogo_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_catalogo
    ADD CONSTRAINT codigo_catalogo_pk PRIMARY KEY (cat_codigo_catalogo);


--
-- TOC entry 2664 (class 2606 OID 34707)
-- Name: agn_distrito codigo_distrito_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_distrito
    ADD CONSTRAINT codigo_distrito_pk PRIMARY KEY (dis_codigo_distrito);


--
-- TOC entry 2669 (class 2606 OID 34709)
-- Name: agn_establecimiento codigo_establecimiento_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_establecimiento
    ADD CONSTRAINT codigo_establecimiento_pk PRIMARY KEY (est_codigo_establecimiento);


--
-- TOC entry 2667 (class 2606 OID 34711)
-- Name: agn_entidad codigo_institucion_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_entidad
    ADD CONSTRAINT codigo_institucion_pk PRIMARY KEY (ent_codigo_entidad);


--
-- TOC entry 2674 (class 2606 OID 34713)
-- Name: agn_parametro_general codigo_parametro_general_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_parametro_general
    ADD CONSTRAINT codigo_parametro_general_pk PRIMARY KEY (pgn_codigo_parametro_general);


--
-- TOC entry 2678 (class 2606 OID 34715)
-- Name: agn_parroquia codigo_parroquia_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_parroquia
    ADD CONSTRAINT codigo_parroquia_pk PRIMARY KEY (par_codigo_parroquia);


--
-- TOC entry 2681 (class 2606 OID 34717)
-- Name: agn_persona codigo_persona_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_persona_pk PRIMARY KEY (per_codigo_persona);


--
-- TOC entry 2692 (class 2606 OID 34719)
-- Name: agn_zona codigo_zona_pk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_zona
    ADD CONSTRAINT codigo_zona_pk PRIMARY KEY (zon_codigo_zona);


--
-- TOC entry 2676 (class 2606 OID 34721)
-- Name: agn_parametro_general identificador_parametro_uk; Type: CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_parametro_general
    ADD CONSTRAINT identificador_parametro_uk UNIQUE (pgn_identificador_parametro);


SET search_path = administracion_seguridad, pg_catalog;

--
-- TOC entry 2710 (class 2606 OID 34723)
-- Name: asg_rol_menu asg_rol_menu_uk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol_menu
    ADD CONSTRAINT asg_rol_menu_uk UNIQUE (rmn_codigo_rol, rmn_codigo_menu, rmn_estado_registro);


--
-- TOC entry 2694 (class 2606 OID 34725)
-- Name: asg_aplicacion codigo_aplicacion_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_aplicacion
    ADD CONSTRAINT codigo_aplicacion_pk PRIMARY KEY (apl_codigo_aplicacion);


--
-- TOC entry 2717 (class 2606 OID 34727)
-- Name: asg_usuario_establecimiento codigo_institucion_usu_uk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_establecimiento
    ADD CONSTRAINT codigo_institucion_usu_uk UNIQUE (uit_codigo_usuario, uit_codigo_establecimiento, uit_estado_registro);


--
-- TOC entry 2699 (class 2606 OID 34729)
-- Name: asg_menu codigo_menu_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_menu
    ADD CONSTRAINT codigo_menu_pk PRIMARY KEY (men_codigo_menu);


--
-- TOC entry 2703 (class 2606 OID 34731)
-- Name: asg_perfil codigo_perfil_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_perfil
    ADD CONSTRAINT codigo_perfil_pk PRIMARY KEY (prl_codigo_perfil);


--
-- TOC entry 2706 (class 2606 OID 34733)
-- Name: asg_rol codigo_rol; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol
    ADD CONSTRAINT codigo_rol PRIMARY KEY (rol_codigo_rol);


--
-- TOC entry 2712 (class 2606 OID 34735)
-- Name: asg_rol_menu codigo_rol_menu_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol_menu
    ADD CONSTRAINT codigo_rol_menu_pk PRIMARY KEY (rmn_codigo_rol_menu);


--
-- TOC entry 2719 (class 2606 OID 34737)
-- Name: asg_usuario_establecimiento codigo_usuario_institucion_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_establecimiento
    ADD CONSTRAINT codigo_usuario_institucion_pk PRIMARY KEY (uit_codigo_usuario_entidad);


--
-- TOC entry 2723 (class 2606 OID 34739)
-- Name: asg_usuario_logueado codigo_usuario_loguedo_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_logueado
    ADD CONSTRAINT codigo_usuario_loguedo_pk PRIMARY KEY (ulg_codigo_usuario_logueado);


--
-- TOC entry 2714 (class 2606 OID 34741)
-- Name: asg_usuario codigo_usuario_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario
    ADD CONSTRAINT codigo_usuario_pk PRIMARY KEY (usu_codigo_usuario);


--
-- TOC entry 2725 (class 2606 OID 34743)
-- Name: asg_usuario_perfil codigo_usuario_rol_pk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_perfil
    ADD CONSTRAINT codigo_usuario_rol_pk PRIMARY KEY (uro_codigo_usuario_rol);


--
-- TOC entry 2697 (class 2606 OID 34745)
-- Name: asg_aplicacion identificador_uk; Type: CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_aplicacion
    ADD CONSTRAINT identificador_uk UNIQUE (apl_identificador);


SET search_path = esamyn, pg_catalog;

--
-- TOC entry 2729 (class 2606 OID 34747)
-- Name: esa_canton esa_canton_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_canton
    ADD CONSTRAINT esa_canton_pkey PRIMARY KEY (can_id);


--
-- TOC entry 2731 (class 2606 OID 34749)
-- Name: esa_catalogo esa_catalogo_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_catalogo
    ADD CONSTRAINT esa_catalogo_pkey PRIMARY KEY (cat_id);


--
-- TOC entry 2733 (class 2606 OID 34751)
-- Name: esa_condicion_no_aplica esa_condicion_no_aplica_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_condicion_no_aplica
    ADD CONSTRAINT esa_condicion_no_aplica_pkey PRIMARY KEY (cna_id);


--
-- TOC entry 2735 (class 2606 OID 34753)
-- Name: esa_cumple_condicion_no_aplica esa_cumple_condicion_no_aplica_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_cumple_condicion_no_aplica
    ADD CONSTRAINT esa_cumple_condicion_no_aplica_pkey PRIMARY KEY (ccn_id);


--
-- TOC entry 2737 (class 2606 OID 34755)
-- Name: esa_encuesta esa_encuesta_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_encuesta
    ADD CONSTRAINT esa_encuesta_pkey PRIMARY KEY (enc_id);


--
-- TOC entry 2739 (class 2606 OID 34757)
-- Name: esa_establecimiento_salud esa_establecimiento_salud_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_establecimiento_salud
    ADD CONSTRAINT esa_establecimiento_salud_pkey PRIMARY KEY (ess_id);


--
-- TOC entry 2741 (class 2606 OID 34759)
-- Name: esa_evaluacion esa_evaluacion_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_evaluacion
    ADD CONSTRAINT esa_evaluacion_pkey PRIMARY KEY (eva_id);


--
-- TOC entry 2744 (class 2606 OID 34761)
-- Name: esa_formulario esa_formulario_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_formulario
    ADD CONSTRAINT esa_formulario_pkey PRIMARY KEY (frm_id);


--
-- TOC entry 2746 (class 2606 OID 34763)
-- Name: esa_grupo_parametro esa_grupo_parametro_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_grupo_parametro
    ADD CONSTRAINT esa_grupo_parametro_pkey PRIMARY KEY (gpa_id);


--
-- TOC entry 2748 (class 2606 OID 34765)
-- Name: esa_parametro esa_parametro_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro
    ADD CONSTRAINT esa_parametro_pkey PRIMARY KEY (par_id);


--
-- TOC entry 2750 (class 2606 OID 34767)
-- Name: esa_parametro_pregunta esa_parametro_pregunta_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro_pregunta
    ADD CONSTRAINT esa_parametro_pregunta_pkey PRIMARY KEY (ppr_id);


--
-- TOC entry 2777 (class 2606 OID 35153)
-- Name: esa_permiso_ingreso esa_permiso_ingreso_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_permiso_ingreso
    ADD CONSTRAINT esa_permiso_ingreso_pkey PRIMARY KEY (pei_id);


--
-- TOC entry 2752 (class 2606 OID 34769)
-- Name: esa_persona_juridica esa_persona_juridica_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_persona_juridica
    ADD CONSTRAINT esa_persona_juridica_pkey PRIMARY KEY (pju_id);


--
-- TOC entry 2754 (class 2606 OID 34771)
-- Name: esa_pregunta esa_pregunta_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_pregunta
    ADD CONSTRAINT esa_pregunta_pkey PRIMARY KEY (prg_id);


--
-- TOC entry 2756 (class 2606 OID 34773)
-- Name: esa_provincia esa_provincia_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_provincia
    ADD CONSTRAINT esa_provincia_pkey PRIMARY KEY (pro_id);


--
-- TOC entry 2758 (class 2606 OID 34775)
-- Name: esa_respuesta esa_respuesta_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_respuesta
    ADD CONSTRAINT esa_respuesta_pkey PRIMARY KEY (res_id);


--
-- TOC entry 2760 (class 2606 OID 34777)
-- Name: esa_rol esa_rol_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_rol
    ADD CONSTRAINT esa_rol_pkey PRIMARY KEY (rol_id);


--
-- TOC entry 2762 (class 2606 OID 34779)
-- Name: esa_tipo_evaluacion esa_tipo_evaluacion_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_tipo_evaluacion
    ADD CONSTRAINT esa_tipo_evaluacion_pkey PRIMARY KEY (tev_id);


--
-- TOC entry 2764 (class 2606 OID 34781)
-- Name: esa_tipo_grupo_parametro esa_tipo_grupo_parametro_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_tipo_grupo_parametro
    ADD CONSTRAINT esa_tipo_grupo_parametro_pkey PRIMARY KEY (tgp_id);


--
-- TOC entry 2766 (class 2606 OID 34783)
-- Name: esa_tipo_pregunta esa_tipo_pregunta_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_tipo_pregunta
    ADD CONSTRAINT esa_tipo_pregunta_pkey PRIMARY KEY (tpp_id);


--
-- TOC entry 2768 (class 2606 OID 34785)
-- Name: esa_usuario esa_usuario_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_usuario
    ADD CONSTRAINT esa_usuario_pkey PRIMARY KEY (usu_id);


--
-- TOC entry 2770 (class 2606 OID 34787)
-- Name: esa_verificador esa_verificador_pkey; Type: CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_verificador
    ADD CONSTRAINT esa_verificador_pkey PRIMARY KEY (ver_id);


SET search_path = medicina_prepagada, pg_catalog;

--
-- TOC entry 2772 (class 2606 OID 34789)
-- Name: mpp_archivo codigo_archivo_pk; Type: CONSTRAINT; Schema: medicina_prepagada; Owner: esamyn_user
--

ALTER TABLE ONLY mpp_archivo
    ADD CONSTRAINT codigo_archivo_pk PRIMARY KEY (arc_codigo_archivo);


--
-- TOC entry 2774 (class 2606 OID 34791)
-- Name: mpp_historial_archivo codigo_historial_pk; Type: CONSTRAINT; Schema: medicina_prepagada; Owner: esamyn_user
--

ALTER TABLE ONLY mpp_historial_archivo
    ADD CONSTRAINT codigo_historial_pk PRIMARY KEY (cht_codigo_historial);


SET search_path = administracion_general, pg_catalog;

--
-- TOC entry 2659 (class 1259 OID 34792)
-- Name: fki_can_codigo_provincia_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_can_codigo_provincia_fk ON agn_canton USING btree (can_codigo_provincia);


--
-- TOC entry 2679 (class 1259 OID 34793)
-- Name: fki_codigo_canton_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_canton_fk ON agn_parroquia USING btree (par_codigo_canton);


--
-- TOC entry 2662 (class 1259 OID 34794)
-- Name: fki_codigo_catalogo_padre_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_catalogo_padre_fk ON agn_catalogo USING btree (cat_codigo_catalogo_padre);


--
-- TOC entry 2670 (class 1259 OID 34795)
-- Name: fki_codigo_distrito_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_distrito_fk ON agn_establecimiento USING btree (est_codigo_distrito);


--
-- TOC entry 2682 (class 1259 OID 34796)
-- Name: fki_codigo_estado_civil_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_estado_civil_fk ON agn_persona USING btree (per_codigo_cat_estado_civil);


--
-- TOC entry 2683 (class 1259 OID 34797)
-- Name: fki_codigo_etnia_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_etnia_fk ON agn_persona USING btree (per_codigo_cat_etnia);


--
-- TOC entry 2684 (class 1259 OID 34798)
-- Name: fki_codigo_nacionalidad_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_nacionalidad_fk ON agn_persona USING btree (per_codigo_cat_nacionalidad);


--
-- TOC entry 2685 (class 1259 OID 34799)
-- Name: fki_codigo_nacionalidad_org_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_nacionalidad_org_fk ON agn_persona USING btree (per_codigo_cat_nacionalidad_org);


--
-- TOC entry 2686 (class 1259 OID 34800)
-- Name: fki_codigo_parroquia_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_parroquia_fk ON agn_persona USING btree (per_codigo_parroquia);


--
-- TOC entry 2671 (class 1259 OID 34801)
-- Name: fki_codigo_parroquia_fk1; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_parroquia_fk1 ON agn_establecimiento USING btree (est_codigo_parroquia);


--
-- TOC entry 2687 (class 1259 OID 34802)
-- Name: fki_codigo_pueblo_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_pueblo_fk ON agn_persona USING btree (per_codigo_cat_pueblo);


--
-- TOC entry 2688 (class 1259 OID 34803)
-- Name: fki_codigo_tipo_entidad_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_codigo_tipo_entidad_fk ON agn_persona USING btree (per_codigo_cat_tipo_entidad);


--
-- TOC entry 2665 (class 1259 OID 34804)
-- Name: fki_dis_codigo_zona_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_dis_codigo_zona_fk ON agn_distrito USING btree (dis_codigo_zona);


--
-- TOC entry 2672 (class 1259 OID 34805)
-- Name: fki_est_codigo_entidad_fk; Type: INDEX; Schema: administracion_general; Owner: esamyn_user
--

CREATE INDEX fki_est_codigo_entidad_fk ON agn_establecimiento USING btree (est_codigo_entidad);


SET search_path = administracion_seguridad, pg_catalog;

--
-- TOC entry 2695 (class 1259 OID 34806)
-- Name: fki_catalogo_proceso_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_catalogo_proceso_fk ON asg_aplicacion USING btree (apl_codigo_cat_proceso);


--
-- TOC entry 2700 (class 1259 OID 34807)
-- Name: fki_codigo_aplicacion_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_aplicacion_fk ON asg_menu USING btree (men_codigo_aplicacion);


--
-- TOC entry 2707 (class 1259 OID 34808)
-- Name: fki_codigo_aplicacion_fk1; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_aplicacion_fk1 ON asg_rol USING btree (rol_codigo_aplicacion);


--
-- TOC entry 2704 (class 1259 OID 34809)
-- Name: fki_codigo_aplicacion_fk2; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_aplicacion_fk2 ON asg_perfil USING btree (prl_codigo_aplicacion);


--
-- TOC entry 2720 (class 1259 OID 34810)
-- Name: fki_codigo_institucion_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_institucion_fk ON asg_usuario_establecimiento USING btree (uit_codigo_establecimiento);


--
-- TOC entry 2701 (class 1259 OID 34811)
-- Name: fki_codigo_menu_padre_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_menu_padre_fk ON asg_menu USING btree (men_codigo_menu_padre);


--
-- TOC entry 2708 (class 1259 OID 34812)
-- Name: fki_codigo_perfil_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_perfil_fk ON asg_rol USING btree (rol_codigo_perfil);


--
-- TOC entry 2715 (class 1259 OID 34813)
-- Name: fki_codigo_persona_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_persona_fk ON asg_usuario USING btree (usu_codigo_persona);


--
-- TOC entry 2726 (class 1259 OID 34814)
-- Name: fki_codigo_rol_fk1; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_rol_fk1 ON asg_usuario_perfil USING btree (uro_codigo_perfil);


--
-- TOC entry 2721 (class 1259 OID 34815)
-- Name: fki_codigo_usuario_fk; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_usuario_fk ON asg_usuario_establecimiento USING btree (uit_codigo_usuario);


--
-- TOC entry 2727 (class 1259 OID 34816)
-- Name: fki_codigo_usuario_fk1; Type: INDEX; Schema: administracion_seguridad; Owner: esamyn_user
--

CREATE INDEX fki_codigo_usuario_fk1 ON asg_usuario_perfil USING btree (uro_codigo_usuario);


SET search_path = esamyn, pg_catalog;

--
-- TOC entry 2742 (class 1259 OID 34817)
-- Name: fki_esa_evaluacion_eva_tipo_evaluacion_fkey; Type: INDEX; Schema: esamyn; Owner: esamyn_user
--

CREATE INDEX fki_esa_evaluacion_eva_tipo_evaluacion_fkey ON esa_evaluacion USING btree (eva_tipo_evaluacion);


--
-- TOC entry 2778 (class 1259 OID 35165)
-- Name: fki_fk_pei_ess; Type: INDEX; Schema: esamyn; Owner: esamyn_user
--

CREATE INDEX fki_fk_pei_ess ON esa_permiso_ingreso USING btree (pei_establecimiento_salud);


--
-- TOC entry 2779 (class 1259 OID 35159)
-- Name: fki_fk_pei_usu; Type: INDEX; Schema: esamyn; Owner: esamyn_user
--

CREATE INDEX fki_fk_pei_usu ON esa_permiso_ingreso USING btree (pei_usuario);


SET search_path = medicina_prepagada, pg_catalog;

--
-- TOC entry 2775 (class 1259 OID 34818)
-- Name: fki_mpp_codigo_archivo_fk; Type: INDEX; Schema: medicina_prepagada; Owner: esamyn_user
--

CREATE INDEX fki_mpp_codigo_archivo_fk ON mpp_historial_archivo USING btree (cht_codigo_archivo);


SET search_path = administracion_general, pg_catalog;

--
-- TOC entry 2780 (class 2606 OID 34819)
-- Name: agn_canton can_codigo_provincia_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_canton
    ADD CONSTRAINT can_codigo_provincia_fk FOREIGN KEY (can_codigo_provincia) REFERENCES agn_provincia(pro_codigo_provincia);


--
-- TOC entry 2786 (class 2606 OID 34824)
-- Name: agn_parroquia codigo_canton_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_parroquia
    ADD CONSTRAINT codigo_canton_fk FOREIGN KEY (par_codigo_canton) REFERENCES agn_canton(can_codigo_canton);


--
-- TOC entry 2781 (class 2606 OID 34829)
-- Name: agn_catalogo codigo_catalogo_padre_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_catalogo
    ADD CONSTRAINT codigo_catalogo_padre_fk FOREIGN KEY (cat_codigo_catalogo_padre) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2783 (class 2606 OID 34834)
-- Name: agn_establecimiento codigo_distrito_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_establecimiento
    ADD CONSTRAINT codigo_distrito_fk FOREIGN KEY (est_codigo_distrito) REFERENCES agn_distrito(dis_codigo_distrito);


--
-- TOC entry 2784 (class 2606 OID 34839)
-- Name: agn_establecimiento codigo_entidad_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_establecimiento
    ADD CONSTRAINT codigo_entidad_fk FOREIGN KEY (est_codigo_entidad) REFERENCES agn_entidad(ent_codigo_entidad);


--
-- TOC entry 2787 (class 2606 OID 34844)
-- Name: agn_persona codigo_estado_civil_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_estado_civil_fk FOREIGN KEY (per_codigo_cat_estado_civil) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2788 (class 2606 OID 34849)
-- Name: agn_persona codigo_etnia_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_etnia_fk FOREIGN KEY (per_codigo_cat_etnia) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2789 (class 2606 OID 34854)
-- Name: agn_persona codigo_nacionalidad_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_nacionalidad_fk FOREIGN KEY (per_codigo_cat_nacionalidad) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2790 (class 2606 OID 34859)
-- Name: agn_persona codigo_nacionalidad_org_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_nacionalidad_org_fk FOREIGN KEY (per_codigo_cat_nacionalidad_org) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2791 (class 2606 OID 34864)
-- Name: agn_persona codigo_parroquia_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_parroquia_fk FOREIGN KEY (per_codigo_parroquia) REFERENCES agn_parroquia(par_codigo_parroquia);


--
-- TOC entry 2785 (class 2606 OID 34869)
-- Name: agn_establecimiento codigo_parroquia_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_establecimiento
    ADD CONSTRAINT codigo_parroquia_fk FOREIGN KEY (est_codigo_parroquia) REFERENCES agn_parroquia(par_codigo_parroquia);


--
-- TOC entry 2792 (class 2606 OID 34874)
-- Name: agn_persona codigo_pueblo_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_pueblo_fk FOREIGN KEY (per_codigo_cat_pueblo) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2793 (class 2606 OID 34879)
-- Name: agn_persona codigo_tipo_entidad_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_persona
    ADD CONSTRAINT codigo_tipo_entidad_fk FOREIGN KEY (per_codigo_cat_tipo_entidad) REFERENCES agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2782 (class 2606 OID 34884)
-- Name: agn_distrito dis_codigo_zona_fk; Type: FK CONSTRAINT; Schema: administracion_general; Owner: esamyn_user
--

ALTER TABLE ONLY agn_distrito
    ADD CONSTRAINT dis_codigo_zona_fk FOREIGN KEY (dis_codigo_zona) REFERENCES agn_zona(zon_codigo_zona);


SET search_path = administracion_seguridad, pg_catalog;

--
-- TOC entry 2794 (class 2606 OID 34889)
-- Name: asg_aplicacion catalogo_proceso_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_aplicacion
    ADD CONSTRAINT catalogo_proceso_fk FOREIGN KEY (apl_codigo_cat_proceso) REFERENCES administracion_general.agn_catalogo(cat_codigo_catalogo);


--
-- TOC entry 2795 (class 2606 OID 34894)
-- Name: asg_menu codigo_aplicacion_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_menu
    ADD CONSTRAINT codigo_aplicacion_fk FOREIGN KEY (men_codigo_aplicacion) REFERENCES asg_aplicacion(apl_codigo_aplicacion);


--
-- TOC entry 2797 (class 2606 OID 34899)
-- Name: asg_perfil codigo_aplicacion_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_perfil
    ADD CONSTRAINT codigo_aplicacion_fk FOREIGN KEY (prl_codigo_aplicacion) REFERENCES asg_aplicacion(apl_codigo_aplicacion);


--
-- TOC entry 2798 (class 2606 OID 34904)
-- Name: asg_rol codigo_aplicacion_fk1; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol
    ADD CONSTRAINT codigo_aplicacion_fk1 FOREIGN KEY (rol_codigo_aplicacion) REFERENCES asg_aplicacion(apl_codigo_aplicacion);


--
-- TOC entry 2803 (class 2606 OID 34909)
-- Name: asg_usuario_establecimiento codigo_establecimiento_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_establecimiento
    ADD CONSTRAINT codigo_establecimiento_fk FOREIGN KEY (uit_codigo_establecimiento) REFERENCES administracion_general.agn_establecimiento(est_codigo_establecimiento);


--
-- TOC entry 2800 (class 2606 OID 34914)
-- Name: asg_rol_menu codigo_menu_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol_menu
    ADD CONSTRAINT codigo_menu_fk FOREIGN KEY (rmn_codigo_menu) REFERENCES asg_menu(men_codigo_menu);


--
-- TOC entry 2796 (class 2606 OID 34919)
-- Name: asg_menu codigo_menu_padre_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_menu
    ADD CONSTRAINT codigo_menu_padre_fk FOREIGN KEY (men_codigo_menu_padre) REFERENCES asg_menu(men_codigo_menu);


--
-- TOC entry 2799 (class 2606 OID 34924)
-- Name: asg_rol codigo_perfil_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol
    ADD CONSTRAINT codigo_perfil_fk FOREIGN KEY (rol_codigo_perfil) REFERENCES asg_perfil(prl_codigo_perfil);


--
-- TOC entry 2806 (class 2606 OID 34929)
-- Name: asg_usuario_perfil codigo_perfil_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_perfil
    ADD CONSTRAINT codigo_perfil_fk FOREIGN KEY (uro_codigo_perfil) REFERENCES asg_perfil(prl_codigo_perfil);


--
-- TOC entry 2802 (class 2606 OID 34934)
-- Name: asg_usuario codigo_persona_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario
    ADD CONSTRAINT codigo_persona_fk FOREIGN KEY (usu_codigo_persona) REFERENCES administracion_general.agn_persona(per_codigo_persona);


--
-- TOC entry 2801 (class 2606 OID 34939)
-- Name: asg_rol_menu codigo_rol_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_rol_menu
    ADD CONSTRAINT codigo_rol_fk FOREIGN KEY (rmn_codigo_rol) REFERENCES asg_rol(rol_codigo_rol);


--
-- TOC entry 2804 (class 2606 OID 34944)
-- Name: asg_usuario_establecimiento codigo_usuario_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_establecimiento
    ADD CONSTRAINT codigo_usuario_fk FOREIGN KEY (uit_codigo_usuario) REFERENCES asg_usuario(usu_codigo_usuario);


--
-- TOC entry 2807 (class 2606 OID 34949)
-- Name: asg_usuario_perfil codigo_usuario_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_perfil
    ADD CONSTRAINT codigo_usuario_fk FOREIGN KEY (uro_codigo_usuario) REFERENCES asg_usuario(usu_codigo_usuario);


--
-- TOC entry 2805 (class 2606 OID 34954)
-- Name: asg_usuario_logueado codigo_usuario_fk; Type: FK CONSTRAINT; Schema: administracion_seguridad; Owner: esamyn_user
--

ALTER TABLE ONLY asg_usuario_logueado
    ADD CONSTRAINT codigo_usuario_fk FOREIGN KEY (ulg_codigo_usuario) REFERENCES asg_usuario(usu_codigo_usuario);


SET search_path = esamyn, pg_catalog;

--
-- TOC entry 2808 (class 2606 OID 34959)
-- Name: esa_canton esa_canton_can_provincia_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_canton
    ADD CONSTRAINT esa_canton_can_provincia_fkey FOREIGN KEY (can_provincia) REFERENCES esa_provincia(pro_id);


--
-- TOC entry 2809 (class 2606 OID 34964)
-- Name: esa_cumple_condicion_no_aplica esa_cumple_condicion_no_aplica_ccn_condicion_no_aplica_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_cumple_condicion_no_aplica
    ADD CONSTRAINT esa_cumple_condicion_no_aplica_ccn_condicion_no_aplica_fkey FOREIGN KEY (ccn_condicion_no_aplica) REFERENCES esa_condicion_no_aplica(cna_id);


--
-- TOC entry 2810 (class 2606 OID 34969)
-- Name: esa_cumple_condicion_no_aplica esa_cumple_condicion_no_aplica_ccn_evaluacion_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_cumple_condicion_no_aplica
    ADD CONSTRAINT esa_cumple_condicion_no_aplica_ccn_evaluacion_fkey FOREIGN KEY (ccn_evaluacion) REFERENCES esa_evaluacion(eva_id);


--
-- TOC entry 2811 (class 2606 OID 34974)
-- Name: esa_encuesta esa_encuesta_enc_establecimiento_salud_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_encuesta
    ADD CONSTRAINT esa_encuesta_enc_establecimiento_salud_fkey FOREIGN KEY (enc_establecimiento_salud) REFERENCES esa_establecimiento_salud(ess_id);


--
-- TOC entry 2812 (class 2606 OID 34979)
-- Name: esa_encuesta esa_encuesta_enc_evaluacion_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_encuesta
    ADD CONSTRAINT esa_encuesta_enc_evaluacion_fkey FOREIGN KEY (enc_evaluacion) REFERENCES esa_evaluacion(eva_id);


--
-- TOC entry 2813 (class 2606 OID 34984)
-- Name: esa_encuesta esa_encuesta_enc_formulario_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_encuesta
    ADD CONSTRAINT esa_encuesta_enc_formulario_fkey FOREIGN KEY (enc_formulario) REFERENCES esa_formulario(frm_id);


--
-- TOC entry 2814 (class 2606 OID 34989)
-- Name: esa_encuesta esa_encuesta_enc_usuario_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_encuesta
    ADD CONSTRAINT esa_encuesta_enc_usuario_fkey FOREIGN KEY (enc_usuario) REFERENCES esa_usuario(usu_id);


--
-- TOC entry 2815 (class 2606 OID 34994)
-- Name: esa_establecimiento_salud esa_establecimiento_salud_ess_canton_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_establecimiento_salud
    ADD CONSTRAINT esa_establecimiento_salud_ess_canton_fkey FOREIGN KEY (ess_canton) REFERENCES esa_canton(can_id);


--
-- TOC entry 2816 (class 2606 OID 34999)
-- Name: esa_establecimiento_salud esa_establecimiento_salud_ess_persona_juridica_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_establecimiento_salud
    ADD CONSTRAINT esa_establecimiento_salud_ess_persona_juridica_fkey FOREIGN KEY (ess_persona_juridica) REFERENCES esa_persona_juridica(pju_id);


--
-- TOC entry 2817 (class 2606 OID 35004)
-- Name: esa_evaluacion esa_evaluacion_eva_establecimiento_salud_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_evaluacion
    ADD CONSTRAINT esa_evaluacion_eva_establecimiento_salud_fkey FOREIGN KEY (eva_establecimiento_salud) REFERENCES esa_establecimiento_salud(ess_id);


--
-- TOC entry 2818 (class 2606 OID 35009)
-- Name: esa_evaluacion esa_evaluacion_eva_tipo_evaluacion_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_evaluacion
    ADD CONSTRAINT esa_evaluacion_eva_tipo_evaluacion_fkey FOREIGN KEY (eva_tipo_evaluacion) REFERENCES esa_tipo_evaluacion(tev_id);


--
-- TOC entry 2819 (class 2606 OID 35014)
-- Name: esa_evaluacion esa_evaluacion_eva_usuario_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_evaluacion
    ADD CONSTRAINT esa_evaluacion_eva_usuario_fkey FOREIGN KEY (eva_usuario) REFERENCES esa_usuario(usu_id);


--
-- TOC entry 2820 (class 2606 OID 35019)
-- Name: esa_grupo_parametro esa_grupo_parametro_gpa_padre_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_grupo_parametro
    ADD CONSTRAINT esa_grupo_parametro_gpa_padre_fkey FOREIGN KEY (gpa_padre) REFERENCES esa_grupo_parametro(gpa_id);


--
-- TOC entry 2821 (class 2606 OID 35024)
-- Name: esa_grupo_parametro esa_grupo_parametro_gpa_tipo_grupo_parametro_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_grupo_parametro
    ADD CONSTRAINT esa_grupo_parametro_gpa_tipo_grupo_parametro_fkey FOREIGN KEY (gpa_tipo_grupo_parametro) REFERENCES esa_tipo_grupo_parametro(tgp_id);


--
-- TOC entry 2822 (class 2606 OID 35029)
-- Name: esa_parametro esa_parametro_par_condicion_no_aplica_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro
    ADD CONSTRAINT esa_parametro_par_condicion_no_aplica_fkey FOREIGN KEY (par_condicion_no_aplica) REFERENCES esa_condicion_no_aplica(cna_id);


--
-- TOC entry 2823 (class 2606 OID 35034)
-- Name: esa_parametro esa_parametro_par_grupo_parametro_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro
    ADD CONSTRAINT esa_parametro_par_grupo_parametro_fkey FOREIGN KEY (par_grupo_parametro) REFERENCES esa_grupo_parametro(gpa_id);


--
-- TOC entry 2824 (class 2606 OID 35039)
-- Name: esa_parametro_pregunta esa_parametro_pregunta_ppr_parametro_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro_pregunta
    ADD CONSTRAINT esa_parametro_pregunta_ppr_parametro_fkey FOREIGN KEY (ppr_parametro) REFERENCES esa_parametro(par_id);


--
-- TOC entry 2825 (class 2606 OID 35044)
-- Name: esa_parametro_pregunta esa_parametro_pregunta_ppr_pregunta_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_parametro_pregunta
    ADD CONSTRAINT esa_parametro_pregunta_ppr_pregunta_fkey FOREIGN KEY (ppr_pregunta) REFERENCES esa_pregunta(prg_id);


--
-- TOC entry 2826 (class 2606 OID 35049)
-- Name: esa_pregunta esa_pregunta_prg_formulario_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_pregunta
    ADD CONSTRAINT esa_pregunta_prg_formulario_fkey FOREIGN KEY (prg_formulario) REFERENCES esa_formulario(frm_id);


--
-- TOC entry 2827 (class 2606 OID 35054)
-- Name: esa_pregunta esa_pregunta_prg_padre_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_pregunta
    ADD CONSTRAINT esa_pregunta_prg_padre_fkey FOREIGN KEY (prg_padre) REFERENCES esa_pregunta(prg_id);


--
-- TOC entry 2828 (class 2606 OID 35059)
-- Name: esa_pregunta esa_pregunta_prg_tipo_pregunta_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_pregunta
    ADD CONSTRAINT esa_pregunta_prg_tipo_pregunta_fkey FOREIGN KEY (prg_tipo_pregunta) REFERENCES esa_tipo_pregunta(tpp_id);


--
-- TOC entry 2829 (class 2606 OID 35064)
-- Name: esa_respuesta esa_respuesta_res_encuesta_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_respuesta
    ADD CONSTRAINT esa_respuesta_res_encuesta_fkey FOREIGN KEY (res_encuesta) REFERENCES esa_encuesta(enc_id);


--
-- TOC entry 2830 (class 2606 OID 35069)
-- Name: esa_respuesta esa_respuesta_res_pregunta_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_respuesta
    ADD CONSTRAINT esa_respuesta_res_pregunta_fkey FOREIGN KEY (res_pregunta) REFERENCES esa_pregunta(prg_id);


--
-- TOC entry 2831 (class 2606 OID 35074)
-- Name: esa_usuario esa_usuario_usu_rol_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_usuario
    ADD CONSTRAINT esa_usuario_usu_rol_fkey FOREIGN KEY (usu_rol) REFERENCES esa_rol(rol_id);


--
-- TOC entry 2832 (class 2606 OID 35079)
-- Name: esa_verificador esa_verificador_ver_cumple_condicion_no_aplica_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_verificador
    ADD CONSTRAINT esa_verificador_ver_cumple_condicion_no_aplica_fkey FOREIGN KEY (ver_cumple_condicion_no_aplica) REFERENCES esa_cumple_condicion_no_aplica(ccn_id);


--
-- TOC entry 2833 (class 2606 OID 35084)
-- Name: esa_verificador esa_verificador_ver_evaluacion_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_verificador
    ADD CONSTRAINT esa_verificador_ver_evaluacion_fkey FOREIGN KEY (ver_evaluacion) REFERENCES esa_evaluacion(eva_id);


--
-- TOC entry 2834 (class 2606 OID 35089)
-- Name: esa_verificador esa_verificador_ver_parametro_fkey; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_verificador
    ADD CONSTRAINT esa_verificador_ver_parametro_fkey FOREIGN KEY (ver_parametro) REFERENCES esa_parametro(par_id);


--
-- TOC entry 2836 (class 2606 OID 35160)
-- Name: esa_permiso_ingreso fk_pei_ess; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_permiso_ingreso
    ADD CONSTRAINT fk_pei_ess FOREIGN KEY (pei_establecimiento_salud) REFERENCES esa_establecimiento_salud(ess_id);


--
-- TOC entry 2837 (class 2606 OID 35154)
-- Name: esa_permiso_ingreso fk_pei_usu; Type: FK CONSTRAINT; Schema: esamyn; Owner: esamyn_user
--

ALTER TABLE ONLY esa_permiso_ingreso
    ADD CONSTRAINT fk_pei_usu FOREIGN KEY (pei_usuario) REFERENCES esa_usuario(usu_id);


SET search_path = medicina_prepagada, pg_catalog;

--
-- TOC entry 2835 (class 2606 OID 35094)
-- Name: mpp_historial_archivo mpp_codigo_archivo_fk; Type: FK CONSTRAINT; Schema: medicina_prepagada; Owner: esamyn_user
--

ALTER TABLE ONLY mpp_historial_archivo
    ADD CONSTRAINT mpp_codigo_archivo_fk FOREIGN KEY (cht_codigo_archivo) REFERENCES mpp_archivo(arc_codigo_archivo);


-- Completed on 2017-11-06 08:39:00 -05

--
-- PostgreSQL database dump complete
--

