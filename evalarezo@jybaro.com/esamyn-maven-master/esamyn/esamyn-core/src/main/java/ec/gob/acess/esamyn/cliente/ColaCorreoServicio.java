
package ec.gob.acess.esamyn.cliente;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;

import org.jboss.logging.Logger;

import ec.gob.acess.esamyn.dto.MailMessage;

/**
 * 
 * Clase: QueueMailServicio.java
 * @author Duval Barragan
 * @date Aug 25, 2017
 * @version 1.0
 *
 */
@Stateless(name = "ClienteColaCorreoServicio")
@LocalBean
public class ColaCorreoServicio {

	private static final Logger LOG = Logger.getLogger(ColaCorreoServicio.class);

	@Resource(mappedName = "java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;

	@Resource(mappedName = "java:/jms/queue/MailESAMYN")
	private Queue queue;

	/**
	 * Metodo encola correo
	 * @param mmessage
	 */
	public void encolarMail(MailMessage mmessage) {

		LOG.info("ENCOLANDO CORREO...");

		Connection connection = null;
		Session session = null;

		try {
			connection = connectionFactory.createConnection();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			MessageProducer messageProducer = session.createProducer(queue);
			// objeto a encolar
			ObjectMessage objectMessage = session.createObjectMessage();
			objectMessage.setObject(mmessage);

			messageProducer.send(objectMessage);

		} catch (JMSException e) {
			LOG.error(e.getMessage());
		} finally {
			if (session != null) {
				try {
					session.close();
					if (connection != null) {
						connection.close();
					}
				} catch (JMSException e) {
					LOG.error(e.getMessage());
				}
			}
		}
	}
}
