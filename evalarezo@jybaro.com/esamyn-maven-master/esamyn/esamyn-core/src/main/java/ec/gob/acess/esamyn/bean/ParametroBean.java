
package ec.gob.acess.esamyn.bean;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.ParametroDAO;
import ec.gob.acess.esamyn.dto.MensajeDto;
import ec.gob.acess.esamyn.modelo.Parametro;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase ParametroBean.java a sido creda para manejar loica de Parametro.java
 *
 */
@Stateless
@LocalBean
public class ParametroBean extends GenericServiceImpl<Parametro, Long> {

	@EJB
	private ParametroDAO parametroDAO;
	/**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return parametroDAO
	 */
	@Override
	public GenericDao<Parametro, Long> getDao() {
		return parametroDAO;
	}
	/**
	 * 
	 * @param parametro
	 * @return
	 */
	public MensajeDto guardar(Parametro parametro) {

		MensajeDto mensajeDto = new MensajeDto();

		try {

			if (parametro.getCodigo() == null) {

				mensajeDto.setError(false);
				mensajeDto.setMensaje("Parametro Guardado");
				create(parametro);
				mensajeDto.setObjeto(parametro);
			} else {
				mensajeDto.setError(false);
				mensajeDto.setMensaje("Actualiza Objeto");
				update(parametro);
				mensajeDto.setObjeto(parametro);
			}

		} catch (Exception e) {
			mensajeDto.setError(true);
			mensajeDto.setMensaje("Error al guardar: " + e.getMessage());
			mensajeDto.setObjeto(null);
		}

		return mensajeDto;

	}

}
