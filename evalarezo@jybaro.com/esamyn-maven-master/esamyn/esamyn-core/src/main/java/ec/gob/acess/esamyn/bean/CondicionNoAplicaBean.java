
package ec.gob.acess.esamyn.bean;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.CondicionDAO;
import ec.gob.acess.esamyn.dto.MensajeDto;
import ec.gob.acess.esamyn.modelo.CondicionNoAplica;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase CondicionNoAplicaBean.java a sido creda para manejar logica de CondicionNoAplica.java
 *
 */
@Stateless
@LocalBean
public class CondicionNoAplicaBean extends GenericServiceImpl<CondicionNoAplica, Long> {

	@EJB
	private CondicionDAO condicionNoAplicaDAO;
	/**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return condicionNoAplicaDAO
	 */
	@Override
	public GenericDao<CondicionNoAplica, Long> getDao() {
		return condicionNoAplicaDAO;
	}
	/**
	 * Metodo Guardar
	 * 
	 * @param condicionNoAplica
	 * @return mensajeDto
	 */
	public MensajeDto guardar(CondicionNoAplica condicionNoAplica) {

		MensajeDto mensajeDto = new MensajeDto();

		try {

			if (condicionNoAplica.getCodigo() == null) {

				mensajeDto.setError(false);
				mensajeDto.setMensaje("CondicionNoAplica Guardado");
				create(condicionNoAplica);
				mensajeDto.setObjeto(condicionNoAplica);
			} else {
				mensajeDto.setError(false);
				mensajeDto.setMensaje("Actualiza Objeto");
				update(condicionNoAplica);
				mensajeDto.setObjeto(condicionNoAplica);
			}

		} catch (Exception e) {
			mensajeDto.setError(true);
			mensajeDto.setMensaje("Error al guardar: " + e.getMessage());
			mensajeDto.setObjeto(null);
		}

		return mensajeDto;

	}

}
