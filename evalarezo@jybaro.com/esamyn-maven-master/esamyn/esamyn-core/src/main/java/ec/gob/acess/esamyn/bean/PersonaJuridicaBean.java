
package ec.gob.acess.esamyn.bean;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.PersonaJuridicaDAO;
import ec.gob.acess.esamyn.dto.MensajeDto;
import ec.gob.acess.esamyn.modelo.PersonaJuridica;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase PersonaJuridicaBean.java a sido creda para manejar logica de PersonaJuridica.java
 *
 */
@Stateless
@LocalBean
public class PersonaJuridicaBean extends GenericServiceImpl<PersonaJuridica, Long> {

	@EJB
	private PersonaJuridicaDAO personaJuridicaDAO;
	/**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return personaJuridicaDAO
	 */
	@Override
	public GenericDao<PersonaJuridica, Long> getDao() {
		return personaJuridicaDAO;
	}


    /**
     * Metodo Guardar Objeto
     * 
     * @param personaJuridica
     * @return mensajeDto
     */
    public MensajeDto guardar(PersonaJuridica personaJuridica) {

	MensajeDto mensajeDto = new MensajeDto();

	try {

	    if (personaJuridica.getCodigo() == null) {

		mensajeDto.setError(false);
		mensajeDto.setMensaje("PersonaJuridica Guardado");
		create(personaJuridica);
		mensajeDto.setObjeto(personaJuridica);
	    } else {
		mensajeDto.setError(false);
		mensajeDto.setMensaje("Actualiza Objeto");
		update(personaJuridica);
		mensajeDto.setObjeto(personaJuridica);
	    }

	} catch (Exception e) {
	    mensajeDto.setError(true);
	    mensajeDto.setMensaje("Error al guardar: " + e.getMessage());
	    mensajeDto.setObjeto(null);
	}

	return mensajeDto;

    }

}
