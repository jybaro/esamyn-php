
package ec.gob.acess.esamyn.bean;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.constant.CriteriaTypeEnum;
import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;
import com.saviasoft.util.Criteria;

import ec.gob.acess.esamyn.dao.VerificadorDAO;
import ec.gob.acess.esamyn.modelo.Verificador;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 *
 *          La Clase VerificadorBean.java a sido creda para manejar logica de
 *          Verificador.java
 *
 */
@Stateless
@LocalBean
public class VerificadorBean extends GenericServiceImpl<Verificador, Long> {

	@EJB
	private VerificadorDAO verificadorDAO;

	/**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return verificadorDAO
	 */
	@Override
	public GenericDao<Verificador, Long> getDao() {
		return verificadorDAO;
	}

	/**
	 * busca por evaluacion
	 * 
	 * @param idEvaluacion
	 * @return
	 */
	public List<Verificador> listaPorEvaluacion(Long idEvaluacion) {

		String[] codigoEvaluacion = { "evaluacion.codigo" };
		CriteriaTypeEnum[] operador = { CriteriaTypeEnum.LONG_EQUALS };
		Object[] valores = { idEvaluacion };

		Criteria criteria = new Criteria(codigoEvaluacion, operador, valores);

		return findByCriterias(criteria);
	}

}
