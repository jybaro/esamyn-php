
package ec.gob.acess.esamyn.bean;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.CantonDAO;
import ec.gob.acess.esamyn.dto.MensajeDto;
import ec.gob.acess.esamyn.modelo.Canton;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase CantonBean.java a sido creda para manejar logica del Canton.java 
 *
 */
@Stateless
@LocalBean
public class CantonBean extends GenericServiceImpl<Canton, Long> {
	
    @EJB
    private CantonDAO cantonDAO;
    /**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return cantonDAO
	 */
    @Override
    public GenericDao<Canton, Long> getDao() {
	return cantonDAO;
    }

    /**
     * Metodo guardar
     * 
     * @param canton
     * @return mensajeDto
     */
    public MensajeDto guardar(Canton canton) {

	MensajeDto mensajeDto = new MensajeDto();

	try {

	    if (canton.getCodigo() == null) {

		mensajeDto.setError(false);
		mensajeDto.setMensaje("Canton Guardado");
		create(canton);
		mensajeDto.setObjeto(canton);
	    } else {
		mensajeDto.setError(false);
		mensajeDto.setMensaje("Actualiza Objeto");
		update(canton);
		mensajeDto.setObjeto(canton);
	    }

	} catch (Exception e) {
	    mensajeDto.setError(true);
	    mensajeDto.setMensaje("Error al guardar: " + e.getMessage());
	    mensajeDto.setObjeto(null);

	}
	return mensajeDto;
    }

}
