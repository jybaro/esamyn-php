
package ec.gob.acess.esamyn.bean;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.constant.CriteriaTypeEnum;
import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;
import com.saviasoft.util.Criteria;

import ec.gob.acess.esamyn.dao.RespuestaDAO;
import ec.gob.acess.esamyn.modelo.Respuesta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase RespuestaBean.java a sido creda para manejar logica de Respuesta.java 
 *
 */
@Stateless
@LocalBean
public class RespuestaBean extends GenericServiceImpl<Respuesta, Long> {

    @EJB
    private RespuestaDAO respuestaDAO;
    /**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return respuestaDAO
	 */
    @Override
    public GenericDao<Respuesta, Long> getDao() {
	return respuestaDAO;
    }

    /**
     * Buscar lista por encuesta
     * 
     * @param idEncuesta
     * @return
     */
    public List<Respuesta> buscarPorEncuesta(Long idEncuesta) {

	String[] ands = { "encuesta.codigo" };
	CriteriaTypeEnum[] operator = { CriteriaTypeEnum.LONG_EQUALS };
	Object[] valores = { idEncuesta };
	String[] orderby = { "codigo" };
	boolean[] asc = { true };

	Criteria criteria = new Criteria(ands, operator, valores, orderby, asc);

	return findByCriterias(criteria);

    }

}
