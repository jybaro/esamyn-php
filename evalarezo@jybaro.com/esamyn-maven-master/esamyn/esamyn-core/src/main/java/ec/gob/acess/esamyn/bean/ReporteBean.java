
package ec.gob.acess.esamyn.bean;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.RespuestaDAO;
import ec.gob.acess.esamyn.dto.RespuestaDto;
import ec.gob.acess.esamyn.modelo.Formulario;
import ec.gob.acess.esamyn.modelo.Respuesta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase ReporteBean.java a sido creda para manejar logica de Respuesta.java 
 *
 */
@Stateless
@LocalBean
public class ReporteBean extends GenericServiceImpl<Respuesta, Long> {

    @EJB
    private RespuestaDAO respuestaDAO;

    @EJB
    private PreguntaBean preguntaBean;

    @EJB
    private FormularioBean formularioBean;
    /**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return respuestaDAO
	 */
    @Override
    public GenericDao<Respuesta, Long> getDao() {
	return respuestaDAO;
    }
    /**
     * 
     * @param idFormulario
     * @param idEstablecimiento
     * @return
     * @throws IOException
     */
    public XSSFWorkbook generarDocumento(Long idFormulario, Long idEstablecimiento) throws IOException {

	Formulario formulario = formularioBean.findByPk(idFormulario);

	XSSFWorkbook libro = new XSSFWorkbook();
	XSSFSheet hoja = libro.createSheet(formulario.getTitulo());

	CellStyle estiloCabecera = libro.createCellStyle();
	estiloCabecera.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
	estiloCabecera.setAlignment(estiloCabecera.ALIGN_CENTER);
	estiloCabecera.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);

	// ENCABEZADO TABLAS
	Row fila = hoja.createRow(0);

	Cell celda = fila.createCell(0);
	celda.setCellStyle(estiloCabecera);
	celda = fila.createCell(0);
	celda.setCellValue((String) "UNICODIGO");
	celda = fila.createCell(1);
	celda.setCellValue((String) "SECUENCIAL");
	celda = fila.createCell(2);
	celda.setCellValue((String) "RESPONSABLE");
	celda = fila.createCell(3);
	celda.setCellValue((String) "CARGO");
	celda = fila.createCell(4);
	celda.setCellValue((String) "CREADO pOR");
	celda = fila.createCell(5);
	celda.setCellValue((String) "FECHA DE INICIO EVALUACION");
	celda = fila.createCell(6);
	celda.setCellValue((String) "FECHA DE INICIO ENCUESTA");
	celda = fila.createCell(7);
	celda.setCellValue((String) "FINALIZADA?");

	Map<Long, String> mapaPreguntas = preguntaBean.buscarPreguntas(idFormulario);

	int contador = 8;
	for (Map.Entry<Long, String> pregunta : mapaPreguntas.entrySet()) {

	    celda = fila.createCell(contador);
	    celda.setCellValue((String) pregunta.getValue());

	    contador++;
	}

	List<RespuestaDto> listaRespuesta = respuestaDAO.respuestasParaReporte(idFormulario, idEstablecimiento);

	// LLENA DATOS RESPUESTA

	int filaContador = 1;
	for (RespuestaDto respuestaDto : listaRespuesta) {

	    fila = hoja.createRow(filaContador);
	    celda = fila.createCell(0);
	    celda.setCellValue((String) respuestaDto.getUnicodigo());
	    celda = fila.createCell(1);
	    celda.setCellValue((Long) respuestaDto.getSecuencial());
	    celda = fila.createCell(2);
	    celda.setCellValue((String) respuestaDto.getResponsable());
	    celda = fila.createCell(3);
	    celda.setCellValue((String) respuestaDto.getCargo());
	    celda = fila.createCell(4);
	    celda.setCellValue((String) respuestaDto.getCreadoPor());
	    celda = fila.createCell(5);
	    celda.setCellValue((String) respuestaDto.getFechaEvaluacion());
	    celda = fila.createCell(6);
	    celda.setCellValue((String) respuestaDto.getFechaEncuesta());
	    celda = fila.createCell(7);
	    celda.setCellValue((String) respuestaDto.getFinalizada());

	    contador = 8;
	    for (Map.Entry<Long, String> pregunta : mapaPreguntas.entrySet()) {

		celda = fila.createCell(contador);
		if (respuestaDto.getIdPregunta().equals(pregunta.getKey())) {
		    celda.setCellValue((String) respuestaDto.getRespuesta());
		}

		contador++;
	    }

	    filaContador++;
	}

	return libro;

    }

}
