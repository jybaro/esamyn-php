
package ec.gob.acess.esamyn.bean;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.EstablecimientoSaludDAO;
import ec.gob.acess.esamyn.dto.MensajeDto;
import ec.gob.acess.esamyn.modelo.EstablecimientoSalud;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase EstablecimientoSaludBean.java a sido creda para manejar logica EstablecimientoSalud.java 
 *
 */
@Stateless
@LocalBean
public class EstablecimientoSaludBean extends GenericServiceImpl<EstablecimientoSalud, Long> {

    @EJB
    private EstablecimientoSaludDAO establecimientoSaludDAO;

    @EJB
    private PersonaJuridicaBean personaJuridicaBean;
    
    /**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return establecimientoSaludDAO
	 */
    @Override
    public GenericDao<EstablecimientoSalud, Long> getDao() {
	return establecimientoSaludDAO;
    }
    /**
     * Metdod Guardar
     * 
     * @param establecimientoSalud
     * @return mensajeDto
     */
    public MensajeDto guardar(EstablecimientoSalud establecimientoSalud) {

	MensajeDto mensajeDto = new MensajeDto();

	if (establecimientoSalud.getPersonaJuridica() != null) {
	    if (establecimientoSalud.getPersonaJuridica().getCodigo() == null) {
		personaJuridicaBean.create(establecimientoSalud.getPersonaJuridica());
	    } else {
		personaJuridicaBean.update(establecimientoSalud.getPersonaJuridica());
	    }
	}

	try {

	    if (establecimientoSalud.getCodigo() == null) {

		mensajeDto.setError(false);
		mensajeDto.setMensaje("Establecimiento de Salud Guardado");
		create(establecimientoSalud);
		mensajeDto.setObjeto(establecimientoSalud);
	    } else {
		mensajeDto.setError(false);
		mensajeDto.setMensaje("Actualiza Objeto");
		update(establecimientoSalud);
		mensajeDto.setObjeto(establecimientoSalud);
	    }

	} catch (Exception e) {
	    mensajeDto.setError(true);
	    mensajeDto.setMensaje("Error al guardar: " + e.getMessage());
	    mensajeDto.setObjeto(null);
	}

	return mensajeDto;

    }

}
