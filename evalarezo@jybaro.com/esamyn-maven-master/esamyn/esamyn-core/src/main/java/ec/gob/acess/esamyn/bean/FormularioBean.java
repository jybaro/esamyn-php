
package ec.gob.acess.esamyn.bean;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.saviasoft.persistence.util.dao.GenericDao;
import com.saviasoft.persistence.util.service.impl.GenericServiceImpl;

import ec.gob.acess.esamyn.dao.FormularioDAO;
import ec.gob.acess.esamyn.dto.MensajeDto;
import ec.gob.acess.esamyn.modelo.Formulario;


/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase FormularioBean.java a sido creda para manejar logica de Formulario.java 
 *
 */
@Stateless
@LocalBean
public class FormularioBean extends GenericServiceImpl<Formulario, Long> {

	@EJB
	private FormularioDAO formularioDAO;
	/**
	 * Metodo que Sobrescribe GenericDao
	 * 
	 * @return formularioDAO
	 */
	@Override
	public GenericDao<Formulario, Long> getDao() {
		return formularioDAO;
	}
	/**
	 * 
	 * @param codigo
	 * @param textoFormulario
	 * @return
	 */
	public MensajeDto editar(Long codigo, String textoFormulario) {
      
      MensajeDto mensajeDto;

	Formulario formulario = findByPk(codigo);

	if (formulario != null) {

	    formulario.setTitulo(textoFormulario);
	    update(formulario);

	    mensajeDto = new MensajeDto(false, "Actualiza Objeto", formulario);

	} else {
	    mensajeDto = new MensajeDto(true, "No existe pregunta para el id: " + codigo, null);
	}

	return mensajeDto;
  }

}
