
package ec.gob.acess.esamyn.exception;

import javax.ejb.ApplicationException;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase MailException.java a sido creda para excepciones de correo
 */
@ApplicationException(rollback = true)
public class MailException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = -7156341398429647282L;
    private String resumen;
    private String detalle;
    private Throwable causa;
    /**
     * 
     * Constructor clase MailException.java
     * @param resumen
     */
    public MailException(String resumen) {
	this.resumen = resumen;
    }
    /**
     * 
     * Constructor clase MailException.java
     * @param resumen
     * @param causa
     */
    public MailException(String resumen, Throwable causa) {
	this.resumen = resumen;
	this.causa = causa;
    }
    /**
     * 
     * Constructor clase MailException.java
     * @param resumen
     * @param detalle
     * @param causa
     */
    public MailException(String resumen, String detalle, Throwable causa) {
	this.resumen = resumen;
	this.detalle = detalle;
	this.causa = causa;
    }
	/**
	 * Metodo get 
	 * @return the resumen
	 */
	public String getResumen() {
		return resumen;
	}
	/**
	 * Metodo set
	 * @param resumen the resumen to set
	 */
	public void setResumen(String resumen) {
		this.resumen = resumen;
	}
	/**
	 * Metodo get 
	 * @return the detalle
	 */
	public String getDetalle() {
		return detalle;
	}
	/**
	 * Metodo set
	 * @param detalle the detalle to set
	 */
	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}
	/**
	 * Metodo get 
	 * @return the causa
	 */
	public Throwable getCausa() {
		return causa;
	}
	/**
	 * Metodo set
	 * @param causa the causa to set
	 */
	public void setCausa(Throwable causa) {
		this.causa = causa;
	}
	
    
}
