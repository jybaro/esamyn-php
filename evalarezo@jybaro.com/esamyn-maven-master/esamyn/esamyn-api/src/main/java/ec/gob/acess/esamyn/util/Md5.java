package ec.gob.acess.esamyn.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 *
 *          La Clase Md5.java a sido creda para codificar password
 *
 */
public class Md5 {

	/**
	 * Aplica Hash a la cadena de texto
	 * 
	 * @param cadenaACodificar
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public static String aplicarHash(String cadenaACodificar) throws NoSuchAlgorithmException {

		MessageDigest mensaje;
		mensaje = MessageDigest.getInstance("MD5");
		byte arregloMensaje[] = mensaje.digest(cadenaACodificar.getBytes());

		StringBuilder cadena = new StringBuilder();
		for (int i = 0; i < arregloMensaje.length; i++) {
			String valor = Integer.toHexString(0xFF & arregloMensaje[i]);
			if (valor.length() == 1) {
				cadena.append('0');
			}

			cadena.append(valor);
		}

		return cadena.toString();

	}

}