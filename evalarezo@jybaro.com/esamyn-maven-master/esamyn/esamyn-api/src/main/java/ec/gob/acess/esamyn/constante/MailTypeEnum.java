
package ec.gob.acess.esamyn.constante;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 *
 * La Clase MailTypeEnum.java a sido creda para manejo de correos
 *
 */
public enum MailTypeEnum {

	TEXT("text/plain"), HTML("text/html");

	private String valor;

	/**
	 * Constructor clase MailTypeEnum.java
	 * 
	 * @param valor
	 */
	private MailTypeEnum(String valor) {
		this.valor = valor;
	}

	/**
	 * Metodo get
	 * 
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}

	/**
	 * Metodo set
	 * 
	 * @param valor
	 *            the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

}
