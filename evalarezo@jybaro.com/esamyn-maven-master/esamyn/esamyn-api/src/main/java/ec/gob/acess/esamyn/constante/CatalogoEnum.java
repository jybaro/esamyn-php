
package ec.gob.acess.esamyn.constante;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * La Clase CatalogoEnum.java a sido creda para catalogo de correos
 *
 */
public enum CatalogoEnum {
    
    HOST,PUERTO,USUARIO,CONTRASENIA, PROTOCOLO, //cONFIGURACION CORREO
    TEXTO_OLVIDO //tEXTO DE OLVIDO DE CONTRASEÑA; 

}
