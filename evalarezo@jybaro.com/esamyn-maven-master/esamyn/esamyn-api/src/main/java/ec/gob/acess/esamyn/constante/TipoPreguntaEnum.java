
package ec.gob.acess.esamyn.constante;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 *
 *          Enumerador TipoPreguntaEnum.java a sido creda para identificar tipos
 *          de preguntas
 *
 */
public enum TipoPreguntaEnum {
	NUMERO("numero"), TEXTO("texto"), FECHA("fecha"), HORA("hora"), EMAIL("email");

	private String claveBdd;

	/**
	 * 
	 * Constructor clase TipoPreguntaEnum.java
	 * 
	 * @param claveBdd
	 */
	TipoPreguntaEnum(String claveBdd) {
		this.claveBdd = claveBdd;
	}

	/**
	 * Metodo get
	 * 
	 * @return the claveBdd
	 */
	public String getClaveBdd() {
		return claveBdd;
	}

	/**
	 * Obtiene el tipo de pregunta dada una clave.
	 * 
	 * @param clave
	 * @return
	 */
	public static TipoPreguntaEnum getTipoPreguntaEnumPorClave(String clave) {
		TipoPreguntaEnum respuesta = null;

		for (TipoPreguntaEnum tipoPregunta : TipoPreguntaEnum.values()) {
			if (tipoPregunta.getClaveBdd().equals(clave)) {
				respuesta = tipoPregunta;
				break;
			}
		}

		return respuesta;
	}
}
