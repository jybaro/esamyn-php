
package ec.gob.acess.esamyn.util;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import ec.gob.acess.esamyn.exception.GeneralException;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 *
 *          La Clase CifradoUtil.java a sido creda para cifrado de password
 *
 */
public class CifradoUtil {

	/**
	 * Encripta el texto con la llave
	 * 
	 * @param texto
	 * @param llave
	 * @return
	 * @throws GeneralException
	 */
	public static String encriptar(String texto, String llave) throws GeneralException {

		String textoCifrado = "";

		try {

			MessageDigest mensaje = MessageDigest.getInstance("MD5");
			byte[] arregloMensaje = mensaje.digest(llave.getBytes("utf-8"));
			byte[] arregloLlaves = Arrays.copyOf(arregloMensaje, 24);
			SecretKey secretaLlave = new SecretKeySpec(arregloLlaves, "DESede");
			Cipher cifrar = Cipher.getInstance("DESede");
			cifrar.init(Cipher.ENCRYPT_MODE, secretaLlave);
			byte[] arregloBytes = texto.getBytes("utf-8");
			byte[] arregloCifrado = cifrar.doFinal(arregloBytes);
			byte[] arreglo64 = Base64.encodeBase64(arregloCifrado);
			textoCifrado = new String(arreglo64);

		} catch (IOException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (NoSuchAlgorithmException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (NoSuchPaddingException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (InvalidKeyException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (IllegalBlockSizeException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (BadPaddingException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		}

		return textoCifrado;
	}

	/**
	 * 
	 * Desencripta la cadena con llave
	 * 
	 * @param textoEncriptado
	 * @param llave
	 * @return
	 * @throws GeneralException
	 */
	public static String desencriptar(String textoEncriptado, String llave) throws GeneralException {

		String arreglo64 = "";

		try {
			// llave para encriptar datos

			byte[] message = Base64.decodeBase64(textoEncriptado.getBytes("utf-8"));
			MessageDigest mensaje = MessageDigest.getInstance("MD5");
			byte[] digestOfPassword = mensaje.digest(llave.getBytes("utf-8"));
			byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
			SecretKey key = new SecretKeySpec(keyBytes, "DESede");

			Cipher decifrar = Cipher.getInstance("DESede");
			decifrar.init(Cipher.DECRYPT_MODE, key);

			byte[] textoPlano = decifrar.doFinal(message);

			arreglo64 = new String(textoPlano, "UTF-8");

		} catch (IOException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (NoSuchAlgorithmException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (NoSuchPaddingException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (InvalidKeyException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (IllegalBlockSizeException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		} catch (BadPaddingException e) {
			throw new GeneralException(e.getMessage(), e.getCause());
		}

		return arreglo64;
	}

}
