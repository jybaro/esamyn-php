
package ec.gob.acess.esamyn.exception;

import javax.ejb.ApplicationException;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 *
 * La Clase EvaluacionException.java a sido creda para manejo de excepciones
 *          
 *
 */
@ApplicationException(rollback = true)
public class EvaluacionException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4866001732056489950L;
	private String resumen;
	private Throwable causa;

	/**
	 * 
	 * Constructor clase EvaluacionException.java
	 * 
	 * @param resumen
	 */
	public EvaluacionException(String resumen) {
		this.resumen = resumen;
	}

	/**
	 * 
	 * Constructor clase EvaluacionException.java
	 * 
	 * @param resumen
	 * @param causa
	 */
	public EvaluacionException(String resumen, Throwable causa) {
		this.resumen = resumen;
		this.causa = causa;
	}

	/**
	 * Metodo get
	 * 
	 * @return the resumen
	 */
	public String getResumen() {
		return resumen;
	}

	/**
	 * Metodo set
	 * 
	 * @param resumen
	 *            the resumen to set
	 */
	public void setResumen(String resumen) {
		this.resumen = resumen;
	}

	/**
	 * Metodo get
	 * 
	 * @return the causa
	 */
	public Throwable getCausa() {
		return causa;
	}

	/**
	 * Metodo set
	 * 
	 * @param causa
	 *            the causa to set
	 */
	public void setCausa(Throwable causa) {
		this.causa = causa;
	}

}
