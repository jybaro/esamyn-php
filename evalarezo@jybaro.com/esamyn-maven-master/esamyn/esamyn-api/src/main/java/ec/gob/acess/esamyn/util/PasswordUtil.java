
package ec.gob.acess.esamyn.util;

import java.util.Random;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017 La Clase PasswordUtil.java a sido creda para utilidad
 *          del password
 *
 */
public class PasswordUtil {

	/**
	 * Metodo genera contrasenia aleatoria
	 * 
	 * @param longitud
	 * @return cadenaAleatoria
	 */
	public static String generaContrasenia(int longitud) {
		StringBuffer cadenaAleatoria = new StringBuffer();
		Calendar calendario = Calendar.getInstance();
		long tiempo = new java.util.GregorianCalendar().getTimeInMillis();
		Random aleatorio = new Random(tiempo);
		int contador = 0;
		while (contador < longitud) {
			char caracter = (char) aleatorio.nextInt(255);
			if ((caracter >= '0' && caracter <= '9') || (caracter >= 'A' && caracter <= 'Z')) {
				cadenaAleatoria.append(caracter);
				contador++;
			}
		}
		return cadenaAleatoria.toString().toLowerCase();
	}
}