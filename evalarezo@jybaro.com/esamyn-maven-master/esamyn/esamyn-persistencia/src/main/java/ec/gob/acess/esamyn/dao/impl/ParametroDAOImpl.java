
package ec.gob.acess.esamyn.dao.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;

import ec.gob.acess.esamyn.dao.ParametroDAO;
import ec.gob.acess.esamyn.modelo.Parametro;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase ParametroDAOImpl.java es la implementación de la Interfaz ParametroDAO.java 
 *
 */
@Stateless
public class ParametroDAOImpl extends GenericEmDaoEjb<Parametro, Long> implements ParametroDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase ParametroDAOImpl.java
	 */
	public ParametroDAOImpl() {
		super(Parametro.class);
	}

	/**
	 * Acceso a datos e implementacion del metodo
	 * 
	 * Nombre:ParametrosParaEvaluacion
	 */
	@Override
	public List<Parametro> getParametrosParaEvaluacion() {
		StringBuffer parametroEvaluacion = new StringBuffer(50);
		parametroEvaluacion.append("select p from Parametro p left outer join fetch p.parametroPreguntaList order by p.texto");

		Query query = em.createQuery(parametroEvaluacion.toString());

		return query.getResultList();
	}

}
