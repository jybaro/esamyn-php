
package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;

import com.saviasoft.persistence.util.dao.GenericDao;

import ec.gob.acess.esamyn.modelo.Formulario;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz FormularioDAO.java a sido creda para metodos de Formulario.java
 *
 */
@Local
public interface FormularioDAO extends GenericDao<Formulario, Long> {
	
}

