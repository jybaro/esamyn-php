package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;
import com.saviasoft.persistence.util.dao.GenericDao;
import ec.gob.acess.esamyn.modelo.GrupoParametro;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz GrupoParametroDAO.java a sido creda para metodos de GrupoParametro.java 
 *
 */
@Local
public interface GrupoParametroDAO extends GenericDao<GrupoParametro, Long> {

}
