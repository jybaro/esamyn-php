package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Rol.java Entidad que refleja la estructura de tabla esa_rol
 *
 */
@Entity
@Table(name = "esa_rol")
public class Rol implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "rol_id")
	private Long codigo;
	@Column(name = "rol_nombre")
	private String nombre;
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Metodo set
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
