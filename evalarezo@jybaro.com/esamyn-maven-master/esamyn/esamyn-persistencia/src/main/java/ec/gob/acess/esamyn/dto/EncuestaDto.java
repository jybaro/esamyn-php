
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase EncuestaDto.java creada para logica del negocio
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "encuestaDto")
public class EncuestaDto implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -4397272294141523613L;

    private Long idEncuesta;

    private Long idFormulario;

    private String responsable;

    private String cargo;

    private String extra;

    private List<PreguntaDto> pregunta;

    /**
	 * Metodo get 
	 * @return the idEncuesta
	 */
	public Long getIdEncuesta() {
		return idEncuesta;
	}

	/**
	 * Metodo set
	 * @param idEncuesta the idEncuesta to set
	 */
	public void setIdEncuesta(Long idEncuesta) {
		this.idEncuesta = idEncuesta;
	}

	/**
	 * Metodo get 
	 * @return the responsable
	 */
	public String getResponsable() {
		return responsable;
	}

	/**
	 * Metodo set
	 * @param responsable the responsable to set
	 */
	public void setResponsable(String responsable) {
		this.responsable = responsable;
	}

	/**
	 * Metodo get 
	 * @return the cargo
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * Metodo set
	 * @param cargo the cargo to set
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	/**
	 * Metodo get 
	 * @return the extra
	 */
	public String getExtra() {
		return extra;
	}

	/**
	 * Metodo set
	 * @param extra the extra to set
	 */
	public void setExtra(String extra) {
		this.extra = extra;
	}

	/**
	 * Metodo get 
	 * @return the pregunta
	 */
	public List<PreguntaDto> getPregunta() {
		return pregunta;
	}

	/**
	 * Metodo set
	 * @param pregunta the pregunta to set
	 */
	public void setPregunta(List<PreguntaDto> pregunta) {
		this.pregunta = pregunta;
	}

	/**
	 * Metodo set
	 * @param idFormulario the idFormulario to set
	 */
	public void setIdFormulario(Long idFormulario) {
		this.idFormulario = idFormulario;
	}

	public Long getIdFormulario() {
	return idFormulario;
    }  

}
