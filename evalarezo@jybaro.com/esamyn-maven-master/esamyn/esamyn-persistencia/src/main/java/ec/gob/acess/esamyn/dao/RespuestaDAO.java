package ec.gob.acess.esamyn.dao;

import java.util.List;

import javax.ejb.Local;

import com.saviasoft.persistence.util.dao.GenericDao;

import ec.gob.acess.esamyn.dto.RespuestaDto;
import ec.gob.acess.esamyn.modelo.Respuesta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz RespuestaDAO.java a sido creda para metodos de Respuesta.java 
 *
 */
@Local
public interface RespuestaDAO extends GenericDao<Respuesta, Long> {
	/**
	 * Obtiene el listado de respuestas relacionadas a un establecimiento de salud y
	 * a un listado de preguntas.
	 * 
	 * @param codigoEstablecimientoSalud
	 * @param codigoPreguntaList
	 * @param anio
	 * @return
	 */
	List<Respuesta> getRespuestasParaEvaluar(Long codigoEstablecimientoSalud, List<Long> codigoPreguntaList,
			Integer anio);
	
	
	/**
	 * 
	 * @param idFormulario
	 * @param idEstableciom
	 * @return
	 */
	List<RespuestaDto> respuestasParaReporte(Long idFormulario, Long idEstablecimiento);
}
