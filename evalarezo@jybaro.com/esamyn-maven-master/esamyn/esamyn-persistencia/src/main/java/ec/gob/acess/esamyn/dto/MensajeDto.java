
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase MensajeDto.java creada para logica del negocio
 *
 */
public class MensajeDto implements Serializable {

    private static final long serialVersionUID = 6508477246386600415L;

    private boolean error;

    private String mensaje;

    private Object objeto;

    public MensajeDto() {
	super();
    }
    /**
     * 
     * Constructor clase MensajeDto.java
     * @param error
     * @param mensaje
     * @param objeto
     */
    public MensajeDto(boolean error, String mensaje, Object objeto) {
	super();
	this.error = error;
	this.mensaje = mensaje;
	this.objeto = objeto;
    }
	/**
	 * Metodo get 
	 * @return the error
	 */
	public boolean isError() {
		return error;
	}
	/**
	 * Metodo set
	 * @param error the error to set
	 */
	public void setError(boolean error) {
		this.error = error;
	}
	/**
	 * Metodo get 
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}
	/**
	 * Metodo set
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	/**
	 * Metodo get 
	 * @return the objeto
	 */
	public Object getObjeto() {
		return objeto;
	}
	/**
	 * Metodo set
	 * @param objeto the objeto to set
	 */
	public void setObjeto(Object objeto) {
		this.objeto = objeto;
	}

}
