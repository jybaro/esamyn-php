
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.CumpleCondicionNoAplicaDAO;
import ec.gob.acess.esamyn.modelo.CumpleCondicionNoAplica;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase CumpleCondicionNoAplicaDAOImpl.java es la implementación de la Interfaz CumpleCondicionNoAplica.java 
 *
 */

@Stateless
public class CumpleCondicionNoAplicaDAOImpl extends GenericEmDaoEjb<CumpleCondicionNoAplica, Long>
		implements CumpleCondicionNoAplicaDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase CumpleCondicionNoAplicaDAOImpl.java
	 */
	public CumpleCondicionNoAplicaDAOImpl() {
		super(CumpleCondicionNoAplica.class);
	}

}
