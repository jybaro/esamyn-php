
package ec.gob.acess.esamyn.dao.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;

import ec.gob.acess.esamyn.dao.UsuarioDAO;
import ec.gob.acess.esamyn.modelo.Usuario;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase UsuarioDAOImpl.java es la implementación de la Interfaz UsuarioDAO.java 
 *
 */
@Stateless
public class UsuarioDAOImpl extends GenericEmDaoEjb<Usuario, Long> implements UsuarioDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase UsuarioDAOImpl.java
	 */
	public UsuarioDAOImpl() {
		super(Usuario.class);
	}

	/**
	 * Acceso a datos e implementacion del metodo
	 * 
	 * Nombre:buscarPorNombreUsuario
	 */
	@Override
	public Usuario buscarPorNombreUsuario(String nombreUsuario) {
		StringBuffer buscaNombre = new StringBuffer(50);
		buscaNombre.append("select u from Usuario u ");
		buscaNombre.append("where u.username = :username");

		Query query = em.createQuery(buscaNombre.toString());
		query.setParameter("username", nombreUsuario);

		List<Usuario> usuarioLista = query.getResultList();

		Usuario usuario = null;

		if (usuarioLista != null && !usuarioLista.isEmpty()) {
			usuario = usuarioLista.get(0);
		}

		return usuario;
	}

}
