
package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;

import com.saviasoft.persistence.util.dao.GenericDao;

import ec.gob.acess.esamyn.modelo.Evaluacion;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz EvaluacionDAO.java a sido creda para metodos de Evaluacion.java 
 *
 */
@Local
public interface EvaluacionDAO extends GenericDao<Evaluacion, Long> {

	/**
	 * Obtiene la Evaluación de un establecimiento de un anio.
	 * 
	 * @param codigoEstablecimientoSalud
	 * @param anio
	 * @return
	 */
	Evaluacion getPorEstablecimientoAnio(Long codigoEstablecimientoSalud, Integer anio);
}
