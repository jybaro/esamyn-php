
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.EstablecimientoSaludDAO;
import ec.gob.acess.esamyn.modelo.EstablecimientoSalud;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase EstablecimientoSaludDAOImpl.java es la implementación de la Interfaz EstablecimientoSaludDAO.java
 *
 */
@Stateless
public class EstablecimientoSaludDAOImpl extends GenericEmDaoEjb<EstablecimientoSalud, Long>
		implements EstablecimientoSaludDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase EstablecimientoSaludDAOImpl.java
	 */
	public EstablecimientoSaludDAOImpl() {
		super(EstablecimientoSalud.class);
	}

}
