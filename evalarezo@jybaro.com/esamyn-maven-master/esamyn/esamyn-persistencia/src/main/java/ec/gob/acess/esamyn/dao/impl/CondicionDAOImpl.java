
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.CondicionDAO;
import ec.gob.acess.esamyn.modelo.CondicionNoAplica;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase CondicionDAOImpl.java es la implementación de la Interfaz CondicionDAO.java 
 *
 */
@Stateless
public class CondicionDAOImpl extends GenericEmDaoEjb<CondicionNoAplica, Long> implements CondicionDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase CondicionDAOImpl.java
	 */
	public CondicionDAOImpl() {
		super(CondicionNoAplica.class);
	}

}
