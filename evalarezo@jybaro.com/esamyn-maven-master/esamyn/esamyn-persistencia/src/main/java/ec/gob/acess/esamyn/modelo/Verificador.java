
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Verificador.java Entidad que refleja la estructura de tabla esa_verificador
 *
 */
@Entity
@Table(name = "esa_verificador")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "verificador")
public class Verificador implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ver_id")
	private Long codigo;
	@Basic(optional = false)
	@Column(name = "ver_cumple")
	private int cumple;
	@Basic(optional = false)
	@Column(name = "ver_no_aplica")
	private int noAplica;
	@Basic(optional = false)
	@Column(name = "ver_cantidad_medidas")
	private int cantidadMedidas;
	@JoinColumn(name = "ver_evaluacion", referencedColumnName = "eva_id")
	@ManyToOne
	private Evaluacion evaluacion;
	@JoinColumn(name = "ver_parametro", referencedColumnName = "par_id")
	@ManyToOne
	private Parametro parametro;
	@JoinColumn(name = "ver_cumple_condicion_no_aplica", referencedColumnName = "ccn_id")
	@ManyToOne
	private CumpleCondicionNoAplica cumpleCondicionNoAplica;
	/**
	 * 
	 * Constructor clase Verificador.java
	 */
	public Verificador() {
	}
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the cumple
	 */
	public int getCumple() {
		return cumple;
	}
	/**
	 * Metodo set
	 * @param cumple the cumple to set
	 */
	public void setCumple(int cumple) {
		this.cumple = cumple;
	}
	/**
	 * Metodo get 
	 * @return the noAplica
	 */
	public int getNoAplica() {
		return noAplica;
	}
	/**
	 * Metodo set
	 * @param noAplica the noAplica to set
	 */
	public void setNoAplica(int noAplica) {
		this.noAplica = noAplica;
	}
	/**
	 * Metodo get 
	 * @return the cantidadMedidas
	 */
	public int getCantidadMedidas() {
		return cantidadMedidas;
	}
	/**
	 * Metodo set
	 * @param cantidadMedidas the cantidadMedidas to set
	 */
	public void setCantidadMedidas(int cantidadMedidas) {
		this.cantidadMedidas = cantidadMedidas;
	}
	/**
	 * Metodo get 
	 * @return the evaluacion
	 */
	public Evaluacion getEvaluacion() {
		return evaluacion;
	}
	/**
	 * Metodo set
	 * @param evaluacion the evaluacion to set
	 */
	public void setEvaluacion(Evaluacion evaluacion) {
		this.evaluacion = evaluacion;
	}
	/**
	 * Metodo get 
	 * @return the parametro
	 */
	public Parametro getParametro() {
		return parametro;
	}
	/**
	 * Metodo set
	 * @param parametro the parametro to set
	 */
	public void setParametro(Parametro parametro) {
		this.parametro = parametro;
	}
	/**
	 * Metodo get 
	 * @return the cumpleCondicionNoAplica
	 */
	public CumpleCondicionNoAplica getCumpleCondicionNoAplica() {
		return cumpleCondicionNoAplica;
	}
	/**
	 * Metodo set
	 * @param cumpleCondicionNoAplica the cumpleCondicionNoAplica to set
	 */
	public void setCumpleCondicionNoAplica(CumpleCondicionNoAplica cumpleCondicionNoAplica) {
		this.cumpleCondicionNoAplica = cumpleCondicionNoAplica;
	}

}
