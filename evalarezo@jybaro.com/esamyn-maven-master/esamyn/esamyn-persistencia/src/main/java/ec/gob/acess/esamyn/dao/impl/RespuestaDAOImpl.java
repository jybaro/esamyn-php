
package ec.gob.acess.esamyn.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;

import ec.gob.acess.esamyn.dao.RespuestaDAO;
import ec.gob.acess.esamyn.dto.RespuestaDto;
import ec.gob.acess.esamyn.modelo.Respuesta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase RespuestaDAOImpl.java es la implementación de la Interfaz RespuestaDAO.java 
 *
 */
@Stateless
public class RespuestaDAOImpl extends GenericEmDaoEjb<Respuesta, Long> implements RespuestaDAO {

    @PersistenceContext(unitName = "esamyn-pu")
    private EntityManager em;
    /**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
    @Override
    protected EntityManager getEm() {
	return em;
    }
    /**
     * 
     * Constructor clase RespuestaDAOImpl.java
     */
    public RespuestaDAOImpl() {
	super(Respuesta.class);
    }

    /**
	 * Acceso a datos e implementacion del metodo
	 * 
	 * Nombre:respuestasParaEvaluar
	 */
    @Override
    public List<Respuesta> getRespuestasParaEvaluar(Long codigoEstablecimientoSalud, List<Long> codigoPreguntaList,
	    Integer anio) {
	StringBuffer respuestaEstablecimiento = new StringBuffer(200);
	respuestaEstablecimiento.append("select r from Respuesta r inner join r.pregunta p ");
	respuestaEstablecimiento.append("where r.encuesta.establecimientoSalud.codigo = :codigoEstablecimientoSalud ");
	respuestaEstablecimiento.append("and p.codigo in (:codigosPreguntas) ");
	respuestaEstablecimiento.append("and year(r.encuesta.fechaInicial) = :anio ");
	respuestaEstablecimiento.append("and r.encuesta.finalizada = 1 ");

	Query query = em.createQuery(respuestaEstablecimiento.toString());
	query.setParameter("codigoEstablecimientoSalud", codigoEstablecimientoSalud);
	query.setParameter("codigosPreguntas", codigoPreguntaList);
	query.setParameter("anio", anio);

	return query.getResultList();
    }
    /**
	 * Acceso a datos e implementacion del metodo
	 * 
	 * Nombre:respuestasParaReporte
	 */
    @SuppressWarnings("unchecked")
    @Override
    public List<RespuestaDto> respuestasParaReporte(Long idFormulario, Long idEstablecimiento) {

	StringBuffer respuestaReporte = new StringBuffer(200);
	respuestaReporte.append(" SELECT r.res_id, r.res_pregunta, r.res_valor_numero, r.res_valor_texto,");
	respuestaReporte.append(" r.res_valor_fecha, r.res_valor_booleano, e.enc_id, es.ess_unicodigo, ");
	respuestaReporte.append(" ev.eva_numero, e.enc_responsable, e.enc_cargo, u.usu_nombres||' '||u.usu_apellidos,");
	respuestaReporte.append(" ev.eva_fecha_inicio, e.enc_fecha_inicial, e.enc_finalizada");
	respuestaReporte.append(" FROM esamyn.esa_respuesta r");
	respuestaReporte.append(" INNER JOIN esamyn.esa_encuesta e ON e.enc_id = r. res_encuesta");
	respuestaReporte.append(" INNER JOIN esamyn.esa_establecimiento_salud es on es.ess_id = e.enc_establecimiento_salud");
	respuestaReporte.append(" INNER JOIN esamyn.esa_usuario u ON u.usu_username = e.enc_creado_por");
	respuestaReporte.append(" INNER JOIN esamyn.esa_evaluacion ev ON ev.eva_id = e.enc_evaluacion");
	respuestaReporte.append(" WHERE enc_formulario = :formulario");
	if (idEstablecimiento != null) {
	    respuestaReporte.append(" AND enc_establecimiento_salud = :establecimiento");
	}

	Query query = em.createNativeQuery(respuestaReporte.toString());
	query.setParameter("formulario", idFormulario);
	if (idEstablecimiento != null) {
	    query.setParameter("establecimiento", idEstablecimiento);
	}

	List<Object[]> lista = query.getResultList();

	if (lista != null && !lista.isEmpty()) {

	    List<RespuestaDto> listaRespuesta = new ArrayList<>();

	    for (Object[] objeto : lista) {

		RespuestaDto respuestaDto = new RespuestaDto();
		respuestaDto.setIdRespuesta(objeto[0] != null ? Long.parseLong(objeto[0].toString()) : null);
		respuestaDto.setIdPregunta(objeto[1] != null ? Long.parseLong(objeto[1].toString()) : null);

		if (objeto[2] != null) {
		    respuestaDto.setRespuesta(objeto[2].toString());
		} else {
		    if (objeto[3] != null) {
			respuestaDto.setRespuesta(objeto[3].toString());
		    } else {
			if (objeto[4] != null) {
			    respuestaDto.setRespuesta(objeto[4].toString());
			} else {

			    if (objeto[5] != null ? Boolean.parseBoolean(objeto[5].toString()) : false) {
				respuestaDto.setRespuesta("SI");
			    } else {
				respuestaDto.setRespuesta("NO");
			    }

			}
		    }
		}

		respuestaDto.setUnicodigo(objeto[7] != null ? objeto[7].toString() : null);

		respuestaDto.setSecuencial(objeto[8] != null ? Long.parseLong(objeto[8].toString()) : null);

		respuestaDto.setResponsable(objeto[9] != null ? objeto[9].toString() : null);

		respuestaDto.setCargo(objeto[10] != null ? objeto[10].toString() : null);

		respuestaDto.setCreadoPor(objeto[11] != null ? objeto[11].toString() : null);

		respuestaDto.setFechaEvaluacion(objeto[12] != null ? objeto[12].toString() : "2000-01-01");

		respuestaDto.setFechaEncuesta(objeto[13] != null ? objeto[13].toString() : "2000-01-01");

		if (objeto[14] != null ? Boolean.parseBoolean(objeto[14].toString()) : false) {
		    respuestaDto.setFinalizada("SI");
		} else {
		    respuestaDto.setFinalizada("NO");
		}
		
		listaRespuesta.add(respuestaDto);

	    }

	    
	    return listaRespuesta;
	}

	return null;
    }

}
