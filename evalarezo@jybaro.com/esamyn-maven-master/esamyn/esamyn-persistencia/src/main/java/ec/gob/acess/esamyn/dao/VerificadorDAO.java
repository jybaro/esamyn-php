package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;

import com.saviasoft.persistence.util.dao.GenericDao;

import ec.gob.acess.esamyn.modelo.Verificador;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz VerificadorDAO.java a sido creda para metodos de Verificador.java 
 *
 */
@Local
public interface VerificadorDAO extends GenericDao<Verificador, Long> {

	/**
	 * Elimina las verificaciones relaiconadas a un Evaluacion.
	 * 
	 * @param codigoEvaluacion
	 */
	void eliminarVerificadorPorEvaluacion(Long codigoEvaluacion);
}
