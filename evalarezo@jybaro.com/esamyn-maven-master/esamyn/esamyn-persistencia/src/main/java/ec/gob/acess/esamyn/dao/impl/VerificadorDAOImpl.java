
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;

import ec.gob.acess.esamyn.dao.VerificadorDAO;
import ec.gob.acess.esamyn.modelo.Verificador;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase VerificadorDAOImpl.java es la implementación de la Interfaz VerificadorDAO.java 
 *
 */
@Stateless
public class VerificadorDAOImpl extends GenericEmDaoEjb<Verificador, Long> implements VerificadorDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase VerificadorDAOImpl.java
	 */
	public VerificadorDAOImpl() {
		super(Verificador.class);
	}

	/**
	 * Acceso a datos e implementacion del metodo
	 * 
	 * Nombre:eliminarVerificadorPorEvaluacion
	 */
	@Override
	public void eliminarVerificadorPorEvaluacion(Long codigoEvaluacion) {
		StringBuffer evaluacionVerificada = new StringBuffer(40);
		evaluacionVerificada.append("delete Verificador v where v.evaluacion.codigo = :codigoEvaluacion");

		Query delete = em.createQuery(evaluacionVerificada.toString());
		delete.setParameter("codigoEvaluacion", codigoEvaluacion);

		delete.executeUpdate();
	}

}
