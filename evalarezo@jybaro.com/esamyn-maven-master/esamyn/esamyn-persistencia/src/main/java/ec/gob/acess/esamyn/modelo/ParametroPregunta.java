
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 * 
 *ParametroPregunta.java Entidad que refleja la estructura de tabla esa_parametro_pregunta
 *          
 *
 */
@Entity
@Table(name = "esa_parametro_pregunta")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "parametro pregunta")
public class ParametroPregunta implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ppr_id")
	private Long codigo;

	@JoinColumn(name = "ppr_parametro", referencedColumnName = "par_id")
	@ManyToOne(optional = false)
	@XmlTransient
	private Parametro parametro;
	@JoinColumn(name = "ppr_pregunta", referencedColumnName = "prg_id")
	@ManyToOne(optional = false)
	private Pregunta pregunta;

	/**
	 * Metodo get
	 * 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}

	/**
	 * Metodo set
	 * 
	 * @param codigo
	 *            the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	/**
	 * Metodo get
	 * 
	 * @return the parametro
	 */
	public Parametro getParametro() {
		return parametro;
	}

	/**
	 * Metodo set
	 * 
	 * @param parametro
	 *            the parametro to set
	 */
	public void setParametro(Parametro parametro) {
		this.parametro = parametro;
	}

	/**
	 * Metodo get
	 * 
	 * @return the pregunta
	 */
	public Pregunta getPregunta() {
		return pregunta;
	}

	/**
	 * Metodo set
	 * 
	 * @param pregunta
	 *            the pregunta to set
	 */
	public void setPregunta(Pregunta pregunta) {
		this.pregunta = pregunta;
	}

}
