package ec.gob.acess.esamyn.dao;

import java.util.List;

import javax.ejb.Local;

import com.saviasoft.persistence.util.dao.GenericDao;

import ec.gob.acess.esamyn.modelo.Parametro;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz ParametroDAO.java a sido creda para metodos de Parametro.java
 *
 */
@Local
public interface ParametroDAO extends GenericDao<Parametro, Long> {

	/**
	 * Obtiene todos los parametros involucrados en una evaluacion.
	 * 
	 * @return
	 */
	List<Parametro> getParametrosParaEvaluacion();
}
