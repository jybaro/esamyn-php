
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.ProvinciaDAO;
import ec.gob.acess.esamyn.modelo.Provincia;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase ProvinciaDAOImpl.java es la implementación de la Interfaz ProvinciaDAO.java 
 *
 */
@Stateless
public class ProvinciaDAOImpl extends GenericEmDaoEjb<Provincia, Long> implements ProvinciaDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase ProvinciaDAOImpl.java
	 */
	public ProvinciaDAOImpl() {
		super(Provincia.class);
	}

}
