
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.TipoGrupoParametroDAO;
import ec.gob.acess.esamyn.modelo.TipoGrupoParametro;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase TipoGrupoParametroDAOImpl.java es la implementación de la Interfaz TipoGrupoParametroDAO.java 
 *
 */
@Stateless
public class TipoGrupoParametroDAOImpl extends GenericEmDaoEjb<TipoGrupoParametro, Long>
		implements TipoGrupoParametroDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase TipoGrupoParametroDAOImpl.java
	 */
	public TipoGrupoParametroDAOImpl() {
		super(TipoGrupoParametro.class);
	}

}
