
package ec.gob.acess.esamyn.dao;

import com.saviasoft.persistence.util.dao.GenericDao;
import ec.gob.acess.esamyn.modelo.CumpleCondicionNoAplica;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz CumpleCondicionNoAplicaDAO.java a sido creda para metodos de CumpleCondicionNoAplica.java 
 *
 */
public interface CumpleCondicionNoAplicaDAO extends GenericDao<CumpleCondicionNoAplica, Long> {

}
