
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.RolDAO;
import ec.gob.acess.esamyn.modelo.Rol;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase RolDAOImpl.java es la implementación de la Interfaz RolDAO.java 
 *
 */
@Stateless
public class RolDAOImpl extends GenericEmDaoEjb<Rol, Long> implements RolDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase RolDAOImpl.java
	 */
	public RolDAOImpl() {
		super(Rol.class);
	}

}
