
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * GrupoParametro.java Entidad que refleja la estructura de tabla esa_grupo_parametro
 *
 */
@Entity
@Table(name = "esa_grupo_parametro")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "grupoParametro")
public class GrupoParametro implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "gpa_id")
	private Long codigo;
	@Column(name = "gpa_texto")
	private String texto;
	@Column(name = "gpa_clave")
	private String clave;
	@XmlTransient
	@Transient
	private List<Parametro> parametroList;
	
	@XmlTransient
	@Transient
	private List<GrupoParametro> grupoParametroLista;
	@JoinColumn(name = "gpa_padre", referencedColumnName = "gpa_id")
	@ManyToOne
	private GrupoParametro padre;
	@JoinColumn(name = "gpa_tipo_grupo_parametro", referencedColumnName = "tgp_id")
	@ManyToOne
	private TipoGrupoParametro tipoGrupoParametro;
	/**
	 * 
	 * Constructor clase GrupoParametro.java
	 */
	public GrupoParametro() {
	}
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the texto
	 */
	public String getTexto() {
		return texto;
	}
	/**
	 * Metodo set
	 * @param texto the texto to set
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}
	/**
	 * Metodo get 
	 * @return the clave
	 */
	public String getClave() {
		return clave;
	}
	/**
	 * Metodo set
	 * @param clave the clave to set
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}
	/**
	 * Metodo get 
	 * @return the parametroList
	 */
	public List<Parametro> getParametroList() {
		return parametroList;
	}
	/**
	 * Metodo set
	 * @param parametroList the parametroList to set
	 */
	public void setParametroList(List<Parametro> parametroList) {
		this.parametroList = parametroList;
	}
	/**
	 * Metodo get 
	 * @return the grupoParametroLista
	 */
	public List<GrupoParametro> getGrupoParametroLista() {
		return grupoParametroLista;
	}
	/**
	 * Metodo set
	 * @param grupoParametroLista the grupoParametroLista to set
	 */
	public void setGrupoParametroLista(List<GrupoParametro> grupoParametroLista) {
		this.grupoParametroLista = grupoParametroLista;
	}
	/**
	 * Metodo get 
	 * @return the padre
	 */
	public GrupoParametro getPadre() {
		return padre;
	}
	/**
	 * Metodo set
	 * @param padre the padre to set
	 */
	public void setPadre(GrupoParametro padre) {
		this.padre = padre;
	}
	/**
	 * Metodo get 
	 * @return the tipoGrupoParametro
	 */
	public TipoGrupoParametro getTipoGrupoParametro() {
		return tipoGrupoParametro;
	}
	/**
	 * Metodo set
	 * @param tipoGrupoParametro the tipoGrupoParametro to set
	 */
	public void setTipoGrupoParametro(TipoGrupoParametro tipoGrupoParametro) {
		this.tipoGrupoParametro = tipoGrupoParametro;
	}

}
