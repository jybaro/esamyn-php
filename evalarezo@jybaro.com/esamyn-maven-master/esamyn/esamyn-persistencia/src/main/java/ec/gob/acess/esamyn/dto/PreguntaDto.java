
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase PreguntaDto.java creada para logica del negocio
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "preguntaDto")
public class PreguntaDto implements Serializable {

    private static final long serialVersionUID = 2677317877352056089L;

    private Long codigo;

    private String texto;

    private String ayuda;

    private String prefijo;

    private String subfijo;

    private String validacion;

    private Integer orden;

    private Long codigoTipoPregunta;

    private String etiquetaTipoPregunta;

    private Long codigoRespuesta;

    private Long codigoEncuesta;

    private BigInteger valorNumero;

    private String valorTexto;

    private Date valorFecha;

    private Boolean valorBooleano;

    private List<PreguntaDto> preguntaLista;
    
    @XmlTransient
    private PreguntaDto padre;

	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}

	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	/**
	 * Metodo get 
	 * @return the texto
	 */
	public String getTexto() {
		return texto;
	}

	/**
	 * Metodo set
	 * @param texto the texto to set
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}

	/**
	 * Metodo get 
	 * @return the ayuda
	 */
	public String getAyuda() {
		return ayuda;
	}

	/**
	 * Metodo set
	 * @param ayuda the ayuda to set
	 */
	public void setAyuda(String ayuda) {
		this.ayuda = ayuda;
	}

	/**
	 * Metodo get 
	 * @return the prefijo
	 */
	public String getPrefijo() {
		return prefijo;
	}

	/**
	 * Metodo set
	 * @param prefijo the prefijo to set
	 */
	public void setPrefijo(String prefijo) {
		this.prefijo = prefijo;
	}

	/**
	 * Metodo get 
	 * @return the subfijo
	 */
	public String getSubfijo() {
		return subfijo;
	}

	/**
	 * Metodo set
	 * @param subfijo the subfijo to set
	 */
	public void setSubfijo(String subfijo) {
		this.subfijo = subfijo;
	}

	/**
	 * Metodo get 
	 * @return the validacion
	 */
	public String getValidacion() {
		return validacion;
	}

	/**
	 * Metodo set
	 * @param validacion the validacion to set
	 */
	public void setValidacion(String validacion) {
		this.validacion = validacion;
	}

	/**
	 * Metodo get 
	 * @return the orden
	 */
	public Integer getOrden() {
		return orden;
	}

	/**
	 * Metodo set
	 * @param orden the orden to set
	 */
	public void setOrden(Integer orden) {
		this.orden = orden;
	}

	/**
	 * Metodo get 
	 * @return the codigoTipoPregunta
	 */
	public Long getCodigoTipoPregunta() {
		return codigoTipoPregunta;
	}

	/**
	 * Metodo set
	 * @param codigoTipoPregunta the codigoTipoPregunta to set
	 */
	public void setCodigoTipoPregunta(Long codigoTipoPregunta) {
		this.codigoTipoPregunta = codigoTipoPregunta;
	}

	/**
	 * Metodo get 
	 * @return the etiquetaTipoPregunta
	 */
	public String getEtiquetaTipoPregunta() {
		return etiquetaTipoPregunta;
	}

	/**
	 * Metodo set
	 * @param etiquetaTipoPregunta the etiquetaTipoPregunta to set
	 */
	public void setEtiquetaTipoPregunta(String etiquetaTipoPregunta) {
		this.etiquetaTipoPregunta = etiquetaTipoPregunta;
	}

	/**
	 * Metodo get 
	 * @return the codigoRespuesta
	 */
	public Long getCodigoRespuesta() {
		return codigoRespuesta;
	}

	/**
	 * Metodo set
	 * @param codigoRespuesta the codigoRespuesta to set
	 */
	public void setCodigoRespuesta(Long codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	/**
	 * Metodo get 
	 * @return the codigoEncuesta
	 */
	public Long getCodigoEncuesta() {
		return codigoEncuesta;
	}

	/**
	 * Metodo set
	 * @param codigoEncuesta the codigoEncuesta to set
	 */
	public void setCodigoEncuesta(Long codigoEncuesta) {
		this.codigoEncuesta = codigoEncuesta;
	}

	/**
	 * Metodo get 
	 * @return the valorNumero
	 */
	public BigInteger getValorNumero() {
		return valorNumero;
	}

	/**
	 * Metodo set
	 * @param valorNumero the valorNumero to set
	 */
	public void setValorNumero(BigInteger valorNumero) {
		this.valorNumero = valorNumero;
	}

	/**
	 * Metodo get 
	 * @return the valorTexto
	 */
	public String getValorTexto() {
		return valorTexto;
	}

	/**
	 * Metodo set
	 * @param valorTexto the valorTexto to set
	 */
	public void setValorTexto(String valorTexto) {
		this.valorTexto = valorTexto;
	}

	/**
	 * Metodo get 
	 * @return the valorFecha
	 */
	public Date getValorFecha() {
		return valorFecha;
	}

	/**
	 * Metodo set
	 * @param valorFecha the valorFecha to set
	 */
	public void setValorFecha(Date valorFecha) {
		this.valorFecha = valorFecha;
	}

	/**
	 * Metodo get 
	 * @return the valorBooleano
	 */
	public Boolean getValorBooleano() {
		return valorBooleano;
	}

	/**
	 * Metodo set
	 * @param valorBooleano the valorBooleano to set
	 */
	public void setValorBooleano(Boolean valorBooleano) {
		this.valorBooleano = valorBooleano;
	}

	/**
	 * Metodo get 
	 * @return the preguntaLista
	 */
	public List<PreguntaDto> getPreguntaLista() {
		return preguntaLista;
	}

	/**
	 * Metodo set
	 * @param preguntaLista the preguntaLista to set
	 */
	public void setPreguntaLista(List<PreguntaDto> preguntaLista) {
		this.preguntaLista = preguntaLista;
	}

	/**
	 * Metodo get 
	 * @return the padre
	 */
	public PreguntaDto getPadre() {
		return padre;
	}

	/**
	 * Metodo set
	 * @param padre the padre to set
	 */
	public void setPadre(PreguntaDto padre) {
		this.padre = padre;
	}

}
