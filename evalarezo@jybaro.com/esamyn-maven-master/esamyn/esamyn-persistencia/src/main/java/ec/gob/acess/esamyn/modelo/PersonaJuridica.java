
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * PersonaJuridica.java Entidad que refleja la estructura de tabla esa_persona_juridica
 *
 */
@Entity
@Table(name = "esa_persona_juridica")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "persona jurdidica")
public class PersonaJuridica implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "pju_id")
    private Long codigo;
    @Column(name = "pju_razon_social")
    private String razonSocial;
    @Column(name = "pju_ruc")
    private String ruc;
    @Transient
    @XmlTransient
    private List<EstablecimientoSalud> establecimientoSaludLista;
    /**
     * 
     * Constructor clase PersonaJuridica.java
     */
    public PersonaJuridica() {
    }
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the razonSocial
	 */
	public String getRazonSocial() {
		return razonSocial;
	}
	/**
	 * Metodo set
	 * @param razonSocial the razonSocial to set
	 */
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	/**
	 * Metodo get 
	 * @return the ruc
	 */
	public String getRuc() {
		return ruc;
	}
	/**
	 * Metodo set
	 * @param ruc the ruc to set
	 */
	public void setRuc(String ruc) {
		this.ruc = ruc;
	}
	/**
	 * Metodo get 
	 * @return the establecimientoSaludLista
	 */
	public List<EstablecimientoSalud> getEstablecimientoSaludLista() {
		return establecimientoSaludLista;
	}
	/**
	 * Metodo set
	 * @param establecimientoSaludLista the establecimientoSaludLista to set
	 */
	public void setEstablecimientoSaludLista(List<EstablecimientoSalud> establecimientoSaludLista) {
		this.establecimientoSaludLista = establecimientoSaludLista;
	}
    
}
