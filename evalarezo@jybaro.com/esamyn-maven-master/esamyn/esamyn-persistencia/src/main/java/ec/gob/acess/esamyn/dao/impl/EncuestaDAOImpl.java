
package ec.gob.acess.esamyn.dao.impl;

import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;

import ec.gob.acess.esamyn.dao.EncuestaDAO;
import ec.gob.acess.esamyn.modelo.Encuesta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase EncuestaDAOImpl.java es la implementación de la Interfaz EncuestaDAO.java
 *
 */
@Stateless
public class EncuestaDAOImpl extends GenericEmDaoEjb<Encuesta, Long> implements EncuestaDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase EncuestaDAOImpl.java
	 */
	public EncuestaDAOImpl() {
		super(Encuesta.class);
	}

	/**
	 * Acceso a datos e implementacion del metodo
	 * 
	 * Nombre:actualizarEncuestaEvaluacion
	 */
	@Override
	public void actualizarEncuestaEvaluacion(Set<Long> encuestaCodigoSet, Long codigoEvaluacion) {
		StringBuffer encuesta = new StringBuffer(50);
		encuesta.append("update esamyn.esa_encuesta set enc_evaluacion = :codigoEvaluacion where enc_id in (:encuestaCodigos)");

		Query update = em.createNativeQuery(encuesta.toString());
		update.setParameter("codigoEvaluacion", codigoEvaluacion);
		update.setParameter("encuestaCodigos", encuestaCodigoSet);

		update.executeUpdate();
	}

}
