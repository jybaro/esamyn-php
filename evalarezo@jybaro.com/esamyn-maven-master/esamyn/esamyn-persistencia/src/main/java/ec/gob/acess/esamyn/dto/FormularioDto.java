
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase FormularioDto.java creada para logica del negocio
 *
 */
public class FormularioDto implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 8772552351227252696L;
    private Date fecha;
    private String estado;
    private String contestados;
	/**
	 * Metodo get 
	 * @return the fecha
	 */
	public Date getFecha() {
		return fecha;
	}
	/**
	 * Metodo set
	 * @param fecha the fecha to set
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
	 * Metodo get 
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}
	/**
	 * Metodo set
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}
	/**
	 * Metodo get 
	 * @return the contestados
	 */
	public String getContestados() {
		return contestados;
	}
	/**
	 * Metodo set
	 * @param contestados the contestados to set
	 */
	public void setContestados(String contestados) {
		this.contestados = contestados;
	}

}
