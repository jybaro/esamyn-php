
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.TipoPreguntaDAO;
import ec.gob.acess.esamyn.modelo.TipoPregunta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase TipoPreguntaDAOImpl.java es la implementación de la Interfaz TipoPreguntaDAO.java 
 *
 */
@Stateless
public class TipoPreguntaDAOImpl extends GenericEmDaoEjb<TipoPregunta, Long> implements TipoPreguntaDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase TipoPreguntaDAOImpl.java
	 */
	public TipoPreguntaDAOImpl() {
		super(TipoPregunta.class);
	}

}
