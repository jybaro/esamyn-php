package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;

import com.saviasoft.persistence.util.dao.GenericDao;

import ec.gob.acess.esamyn.modelo.Usuario;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz UsuarioDAO.java a sido creda para metodos de Usuario.java 
 *
 */
@Local
public interface UsuarioDAO extends GenericDao<Usuario, Long> {

	/**
	 * Obtiene usuario por el nombreUsuario.
	 * 
	 * @param nombreUsuario
	 * @return
	 */
	Usuario buscarPorNombreUsuario(String nombreUsuario);
}
