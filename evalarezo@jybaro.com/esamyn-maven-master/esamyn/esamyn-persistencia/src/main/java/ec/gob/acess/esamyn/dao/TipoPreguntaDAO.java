package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;
import com.saviasoft.persistence.util.dao.GenericDao;
import ec.gob.acess.esamyn.modelo.TipoPregunta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz TipoPreguntaDAO.java a sido creda para metodos de TipoPregunta.java 
 *
 */
@Local
public interface TipoPreguntaDAO extends GenericDao<TipoPregunta, Long> {

}
