
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Canton.java Entidad que refleja la estructura de tabla esa_canton
 *
 */
@Entity
@Table(name = "esa_canton")
public class Canton implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "can_id")
    private Long codigo;
    @Column(name = "can_nombre")
    private String nombre;
    @Column(name = "can_codigo")
    private String codigoINEN;
 
    @JoinColumn(name = "can_provincia", referencedColumnName = "pro_id")
    @ManyToOne
    private Provincia provincia;
    /**
     * 
     * Constructor clase Canton.java
     */
    public Canton() {
    }
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Metodo set
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Metodo get 
	 * @return the codigoINEN
	 */
	public String getCodigoINEN() {
		return codigoINEN;
	}
	/**
	 * Metodo set
	 * @param codigoINEN the codigoINEN to set
	 */
	public void setCodigoINEN(String codigoINEN) {
		this.codigoINEN = codigoINEN;
	}
	/**
	 * Metodo get 
	 * @return the provincia
	 */
	public Provincia getProvincia() {
		return provincia;
	}
	/**
	 * Metodo set
	 * @param provincia the provincia to set
	 */
	public void setProvincia(Provincia provincia) {
		this.provincia = provincia;
	}


}
