
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Encuesta.java Entidad que refleja la estructura de tabla esa_encuesta
 *
 */
@Entity
@Table(name = "esa_encuesta")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "encuesta")
public class Encuesta implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "enc_id")
    private Long codigo;

    @Column(name = "enc_creado_por")
    @XmlTransient
    private String creadoPor;
    @Column(name = "enc_modificado_por")
    @XmlTransient
    private String modificadoPor;
    @Basic(optional = false)
    @Column(name = "enc_finalizada")
    @XmlTransient
    private int finalizada;
    @Basic(optional = false)
    @Column(name = "enc_fecha_inicial")
    @Temporal(TemporalType.TIMESTAMP)
    @XmlTransient
    private Date fechaInicial;
    @Column(name = "enc_fecha_final")
    @Temporal(TemporalType.TIMESTAMP)
    @XmlTransient
    private Date fechaFinal;
    @Column(name = "enc_responsable")
    private String responsable;
    @Column(name = "enc_cargo")
    private String cargo;
    @Column(name = "enc_extra")
    private String extra;
    @Transient
    @XmlTransient
    private List<Respuesta> respuestaLista;
    @JoinColumn(name = "enc_establecimiento_salud", referencedColumnName = "ess_id")
    @ManyToOne
    private EstablecimientoSalud establecimientoSalud;
    @JoinColumn(name = "enc_evaluacion", referencedColumnName = "eva_id")
    @ManyToOne
    @XmlTransient
    private Evaluacion evaluacion;
    @JoinColumn(name = "enc_formulario", referencedColumnName = "frm_id")
    @ManyToOne
    private Formulario formulario;
    @JoinColumn(name = "enc_usuario", referencedColumnName = "usu_id")
    @ManyToOne
    @XmlTransient
    private Usuario usuario;
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the creadoPor
	 */
	public String getCreadoPor() {
		return creadoPor;
	}
	/**
	 * Metodo set
	 * @param creadoPor the creadoPor to set
	 */
	public void setCreadoPor(String creadoPor) {
		this.creadoPor = creadoPor;
	}
	/**
	 * Metodo get 
	 * @return the modificadoPor
	 */
	public String getModificadoPor() {
		return modificadoPor;
	}
	/**
	 * Metodo set
	 * @param modificadoPor the modificadoPor to set
	 */
	public void setModificadoPor(String modificadoPor) {
		this.modificadoPor = modificadoPor;
	}
	/**
	 * Metodo get 
	 * @return the finalizada
	 */
	public int getFinalizada() {
		return finalizada;
	}
	/**
	 * Metodo set
	 * @param finalizada the finalizada to set
	 */
	public void setFinalizada(int finalizada) {
		this.finalizada = finalizada;
	}
	/**
	 * Metodo get 
	 * @return the fechaInicial
	 */
	public Date getFechaInicial() {
		return fechaInicial;
	}
	/**
	 * Metodo set
	 * @param fechaInicial the fechaInicial to set
	 */
	public void setFechaInicial(Date fechaInicial) {
		this.fechaInicial = fechaInicial;
	}
	/**
	 * Metodo get 
	 * @return the fechaFinal
	 */
	public Date getFechaFinal() {
		return fechaFinal;
	}
	/**
	 * Metodo set
	 * @param fechaFinal the fechaFinal to set
	 */
	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	/**
	 * Metodo get 
	 * @return the responsable
	 */
	public String getResponsable() {
		return responsable;
	}
	/**
	 * Metodo set
	 * @param responsable the responsable to set
	 */
	public void setResponsable(String responsable) {
		this.responsable = responsable;
	}
	/**
	 * Metodo get 
	 * @return the cargo
	 */
	public String getCargo() {
		return cargo;
	}
	/**
	 * Metodo set
	 * @param cargo the cargo to set
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	/**
	 * Metodo get 
	 * @return the extra
	 */
	public String getExtra() {
		return extra;
	}
	/**
	 * Metodo set
	 * @param extra the extra to set
	 */
	public void setExtra(String extra) {
		this.extra = extra;
	}
	/**
	 * Metodo get 
	 * @return the respuestaLista
	 */
	public List<Respuesta> getRespuestaLista() {
		return respuestaLista;
	}
	/**
	 * Metodo set
	 * @param respuestaLista the respuestaLista to set
	 */
	public void setRespuestaLista(List<Respuesta> respuestaLista) {
		this.respuestaLista = respuestaLista;
	}
	/**
	 * Metodo get 
	 * @return the establecimientoSalud
	 */
	public EstablecimientoSalud getEstablecimientoSalud() {
		return establecimientoSalud;
	}
	/**
	 * Metodo set
	 * @param establecimientoSalud the establecimientoSalud to set
	 */
	public void setEstablecimientoSalud(EstablecimientoSalud establecimientoSalud) {
		this.establecimientoSalud = establecimientoSalud;
	}
	/**
	 * Metodo get 
	 * @return the evaluacion
	 */
	public Evaluacion getEvaluacion() {
		return evaluacion;
	}
	/**
	 * Metodo set
	 * @param evaluacion the evaluacion to set
	 */
	public void setEvaluacion(Evaluacion evaluacion) {
		this.evaluacion = evaluacion;
	}
	/**
	 * Metodo get 
	 * @return the formulario
	 */
	public Formulario getFormulario() {
		return formulario;
	}
	/**
	 * Metodo set
	 * @param formulario the formulario to set
	 */
	public void setFormulario(Formulario formulario) {
		this.formulario = formulario;
	}
	/**
	 * Metodo get 
	 * @return the usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}
	/**
	 * Metodo set
	 * @param usuario the usuario to set
	 */
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}


}
