package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Provincia.java Entidad que refleja la estructura de tabla esa_provincia
 *
 */
@Entity
@Table(name = "esa_provincia")
public class Provincia implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "pro_id")
	private Long codigo;
	@Column(name = "pro_nombre")
	private String nombre;
	@Column(name = "pro_codigo")
	private String codigoInen;
	/**
	 * 
	 * Constructor clase Provincia.java
	 */
	public Provincia() {
	}
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Metodo set
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Metodo get 
	 * @return the codigoInen
	 */
	public String getCodigoInen() {
		return codigoInen;
	}
	/**
	 * Metodo set
	 * @param codigoInen the codigoInen to set
	 */
	public void setCodigoInen(String codigoInen) {
		this.codigoInen = codigoInen;
	}

}
