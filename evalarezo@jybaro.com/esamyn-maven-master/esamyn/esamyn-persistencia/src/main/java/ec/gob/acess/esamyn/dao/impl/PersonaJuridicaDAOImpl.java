
package ec.gob.acess.esamyn.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.saviasoft.persistence.util.dao.ejb.GenericEmDaoEjb;
import ec.gob.acess.esamyn.dao.PersonaJuridicaDAO;
import ec.gob.acess.esamyn.modelo.PersonaJuridica;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * La clase PersonaJuridicaDAOImpl.java es la implementación de la Interfaz PersonaJuridicaDAO.java
 *
 */
@Stateless
public class PersonaJuridicaDAOImpl extends GenericEmDaoEjb<PersonaJuridica, Long> implements PersonaJuridicaDAO {

	@PersistenceContext(unitName = "esamyn-pu")
	private EntityManager em;
	/**
	 * Metodo que Sobrescribe EntityManager
	 * 
	 * @return em
	 */
	@Override
	protected EntityManager getEm() {
		return em;
	}
	/**
	 * 
	 * Constructor clase PersonaJuridicaDAOImpl.java
	 */
	public PersonaJuridicaDAOImpl() {
		super(PersonaJuridica.class);
	}

}
