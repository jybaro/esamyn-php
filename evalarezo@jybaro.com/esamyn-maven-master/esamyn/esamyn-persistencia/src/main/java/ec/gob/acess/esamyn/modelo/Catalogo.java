
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Catalogo.java Entidad que refleja la estructura de tabla esa_catalogo
 *
 */
@Entity
@Table(name = "esa_catalogo")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "catalogo")
public class Catalogo implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "cat_id")
	private Long codigo;

	@Column(name = "cat_codigo")
	private String identificador;
	@Basic(optional = false)
	@Column(name = "cat_valor")
	private String valor;
	/**
	 * 
	 * Constructor clase Catalogo.java
	 */
	public Catalogo() {
	}
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the identificador
	 */
	public String getIdentificador() {
		return identificador;
	}
	/**
	 * Metodo set
	 * @param identificador the identificador to set
	 */
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	/**
	 * Metodo get 
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}
	/**
	 * Metodo set
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

}
