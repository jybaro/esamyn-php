
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Usuario.java Entidad que refleja la estructura de tabla esa_usuario
 *
 */
@Entity
@Table(name = "esa_usuario")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "usuario")
public class Usuario implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "usu_id")
	private Long codigo;
	@Column(name = "usu_nombres")
	private String nombres;
	@Column(name = "usu_apellidos")
	private String apellidos;
	@Column(name = "usu_username")
	private String username;
	@Column(name = "usu_password")
	private String password;
	@Basic(optional = false)
	@Column(name = "usu_bloqueado")
	private int bloqueado;
	@Column(name = "usu_cedula")
	private String cedula;
	@Column(name = "usu_telefono")
	private String telefono;
	@Column(name = "usu_correo_eletronico")
	private String correoEletronico;
	@Column(name = "usu_sesion")
	private String token;
	@JoinColumn(name = "usu_rol", referencedColumnName = "rol_id")
	@ManyToOne
	private Rol rol;
	/**
	 * 
	 * Constructor clase Usuario.java
	 */
	public Usuario() {
	}

	public Long getCodigo() {
		return codigo;
	}

	/**
	 * Metodo get 
	 * @return the nombres
	 */
	public String getNombres() {
		return nombres;
	}

	/**
	 * Metodo set
	 * @param nombres the nombres to set
	 */
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	/**
	 * Metodo get 
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * Metodo set
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * Metodo get 
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Metodo set
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Metodo get 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Metodo set
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Metodo get 
	 * @return the bloqueado
	 */
	public int getBloqueado() {
		return bloqueado;
	}

	/**
	 * Metodo set
	 * @param bloqueado the bloqueado to set
	 */
	public void setBloqueado(int bloqueado) {
		this.bloqueado = bloqueado;
	}

	/**
	 * Metodo get 
	 * @return the cedula
	 */
	public String getCedula() {
		return cedula;
	}

	/**
	 * Metodo set
	 * @param cedula the cedula to set
	 */
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	/**
	 * Metodo get 
	 * @return the telefono
	 */
	public String getTelefono() {
		return telefono;
	}

	/**
	 * Metodo set
	 * @param telefono the telefono to set
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	/**
	 * Metodo get 
	 * @return the correoEletronico
	 */
	public String getCorreoEletronico() {
		return correoEletronico;
	}

	/**
	 * Metodo set
	 * @param correoEletronico the correoEletronico to set
	 */
	public void setCorreoEletronico(String correoEletronico) {
		this.correoEletronico = correoEletronico;
	}

	/**
	 * Metodo get 
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Metodo set
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Metodo get 
	 * @return the rol
	 */
	public Rol getRol() {
		return rol;
	}

	/**
	 * Metodo set
	 * @param rol the rol to set
	 */
	public void setRol(Rol rol) {
		this.rol = rol;
	}

	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}


}
