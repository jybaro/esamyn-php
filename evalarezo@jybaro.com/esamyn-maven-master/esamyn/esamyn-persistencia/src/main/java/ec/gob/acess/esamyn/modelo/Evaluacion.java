
package ec.gob.acess.esamyn.modelo;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * Evaluacion.java Entidad que refleja la estructura de tabla esa_evaluacion
 *
 */
@Entity
@Table(name = "esa_evaluacion")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "evaluacion")
public class Evaluacion implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "eva_id")
	private Long codigo;
	@Column(name = "eva_numero")
	@XmlTransient
	private Integer numero;
	@Column(name = "eva_calificacion")
	private BigInteger calificacion;
	@Basic(optional = false)
	@Column(name = "eva_fecha_inicio")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaInicio;
	@Column(name = "eva_fecha_calificacion")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaCalificacion;
	@Basic(optional = false)
	@Column(name = "eva_cantidad_encuestas")
	private int cantidadEncuestas;

	@JoinColumn(name = "eva_establecimiento_salud", referencedColumnName = "ess_id")
	@ManyToOne
	private EstablecimientoSalud establecimientoSalud;
	@JoinColumn(name = "eva_usuario", referencedColumnName = "usu_id")
	@ManyToOne
	private Usuario usuario;
	/**
	 * 
	 * Constructor clase Evaluacion.java
	 */
	public Evaluacion() {
	}
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	/**
	 * Metodo get 
	 * @return the numero
	 */
	public Integer getNumero() {
		return numero;
	}
	/**
	 * Metodo set
	 * @param numero the numero to set
	 */
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	/**
	 * Metodo get 
	 * @return the calificacion
	 */
	public BigInteger getCalificacion() {
		return calificacion;
	}
	/**
	 * Metodo set
	 * @param calificacion the calificacion to set
	 */
	public void setCalificacion(BigInteger calificacion) {
		this.calificacion = calificacion;
	}
	/**
	 * Metodo get 
	 * @return the fechaInicio
	 */
	public Date getFechaInicio() {
		return fechaInicio;
	}
	/**
	 * Metodo set
	 * @param fechaInicio the fechaInicio to set
	 */
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	/**
	 * Metodo get 
	 * @return the fechaCalificacion
	 */
	public Date getFechaCalificacion() {
		return fechaCalificacion;
	}
	/**
	 * Metodo set
	 * @param fechaCalificacion the fechaCalificacion to set
	 */
	public void setFechaCalificacion(Date fechaCalificacion) {
		this.fechaCalificacion = fechaCalificacion;
	}
	/**
	 * Metodo get 
	 * @return the cantidadEncuestas
	 */
	public int getCantidadEncuestas() {
		return cantidadEncuestas;
	}
	/**
	 * Metodo set
	 * @param cantidadEncuestas the cantidadEncuestas to set
	 */
	public void setCantidadEncuestas(int cantidadEncuestas) {
		this.cantidadEncuestas = cantidadEncuestas;
	}
	/**
	 * Metodo get 
	 * @return the establecimientoSalud
	 */
	public EstablecimientoSalud getEstablecimientoSalud() {
		return establecimientoSalud;
	}
	/**
	 * Metodo set
	 * @param establecimientoSalud the establecimientoSalud to set
	 */
	public void setEstablecimientoSalud(EstablecimientoSalud establecimientoSalud) {
		this.establecimientoSalud = establecimientoSalud;
	}
	/**
	 * Metodo get 
	 * @return the usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}
	/**
	 * Metodo set
	 * @param usuario the usuario to set
	 */
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

}
