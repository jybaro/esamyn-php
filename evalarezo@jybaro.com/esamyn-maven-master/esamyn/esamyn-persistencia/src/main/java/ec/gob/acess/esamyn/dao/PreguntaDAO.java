package ec.gob.acess.esamyn.dao;

import javax.ejb.Local;
import com.saviasoft.persistence.util.dao.GenericDao;
import ec.gob.acess.esamyn.modelo.Pregunta;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *
 * Interfaz PreguntaDAO.java a sido creda para metodos de Pregunta.java
 *
 */
@Local
public interface PreguntaDAO extends GenericDao<Pregunta, Long> {

}
