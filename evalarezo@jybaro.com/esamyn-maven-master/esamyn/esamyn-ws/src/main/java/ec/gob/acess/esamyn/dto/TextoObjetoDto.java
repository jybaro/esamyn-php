
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;
/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * TextoObjetoDto.java Maneja la logica de Web services
 *
 */
public class TextoObjetoDto implements Serializable {

    private static final long serialVersionUID = 3524289730494969860L;

    private Long codigo;

    private String texto;

	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}

	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	/**
	 * Metodo get 
	 * @return the texto
	 */
	public String getTexto() {
		return texto;
	}

	/**
	 * Metodo set
	 * @param texto the texto to set
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}

}
