
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * PreguntaWsDto.java Maneja la logica de Web services
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pregunta")
public class PreguntaWsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9014875630963612166L;

	private Long idFormulario;

	private Long idEncuesta;
	
	private Long idPregunta;

	public Long getIdFormulario() {
		return idFormulario;
	}

	/**
	 * Metodo get 
	 * @return the idEncuesta
	 */
	public Long getIdEncuesta() {
		return idEncuesta;
	}

	/**
	 * Metodo set
	 * @param idEncuesta the idEncuesta to set
	 */
	public void setIdEncuesta(Long idEncuesta) {
		this.idEncuesta = idEncuesta;
	}

	/**
	 * Metodo get 
	 * @return the idPregunta
	 */
	public Long getIdPregunta() {
		return idPregunta;
	}

	/**
	 * Metodo set
	 * @param idPregunta the idPregunta to set
	 */
	public void setIdPregunta(Long idPregunta) {
		this.idPregunta = idPregunta;
	}

	/**
	 * Metodo set
	 * @param idFormulario the idFormulario to set
	 */
	public void setIdFormulario(Long idFormulario) {
		this.idFormulario = idFormulario;
	}

}
