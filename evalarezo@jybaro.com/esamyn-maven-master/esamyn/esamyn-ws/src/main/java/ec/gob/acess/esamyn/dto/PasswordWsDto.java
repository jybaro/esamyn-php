
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;
/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * PasswordWsDto.java Maneja la logica de Web services
 *
 */
public class PasswordWsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8201448609212098389L;

	private Long codigoUsuario;

	private String passwordAntiguo;

	private String passwordNuevo;

	/**
	 * Metodo get 
	 * @return the codigoUsuario
	 */
	public Long getCodigoUsuario() {
		return codigoUsuario;
	}

	/**
	 * Metodo set
	 * @param codigoUsuario the codigoUsuario to set
	 */
	public void setCodigoUsuario(Long codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	/**
	 * Metodo get 
	 * @return the passwordAntiguo
	 */
	public String getPasswordAntiguo() {
		return passwordAntiguo;
	}

	/**
	 * Metodo set
	 * @param passwordAntiguo the passwordAntiguo to set
	 */
	public void setPasswordAntiguo(String passwordAntiguo) {
		this.passwordAntiguo = passwordAntiguo;
	}

	/**
	 * Metodo get 
	 * @return the passwordNuevo
	 */
	public String getPasswordNuevo() {
		return passwordNuevo;
	}

	/**
	 * Metodo set
	 * @param passwordNuevo the passwordNuevo to set
	 */
	public void setPasswordNuevo(String passwordNuevo) {
		this.passwordNuevo = passwordNuevo;
	}

}
