
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * EliminarDto.java Maneja la logica de Web services
 *
 */
public class EliminarDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2562720911264435L;
	private Long codigo;
	/**
	 * Metodo get 
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}
	/**
	 * Metodo set
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

}
