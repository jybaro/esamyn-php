
package ec.gob.acess.esamyn.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Edgar Valarezo 
 * @version 1.0
 * 12/09/2017
 *  
 * AccesoWsDto.java Maneja la logica de Web services
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "login")
public class AccesoWsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4673840235510590872L;

	private String usuario;

	private String password;

	/**
	 * Metodo get 
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * Metodo set
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	/**
	 * Metodo get 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Metodo set
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
}
