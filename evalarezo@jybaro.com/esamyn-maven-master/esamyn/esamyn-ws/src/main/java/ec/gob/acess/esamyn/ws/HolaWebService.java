
package ec.gob.acess.esamyn.ws;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 * 
 * @author Edgar Valarezo
 * @version 1.0 12/09/2017
 * 
 *          Clase HolaWebService.java que publica servicios web
 *
 */
@Path("/hola")
public class HolaWebService {

	/**
	 * 
	 * Constructor clase HolaWebService.java
	 */
	public HolaWebService() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Servicio web de prueba
	 * 
	 * @return
	 */
	@GET
	@Produces("application/json")
	public String sayHello() {

		String mensajeDto = "ESAMYN pruebas";
		return mensajeDto;
	}
}
